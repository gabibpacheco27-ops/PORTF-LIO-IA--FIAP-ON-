# NOME COMPLETO: [PREENCHER] | RM: [PREENCHER] | Fase: [PREENCHER] | Capítulo: [PREENCHER]
# Trabalho de Agronegócio — Integrante 4
# Análise exploratória da variável quantitativa contínua: area_total_ha
#
# Base utilizada: arquivo base_agro_pessoa3.xlsx, aba "Dados".
# Fonte indicada no dicionário da base: IBGE, Censo Agropecuário 2017,
# SIDRA, tabela 6882. A base contém 81 registros (UF x uso da terra).
#
# Os valores abaixo foram copiados da coluna area_total_ha da base enviada
# pelo Integrante 3 para que a análise possa ser executada sem importar arquivos.

# 1. Inserção dos dados no R
area_total_ha <- c(
  324355, 56858, 118219, 71609, 889790, 43406, 1043471, 1245676, 1413162,
  650840, 259834, 398910, 682513, 459391, 256592, 3406716, 4015732,
  150538, 128619, 6860129, 6087812, 1356024, 7622066, 3591388, 9757280,
  4651568, 99561, 125791, 24169, 103772, 35118, 780929, 21190, 172719,
  106428, 165876, 330373, 87540, 43962, 142437, 41733, 77082, 1027521,
  1740888, 563052, 59014, 1193574, 209533, 114471, 192936, 36968, 99608,
  249827, 9304, 5740064, 1377663, 729032, 380264, 11533487, 43156,
  5285579, 4081773, 508065, 210900, 85882, 184264, 342790, 245606,
  421118, 5256409, 11768687, 1310487, 602310, 3114835, 3098967, 600382,
  1543287, 13065924, 17453290, 11299288, 27751
)

# Nome e unidade da variável
nome_variavel <- "Área total dos estabelecimentos agropecuários (ha)"

# Conferência inicial
cat("ANÁLISE EXPLORATÓRIA — AGRONEGÓCIO\n")
cat("Variável:", nome_variavel, "\n")
cat("Quantidade de observações:", length(area_total_ha), "\n")
cat("Valores ausentes:", sum(is.na(area_total_ha)), "\n\n")

# 2. Medidas de tendência central
media <- mean(area_total_ha, na.rm = TRUE)
mediana <- median(area_total_ha, na.rm = TRUE)

# A moda é o valor que aparece com maior frequência.
# O código retorna todos os valores que empatam na maior frequência.
frequencias <- table(area_total_ha)
maior_frequencia <- max(frequencias)
modas <- names(frequencias[frequencias == maior_frequencia])

cat("MEDIDAS DE TENDÊNCIA CENTRAL\n")
cat("Média:", round(media, 2), "ha\n")
cat("Mediana:", round(mediana, 2), "ha\n")

if (maior_frequencia == 1) {
  cat("Moda: não há moda única; todos os valores aparecem uma vez.\n\n")
} else {
  cat("Moda(s):", paste(modas, collapse = ", "), "ha\n\n")
}

# 3. Medidas de dispersão
amplitude <- max(area_total_ha, na.rm = TRUE) -
             min(area_total_ha, na.rm = TRUE)
variancia <- var(area_total_ha, na.rm = TRUE)
desvio_padrao <- sd(area_total_ha, na.rm = TRUE)
coef_variacao <- (desvio_padrao / media) * 100

cat("MEDIDAS DE DISPERSÃO\n")
cat("Mínimo:", min(area_total_ha, na.rm = TRUE), "ha\n")
cat("Máximo:", max(area_total_ha, na.rm = TRUE), "ha\n")
cat("Amplitude:", round(amplitude, 2), "ha\n")
cat("Variância amostral:", round(variancia, 2), "\n")
cat("Desvio padrão amostral:", round(desvio_padrao, 2), "ha\n")
cat("Coeficiente de variação:", round(coef_variacao, 2), "%\n\n")

# 4. Medidas separatrizes: quartis, decis e percentis
quartis <- quantile(
  area_total_ha,
  probs = c(0, 0.25, 0.50, 0.75, 1),
  na.rm = TRUE
)

decis <- quantile(
  area_total_ha,
  probs = seq(0.1, 0.9, by = 0.1),
  na.rm = TRUE
)

percentis <- quantile(
  area_total_ha,
  probs = c(0.10, 0.25, 0.50, 0.75, 0.90),
  na.rm = TRUE
)

cat("MEDIDAS SEPARATRIZES\n")
cat("Quartis (0%, 25%, 50%, 75%, 100%):\n")
print(quartis)
cat("\nDecis (10% a 90%):\n")
print(decis)
cat("\nPercentis selecionados (P10, P25, P50, P75 e P90):\n")
print(percentis)
cat("\n")

# 5. Resumo estatístico geral
cat("RESUMO ESTATÍSTICO\n")
print(summary(area_total_ha))
cat("\n")

# 6. Análise gráfica
# Histograma: mostra a distribuição dos valores.
# Como a variável pode apresentar valores muito altos, a distribuição
# pode ficar assimétrica; o gráfico ajuda a visualizar essa concentração.
hist(
  area_total_ha,
  main = "Distribuição da área total por UF e uso da terra",
  xlab = "Área total (hectares)",
  ylab = "Frequência",
  col = "lightblue",
  border = "white"
)

# Boxplot: mostra mediana, quartis, dispersão e possíveis valores extremos.
boxplot(
  area_total_ha,
  main = "Boxplot da área total dos estabelecimentos",
  ylab = "Área total (hectares)",
  col = "lightgreen"
)

# 7. Interpretação automática básica
cat("INTERPRETAÇÃO INICIAL\n")
if (media > mediana) {
  cat("A média é maior que a mediana, o que sugere influência de valores altos\n")
  cat("e possível assimetria à direita na distribuição.\n")
} else if (media < mediana) {
  cat("A média é menor que a mediana, o que pode indicar influência de valores baixos.\n")
} else {
  cat("A média e a mediana são iguais.\n")
}

cat("O coeficiente de variação foi de", round(coef_variacao, 2),
    "%. Valores elevados indicam grande dispersão relativa em torno da média.\n")
cat("Consulte o histograma e o boxplot para observar a forma da distribuição\n")
cat("e a presença de possíveis valores extremos.\n")
