# Trabalho de Agronegócio - Pessoa 5
# Análise gráfica de uma variável qualitativa ordinal: faixa_leite.
# Autoria: preencha seu nome e RM antes de entregar.
# Execute o arquivo inteiro no RStudio: botão Source ou Ctrl+Shift+Enter
# (no Mac, Command+Shift+Enter).
# Usa somente funções do R base: não exige instalação de pacotes.
#
# Base: Agronegocio_Pessoa_2.xlsx, aba Base, 30 registros (10 UFs x 3 anos).
# Fonte: IBGE, Pesquisa da Pecuária Municipal (PPM), SIDRA, tabela 74.
# Anos de referência: 2021, 2022 e 2023. Dados consultados em 07/10/2026.
# Link: https://sidra.ibge.gov.br/tabela/74
# As faixas são classificações analíticas do trabalho, não categorias oficiais.
# Este script usa a base da Pessoa 2. O script da Pessoa 4 utiliza outra base.

# 1. Inserção dos dados diretamente no R
dados <- data.frame(
  estado = rep(c("Pará", "Bahia", "Minas Gerais", "Rio de Janeiro",
                 "São Paulo", "Paraná", "Santa Catarina",
                 "Rio Grande do Sul", "Mato Grosso", "Goiás"), each = 3),
  ano = rep(c(2021L, 2022L, 2023L), times = 10),
  leite_milhoes_litros = c(
    558.313, 578.060, 580.398,
    1202.553, 1276.259, 1242.711,
    9611.706, 9362.690, 9422.028,
    412.809, 392.029, 391.902,
    1570.502, 1524.256, 1526.900,
    4415.634, 4459.359, 4545.468,
    3161.993, 3134.943, 3202.081,
    4400.356, 4071.675, 4114.732,
    545.924, 489.243, 455.837,
    3121.391, 2995.345, 2980.911
  ),
  stringsAsFactors = FALSE
)

# 2. Construção da variável qualitativa ordinal conforme o dicionário
# Baixa: até 1.000 milhões de litros (inclusive).
# Média: acima de 1.000 e até 3.000 milhões de litros (inclusive).
# Alta: acima de 3.000 milhões de litros.
# A ordem representa volume de produção, não qualidade do leite.
dados$faixa_leite <- cut(
  dados$leite_milhoes_litros,
  breaks = c(-Inf, 1000, 3000, Inf),
  labels = c("Baixa", "Média", "Alta"),
  right = TRUE,
  ordered_result = TRUE
)

# 3. Conferência dos dados
stopifnot(nrow(dados) == 30L,
          length(unique(dados$estado)) == 10L,
          !anyNA(dados),
          !anyDuplicated(dados[c("estado", "ano")]),
          is.ordered(dados$faixa_leite))

# 4. Frequências absoluta, relativa e percentual, calculadas no R
frequencia <- table(dados$faixa_leite)
relativa <- prop.table(frequencia)
tabela_frequencias <- data.frame(
  faixa_leite = names(frequencia),
  frequencia_absoluta = as.integer(frequencia),
  frequencia_relativa = as.numeric(relativa),
  percentual = round(as.numeric(relativa) * 100, 2)
)

cat("ANÁLISE QUALITATIVA - PESSOA 5\n")
cat("Variável: faixa de produção anual de leite (ordinal).\n")
cat("Unidade observacional: um estado em um ano.\n")
cat("30 registros, 10 estados, anos 2021-2023.\n\n")
print(dados, row.names = FALSE)
cat("\nTABELA DE FREQUÊNCIAS\n")
print(tabela_frequencias, row.names = FALSE)

# 5. Interpretação calculada com os resultados
indice_maior <- which.max(tabela_frequencias$frequencia_absoluta)
fmt <- function(x) formatC(x, format = "f", digits = 2, decimal.mark = ",")
interpretacao <- paste0(
  "A faixa ", tabela_frequencias$faixa_leite[indice_maior],
  " é a mais frequente, com ",
  tabela_frequencias$frequencia_absoluta[indice_maior], " dos ", nrow(dados),
  " registros (", fmt(tabela_frequencias$percentual[indice_maior]), "%). ",
  "A faixa Baixa reúne ", frequencia["Baixa"], " registros (",
  fmt(100 * relativa["Baixa"]), "%), e a faixa Média reúne ",
  frequencia["Média"], " registros (", fmt(100 * relativa["Média"]), "%). ",
  "Essas porcentagens medem a proporção de registros em cada faixa, ",
  "não a participação no volume total de leite."
)
nota <- paste0(
  "O recorte é intencional: cada um dos 10 estados aparece em três anos. ",
  "Portanto, os resultados descrevem os 30 registros selecionados e ",
  "não representam todos os estados ou estabelecimentos brasileiros. ",
  "Os limites das faixas foram definidos no trabalho."
)
cat("\nINTERPRETAÇÃO\n", interpretacao, "\n\n", nota, "\n", sep = "")

# 6. Gráfico de barras: adequado para categorias qualitativas
# Mantém a ordem Baixa < Média < Alta, inclusive para categorias vazias.
desenhar_grafico <- function() {
  op <- par(mar = c(6.5, 5, 5, 1))
  on.exit(par(op))
  barras <- barplot(
    frequencia,
    names.arg = names(frequencia),
    col = c("#8AB6A2", "#D4A85C", "#315A46"),
    border = NA,
    ylim = c(0, max(frequencia) * 1.3),
    main = "Faixas de produção anual de leite",
    xlab = "Faixa de produção (Baixa < Média < Alta)",
    ylab = "Número de registros (estado-ano)",
    las = 1,
    cex.names = 1.1
  )
  rotulos <- paste0(as.integer(frequencia), " (",
                    vapply(100 * as.numeric(relativa), fmt, character(1)), "%)")
  text(x = barras, y = as.numeric(frequencia), labels = rotulos,
       pos = 3, cex = 1)
  mtext("10 estados selecionados | 2021 a 2023 | n = 30", side = 3, line = 0.5)
  mtext("Fonte: IBGE/PPM, SIDRA 74. Faixas definidas no trabalho.",
        side = 1, line = 4.7, cex = 0.8)
}

# 7. Salvar os resultados na pasta de trabalho atual do R (getwd())
# O diretório separado facilita localizar todos os arquivos da Pessoa 5.
pasta_saida <- file.path(getwd(), "resultados_pessoa5")
dir.create(pasta_saida, recursive = TRUE, showWarnings = FALSE)
arquivo_grafico <- file.path(pasta_saida, "grafico_faixa_leite.png")
png(filename = arquivo_grafico, width = 1800, height = 1200, res = 180)
tryCatch(desenhar_grafico(), finally = dev.off())

write.csv2(dados, file.path(pasta_saida, "dados_pessoa5.csv"),
           row.names = FALSE, fileEncoding = "UTF-8")
write.csv2(tabela_frequencias, file.path(pasta_saida, "frequencias_pessoa5.csv"),
           row.names = FALSE, fileEncoding = "UTF-8")
writeLines(c("INTERPRETAÇÃO - PESSOA 5", interpretacao, "", nota, "",
             "Fonte: IBGE/PPM, SIDRA, tabela 74; anos 2021-2023.",
             "https://sidra.ibge.gov.br/tabela/74"),
           file.path(pasta_saida, "interpretacao_pessoa5.txt"), useBytes = TRUE)

# Mostrar também no painel Plots quando executado interativamente no RStudio.
if (interactive()) desenhar_grafico()
cat("\nArquivos gerados em: ", normalizePath(pasta_saida), "\n", sep = "")
