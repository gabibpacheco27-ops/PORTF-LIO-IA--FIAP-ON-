import pandas as pd
import numpy as np


def _validar_datas_e_periodo(df: pd.DataFrame, col_data: str, inconsistencias: list[dict]) -> pd.DataFrame:
    datas_convertidas = pd.to_datetime(df[col_data], format="%Y-%m-%d", errors="coerce")
    mask_invalida = datas_convertidas.isna()

    for idx in df[mask_invalida].index:
        inconsistencias.append({
            "arquivo": df.loc[idx, "origem_arquivo"],
            "registro_1base": int(df.loc[idx, "registro_1base"]),
            "campo": col_data,
            "tipo": "data_impossivel",
            "valor_encontrado": str(df.loc[idx, col_data]),
            "id_veiculo": df.loc[idx, "id_veiculo"],
            "acao_tomada": "descartado",
            "detalhe": "Data inválida no calendário; registro descartado sem inventar data",
        })

    df_valido = df[~mask_invalida].copy()
    df_valido[col_data] = datas_convertidas[~mask_invalida].dt.strftime("%Y-%m-%d")
    df_valido["periodo"] = datas_convertidas[~mask_invalida].dt.strftime("%Y-%m")
    return df_valido


def _filtrar_cadastro_e_nulos(
    df: pd.DataFrame,
    ids_validos: set[str],
    campos_obrigatorios: list[str],
    inconsistencias: list[dict],
) -> pd.DataFrame:
    indices_descartar = set()

    for idx, row in df.iterrows():
        # 1. Verifica campos obrigatórios vazios
        for campo in campos_obrigatorios:
            val = row[campo]
            if pd.isna(val) or str(val).strip() == "":
                inconsistencias.append({
                    "arquivo": row["origem_arquivo"],
                    "registro_1base": int(row["registro_1base"]),
                    "campo": campo,
                    "tipo": "obrigatorio_vazio",
                    "valor_encontrado": "NaN",
                    "id_veiculo": row["id_veiculo"] if pd.notna(row["id_veiculo"]) else "NaN",
                    "acao_tomada": "descartado",
                    "detalhe": f"Campo obrigatório '{campo}' vazio; registro descartado",
                })
                indices_descartar.add(idx)

        # 2. Verifica veículo inexistente no cadastro (apenas se id_veiculo não for nulo)
        if idx not in indices_descartar and row["id_veiculo"] not in ids_validos:
            inconsistencias.append({
                "arquivo": row["origem_arquivo"],
                "registro_1base": int(row["registro_1base"]),
                "campo": "id_veiculo",
                "tipo": "veiculo_inexistente",
                "valor_encontrado": str(row["id_veiculo"]),
                "id_veiculo": str(row["id_veiculo"]),
                "acao_tomada": "descartado",
                "detalhe": "Veículo ausente em cadastro_frota.csv; enviado para quarentena/descartado",
            })
            indices_descartar.add(idx)

    return df.drop(index=list(indices_descartar)).copy()


def _remover_duplicados(df: pd.DataFrame, cols_chave: list[str], inconsistencias: list[dict]) -> pd.DataFrame:
    mask_dup = df.duplicated(subset=cols_chave, keep="first")
    for idx in df[mask_dup].index:
        inconsistencias.append({
            "arquivo": df.loc[idx, "origem_arquivo"],
            "registro_1base": int(df.loc[idx, "registro_1base"]),
            "campo": "registro_inteiro",
            "tipo": "duplicado",
            "valor_encontrado": "duplicata_exata",
            "id_veiculo": df.loc[idx, "id_veiculo"],
            "acao_tomada": "descartado",
            "detalhe": "Registro duplicado exato; mantida a primeira ocorrência",
        })
    return df[~mask_dup].copy()


def validar_e_integrar(
    dfs_norm: dict[str, pd.DataFrame], inconsistencias_iniciais: list[dict]
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    inconsistencias = list(inconsistencias_iniciais)
    df_cadastro = dfs_norm["cadastro"].copy()
    ids_validos = set(df_cadastro["id_veiculo"].dropna().unique())

    # --- 1. COMBUSTÍVEL ---
    df_comb = dfs_norm["combustivel"].copy()
    df_comb = _remover_duplicados(df_comb, ["id_veiculo", "data", "litros", "valor_reais"], inconsistencias)
    df_comb = _filtrar_cadastro_e_nulos(
        df_comb, ids_validos, ["id_veiculo", "data", "litros", "valor_reais"], inconsistencias
    )
    df_comb = _validar_datas_e_periodo(df_comb, "data", inconsistencias)

    # Valores negativos em combustível (valor_reais <= 0 ou litros <= 0)
    idx_neg = []
    for idx, row in df_comb.iterrows():
        if row["valor_reais"] <= 0:
            inconsistencias.append({
                "arquivo": row["origem_arquivo"],
                "registro_1base": int(row["registro_1base"]),
                "campo": "valor_reais",
                "tipo": "valor_negativo",
                "valor_encontrado": str(row["valor_reais"]),
                "id_veiculo": row["id_veiculo"],
                "acao_tomada": "descartado",
                "detalhe": "Valor em reais negativo/zero; descartado sem aplicar abs()",
            })
            idx_neg.append(idx)
        elif row["litros"] <= 0:
            inconsistencias.append({
                "arquivo": row["origem_arquivo"],
                "registro_1base": int(row["registro_1base"]),
                "campo": "litros",
                "tipo": "litros_negativos",
                "valor_encontrado": str(row["litros"]),
                "id_veiculo": row["id_veiculo"],
                "acao_tomada": "descartado",
                "detalhe": "Litros negativos/zero; descartado sem aplicar abs()",
            })
            idx_neg.append(idx)
    df_comb = df_comb.drop(index=idx_neg)

    # --- 2. MANUTENÇÃO ---
    df_manut = dfs_norm["manutencao"].copy()
    df_manut = _remover_duplicados(df_manut, ["id_veiculo", "data", "descricao", "valor"], inconsistencias)
    df_manut = _filtrar_cadastro_e_nulos(df_manut, ids_validos, ["id_veiculo", "data", "valor"], inconsistencias)
    df_manut = _validar_datas_e_periodo(df_manut, "data", inconsistencias)

    # --- 3. PEDÁGIOS ---
    df_ped = dfs_norm["pedagios"].copy()
    df_ped = _remover_duplicados(df_ped, ["id_veiculo", "data", "valor"], inconsistencias)
    df_ped = _filtrar_cadastro_e_nulos(df_ped, ids_validos, ["id_veiculo", "data", "valor"], inconsistencias)
    df_ped = _validar_datas_e_periodo(df_ped, "data", inconsistencias)

    # --- 4. MULTAS E IMPOSTOS ---
    df_mi = dfs_norm["multas_impostos"].copy()
    df_mi = _remover_duplicados(df_mi, ["id_veiculo", "data", "categoria", "valor"], inconsistencias)
    df_mi = _filtrar_cadastro_e_nulos(df_mi, ids_validos, ["id_veiculo", "data", "categoria", "valor"], inconsistencias)
    df_mi = _validar_datas_e_periodo(df_mi, "data", inconsistencias)

    # --- 5. KM MENSAL ---
    df_km = dfs_norm["km_mensal"].copy()
    df_km = _remover_duplicados(df_km, ["id_veiculo", "periodo", "km_rodados"], inconsistencias)
    df_km = _filtrar_cadastro_e_nulos(df_km, ids_validos, ["id_veiculo", "periodo", "km_rodados"], inconsistencias)

    # --- 6. TELEMETRIA ESP32 ---
    df_tel = dfs_norm["telemetria"].copy()
    df_tel = _remover_duplicados(
        df_tel, ["id_veiculo", "timestamp", "velocidade", "rpm", "temperatura", "nivel_combustivel"], inconsistencias
    )
    df_tel = _filtrar_cadastro_e_nulos(df_tel, ids_validos, ["id_veiculo", "timestamp"], inconsistencias)

    # Leitura inválida de sensor (nivel_combustivel fora da faixa 0..100)
    mask_sensor_inv = (df_tel["nivel_combustivel"] < 0) | (df_tel["nivel_combustivel"] > 100)
    df_tel["leitura_invalida"] = mask_sensor_inv.astype(int)
    for idx in df_tel[mask_sensor_inv].index:
        inconsistencias.append({
            "arquivo": df_tel.loc[idx, "origem_arquivo"],
            "registro_1base": int(df_tel.loc[idx, "registro_1base"]),
            "campo": "nivel_combustivel",
            "tipo": "fora_de_faixa",
            "valor_encontrado": str(df_tel.loc[idx, "nivel_combustivel"]),
            "id_veiculo": df_tel.loc[idx, "id_veiculo"],
            "acao_tomada": "sinalizado",
            "detalhe": "Nível de combustível fora de 0-100%; sinalizado como falha de sensor",
        })

    df_tel["periodo"] = pd.to_datetime(df_tel["timestamp"]).dt.strftime("%Y-%m")

    # =========================================================================
    # MONTAGEM DO CONTRATO: custos_padronizados.csv
    # Colunas: id_veiculo, periodo, categoria, valor_reais, litros, km, origem_arquivo
    # =========================================================================
    c_comb = pd.DataFrame({
        "id_veiculo": df_comb["id_veiculo"],
        "periodo": df_comb["periodo"],
        "categoria": "combustivel",
        "valor_reais": df_comb["valor_reais"],
        "litros": df_comb["litros"],
        "km": np.nan,
        "origem_arquivo": df_comb["origem_arquivo"],
    })

    c_manut = pd.DataFrame({
        "id_veiculo": df_manut["id_veiculo"],
        "periodo": df_manut["periodo"],
        "categoria": "manutencao",
        "valor_reais": df_manut["valor"],
        "litros": 0.0,
        "km": np.nan,
        "origem_arquivo": df_manut["origem_arquivo"],
    })

    c_ped = pd.DataFrame({
        "id_veiculo": df_ped["id_veiculo"],
        "periodo": df_ped["periodo"],
        "categoria": "pedagio",
        "valor_reais": df_ped["valor"],
        "litros": 0.0,
        "km": np.nan,
        "origem_arquivo": df_ped["origem_arquivo"],
    })

    c_mi = pd.DataFrame({
        "id_veiculo": df_mi["id_veiculo"],
        "periodo": df_mi["periodo"],
        "categoria": df_mi["categoria"],
        "valor_reais": df_mi["valor"],
        "litros": 0.0,
        "km": np.nan,
        "origem_arquivo": df_mi["origem_arquivo"],
    })

    df_custos = pd.concat([c_comb, c_manut, c_ped, c_mi], ignore_index=True)

    # =========================================================================
    # MONTAGEM DA BASE INTEGRADA (1 linha por id_veiculo e periodo)
    # =========================================================================
    # Agrega custos por categoria
    pivot_custos = (
        df_custos.pivot_table(
            index=["id_veiculo", "periodo"],
            columns="categoria",
            values="valor_reais",
            aggfunc="sum",
            fill_value=0.0,
        )
        .reset_index()
    )
    for cat in ["combustivel", "manutencao", "pedagio", "multas", "impostos", "outros"]:
        if cat not in pivot_custos.columns:
            pivot_custos[cat] = 0.0
        pivot_custos.rename(columns={cat: f"custo_{cat}"}, inplace=True)

    agg_litros = (
        df_custos.groupby(["id_veiculo", "periodo"], as_index=False)["litros"]
        .sum()
        .rename(columns={"litros": "litros_totais"})
    )

    # Agrega telemetria por veículo e período
    agg_tel = (
        df_tel.groupby(["id_veiculo", "periodo"], as_index=False)
        .agg(
            qtd_leituras_telemetria=("anomalia", "count"),
            qtd_anomalias_telemetria=("anomalia", "sum"),
            qtd_leituras_invalidas_sensor=("leitura_invalida", "sum"),
            velocidade_media=("velocidade", "mean"),
            rpm_medio=("rpm", "mean"),
            temperatura_media=("temperatura", "mean"),
        )
    )

    # Base mestre: km_mensal + cadastro + custos + litros + telemetria
    base = df_km[["id_veiculo", "periodo", "km_rodados", "registro_1base", "origem_arquivo"]].merge(
        df_cadastro.drop(columns=["origem_arquivo", "registro_1base"]),
        on="id_veiculo",
        how="left",
    )
    base = base.merge(pivot_custos, on=["id_veiculo", "periodo"], how="left")
    base = base.merge(agg_litros, on=["id_veiculo", "periodo"], how="left")
    base = base.merge(agg_tel, on=["id_veiculo", "periodo"], how="left")

    # Integra rótulo real se disponível (para o Integrante 4 usar no ML)
    if "rotulos" in dfs_norm:
        base = base.merge(
            dfs_norm["rotulos"][["id_veiculo", "periodo", "ineficiente_real", "motivo"]],
            on=["id_veiculo", "periodo"],
            how="left",
        )

    # Verifica incoerência: km_rodados == 0 com litros_totais > 0 (INC-006)
    base["flag_incoerencia_km"] = 0
    mask_km_zero_comb = (base["km_rodados"] == 0) & (base["litros_totais"] > 0)
    for idx in base[mask_km_zero_comb].index:
        base.loc[idx, "flag_incoerencia_km"] = 1
        inconsistencias.append({
            "arquivo": base.loc[idx, "origem_arquivo"],
            "registro_1base": int(base.loc[idx, "registro_1base"]),
            "campo": "km_rodados",
            "tipo": "km_zero_com_combustivel",
            "valor_encontrado": "0",
            "id_veiculo": base.loc[idx, "id_veiculo"],
            "acao_tomada": "sinalizado",
            "detalhe": f"km_rodados=0 no período {base.loc[idx, 'periodo']} com {base.loc[idx, 'litros_totais']:.2f}L abastecidos; indicadores marcados como indefinidos",
        })

    # Calcula custo total e indicadores seguros (evitando divisão por zero)
    cols_custo = ["custo_combustivel", "custo_manutencao", "custo_pedagio", "custo_multas", "custo_impostos", "custo_outros"]
    base["custo_total"] = base[cols_custo].sum(axis=1)

    km_valido = base["km_rodados"].replace(0, np.nan)
    litros_valido = base["litros_totais"].replace(0, np.nan)

    base["custo_por_km"] = base["custo_total"] / km_valido
    base["consumo_km_l"] = km_valido / litros_valido

    # Preenche coluna 'km' em custos_padronizados.csv com o km_rodados do respectivo veículo/período
    df_custos = df_custos.merge(base[["id_veiculo", "periodo", "km_rodados"]], on=["id_veiculo", "periodo"], how="left")
    df_custos["km"] = df_custos["km_rodados"]
    df_custos = df_custos[["id_veiculo", "periodo", "categoria", "valor_reais", "litros", "km", "origem_arquivo"]]

    # Limpa colunas auxiliares internas da base_integrada
    base = base.drop(columns=["registro_1base", "origem_arquivo"])

    df_relatorio = pd.DataFrame(inconsistencias)
    return df_custos, base, df_relatorio