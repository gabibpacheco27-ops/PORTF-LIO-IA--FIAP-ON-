"""Diagnóstico de eficiência por regras de negócio usando gap de custo/km.

Uso: python src/diagnostico_regras.py --gaps outputs/gaps_veiculo_periodo.csv \
    --saida outputs
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

LIMITE_EFICIENTE_PCT = 10.0
LIMITE_ATENCAO_PCT = 25.0


def classificar_gap(gap_pct: float | None) -> str:
    """Classifica em eficiente, atenção, ineficiente ou dados insuficientes."""
    if gap_pct is None or pd.isna(gap_pct) or not np.isfinite(gap_pct):
        return "dados_insuficientes"
    if gap_pct <= LIMITE_EFICIENTE_PCT:
        return "eficiente"
    elif gap_pct <= LIMITE_ATENCAO_PCT:
        return "atencao"
    else:
        return "ineficiente"


def gerar_diagnosticos(caminho_gaps: Path, pasta_saida: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    if not caminho_gaps.exists():
        raise FileNotFoundError(f"Arquivo de gaps não encontrado: {caminho_gaps}")
    gaps = pd.read_csv(caminho_gaps)
    obrigatorias = ["id_veiculo", "periodo", "grupo_comparacao", "custo_por_km", "custo_por_km_mediana", "gap_custo_km_pct"]
    faltam = sorted(set(obrigatorias) - set(gaps.columns))
    if faltam:
        raise ValueError(f"Colunas ausentes no arquivo de gaps: {faltam}")

    mensal = gaps[obrigatorias + [
        c for c in ["gap_custo_km_diferenca", "gap_custo_km_absoluto", "consumo_km_l", "consumo_km_l_mediana", "gap_consumo_desfavoravel_pct", "km_rodados", "custo_total_calculado"]
        if c in gaps.columns
    ]].copy()
    mensal["diagnostico"] = mensal["gap_custo_km_pct"].apply(classificar_gap)
    mensal["criterio"] = (
        f"Gap percentual do custo/km versus mediana do grupo no mesmo mês: eficiente <= {LIMITE_EFICIENTE_PCT:.0f}%; "
        f"atenção > {LIMITE_EFICIENTE_PCT:.0f}% e <= {LIMITE_ATENCAO_PCT:.0f}%; ineficiente > {LIMITE_ATENCAO_PCT:.0f}%."
    )
    mensal["justificativa"] = mensal.apply(
        lambda r: (
            "Custo/km não calculável ou benchmark indisponível; revisar quilometragem e dados do período."
            if r["diagnostico"] == "dados_insuficientes" else
            f"Gap de custo/km de {r['gap_custo_km_pct']:.2f}% frente à mediana do grupo {r['grupo_comparacao']} no período {r['periodo']}."
        ), axis=1
    )

    resumo = (
        mensal.groupby(["id_veiculo", "grupo_comparacao"], as_index=False)
        .agg(
            periodos_total=("periodo", "count"),
            periodos_validos=("gap_custo_km_pct", "count"),
            gap_medio_pct=("gap_custo_km_pct", "mean"),
            gap_mediano_pct=("gap_custo_km_pct", "median"),
            custo_por_km_medio=("custo_por_km", "mean"),
            benchmark_custo_km_medio=("custo_por_km_mediana", "mean"),
            consumo_km_l_medio=("consumo_km_l", "mean"),
        )
    )
    resumo["diagnostico"] = resumo["gap_medio_pct"].apply(classificar_gap)
    resumo["criterio"] = (
        f"Média dos gaps mensais de custo/km: eficiente <= {LIMITE_EFICIENTE_PCT:.0f}%; "
        f"atenção > {LIMITE_EFICIENTE_PCT:.0f}% e <= {LIMITE_ATENCAO_PCT:.0f}%; ineficiente > {LIMITE_ATENCAO_PCT:.0f}%."
    )
    resumo["justificativa"] = resumo.apply(
        lambda r: (
            "Sem períodos com km e benchmark válidos; não foi possível classificar o veículo."
            if r["diagnostico"] == "dados_insuficientes" else
            f"Média de {r['gap_medio_pct']:.2f}% nos {int(r['periodos_validos'])} períodos válidos, comparada à mediana mensal do grupo."
        ), axis=1
    )
    ordem = {"ineficiente": 0, "atencao": 1, "eficiente": 2, "dados_insuficientes": 3}
    resumo["_ordem"] = resumo["diagnostico"].map(ordem)
    resumo = resumo.sort_values(["_ordem", "gap_medio_pct"], ascending=[True, False], na_position="last").drop(columns="_ordem")

    pasta_saida.mkdir(parents=True, exist_ok=True)
    mensal.to_csv(pasta_saida / "diagnostico_regras_mensal.csv", index=False, encoding="utf-8-sig")
    resumo.to_csv(pasta_saida / "diagnostico_regras.csv", index=False, encoding="utf-8-sig")
    return mensal, resumo


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gaps", type=Path, default=Path("outputs/gaps_veiculo_periodo.csv"))
    parser.add_argument("--saida", type=Path, default=Path("outputs"))
    args = parser.parse_args()
    mensal, resumo = gerar_diagnosticos(args.gaps, args.saida)
    print("Diagnóstico gerado.")
    print(resumo["diagnostico"].value_counts(dropna=False).to_string())
    print(f"Veículos resumidos: {len(resumo)} | registros mensais: {len(mensal)}")


if __name__ == "__main__":
    main()
