"""Módulos do projeto Sem Parar - Sprint 2."""
