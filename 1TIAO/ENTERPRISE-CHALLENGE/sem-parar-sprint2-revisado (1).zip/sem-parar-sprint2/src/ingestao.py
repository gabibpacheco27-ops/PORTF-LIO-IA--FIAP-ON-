import json
from datetime import datetime
from pathlib import Path
import pandas as pd


def ler_manutencao_json(caminho: Path) -> pd.DataFrame:
    with open(caminho, "r", encoding="utf-8") as f:
        dados = json.load(f)
    df = pd.DataFrame(dados)
    df["origem_arquivo"] = caminho.name
    df["registro_1base"] = range(1, len(df) + 1)
    return df


def ler_pedagios_txt(caminho: Path) -> pd.DataFrame:
    registros = []
    with open(caminho, "r", encoding="utf-8") as f:
        linhas = [linha.strip() for linha in f if linha.strip()]

    cabecalho = linhas[0].split(";")
    for idx, linha in enumerate(linhas[1:], start=1):
        partes = linha.split(";")
        registros.append(dict(zip(cabecalho, partes)))

    df = pd.DataFrame(registros)
    df["valor"] = pd.to_numeric(df["valor"], errors="coerce")
    df["origem_arquivo"] = caminho.name
    df["registro_1base"] = range(1, len(df) + 1)
    return df


def ler_csv_padrao(caminho: Path) -> pd.DataFrame:
    df = pd.read_csv(caminho)
    df["origem_arquivo"] = caminho.name
    df["registro_1base"] = range(1, len(df) + 1)
    return df


def _caminho_relativo(caminho: Path) -> str:
    """Evita gravar no log o caminho absoluto do computador de quem executou."""
    try:
        return str(caminho.resolve().relative_to(Path.cwd().resolve())).replace("\\", "/")
    except ValueError:
        return caminho.name


def carregar_dados_brutos(
    dir_raw: Path,
    dir_logs: Path | None = None,
    caminho_telemetria: Path | None = None,
) -> dict[str, pd.DataFrame]:
    """Lê os arquivos brutos. ``caminho_telemetria`` (opcional) substitui telemetria_esp32.csv,
    por exemplo pelo arquivo combinado com as leituras capturadas no Wokwi (nunca ler os dois)."""
    arquivos_esperados = {
        "cadastro": ("cadastro_frota.csv", ler_csv_padrao),
        "combustivel": ("combustivel.csv", ler_csv_padrao),
        "manutencao": ("manutencao.json", ler_manutencao_json),
        "pedagios": ("pedagios.txt", ler_pedagios_txt),
        "multas_impostos": ("multas_impostos.csv", ler_csv_padrao),
        "km_mensal": ("km_mensal.csv", ler_csv_padrao),
        "telemetria": ("telemetria_esp32.csv", ler_csv_padrao),
    }

    # Opcional: carrega rotulos_simulacao.csv se estiver presente para integrar ao dataset do ML
    caminho_rotulos = dir_raw / "rotulos_simulacao.csv"
    if caminho_rotulos.exists():
        arquivos_esperados["rotulos"] = ("rotulos_simulacao.csv", ler_csv_padrao)

    dfs = {}
    linhas_log = [
        f"=== LOG DE PROCESSAMENTO - INGESTÃO ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')}) ===",
        f"Diretório de origem (dados brutos intactos): {_caminho_relativo(dir_raw)}",
        "-" * 70,
    ]

    for chave, (nome_arquivo, funcao_leitura) in arquivos_esperados.items():
        caminho = dir_raw / nome_arquivo
        if chave == "telemetria" and caminho_telemetria is not None:
            caminho = Path(caminho_telemetria)
            nome_arquivo = caminho.name
        if not caminho.exists():
            raise FileNotFoundError(f"Arquivo obrigatório não encontrado: {caminho}")

        df = funcao_leitura(caminho)
        dfs[chave] = df
        linhas_log.append(
            f"[OK] {nome_arquivo:<25} | Registros lidos: {len(df):>5} | Colunas: {list(df.columns[:-2])}"
        )

    linhas_log.append("-" * 70)

    if dir_logs is not None:
        dir_logs.mkdir(parents=True, exist_ok=True)
        caminho_log = dir_logs / "log_processamento.txt"
        with open(caminho_log, "w", encoding="utf-8") as f:
            f.write("\n".join(linhas_log) + "\n")

    return dfs


