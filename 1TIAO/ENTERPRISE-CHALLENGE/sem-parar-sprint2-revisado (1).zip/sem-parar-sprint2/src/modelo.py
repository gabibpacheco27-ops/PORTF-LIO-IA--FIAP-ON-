"""Modelo introdutório de eficiência (classificação supervisionada) e comparação com as regras.

Pergunta do modelo: dado o desempenho mensal de um veículo, ele é eficiente (0) ou
ineficiente (1)?

Rótulo: ``ineficiente_real`` (arquivo data/raw/rotulos_simulacao.csv). É a condição que o
simulador plantou nos veículos, e NÃO é uma medida observada em frota real.

Atributos (nenhum deles é o rótulo, o motivo, o ID ou a placa):
    gap_consumo_desfavoravel_pct (quanto o consumo está abaixo da mediana do grupo, em %),
    participacao_manutencao_pct, km_rodados, idade_veiculo, qtd_anomalias_telemetria e custo_multas.
O consumo é usado de forma RELATIVA ao grupo porque o km/L absoluto mistura perfis muito
diferentes (automóvel ~11 km/L, caminhão ~3 km/L). O custo por km e seu gap ficam de fora,
pois são a base das regras de negócio.

Divisão treino/teste: POR VEÍCULO. Os seis meses de um mesmo veículo ficam sempre do mesmo
lado, para o teste não "enxergar" o veículo no treino.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text

ANO_REFERENCIA = 2026
ALVO = "ineficiente_real"
ATRIBUTOS_NUMERICOS = [
    "gap_consumo_desfavoravel_pct",
    "participacao_manutencao_pct",
    "km_rodados",
    "idade_veiculo",
    "qtd_anomalias_telemetria",
    "custo_multas",
]
SEMENTE = 42
FRACAO_TESTE = 0.25
PROFUNDIDADE_MAX = 3


def montar_tabela_modelo(indicadores_csv: Path, base_csv: Path, regras_mensal_csv: Path) -> pd.DataFrame:
    """Une os indicadores do benchmark com o rótulo de simulação (uma linha por veículo/mês)."""
    ind = pd.read_csv(indicadores_csv)
    base = pd.read_csv(base_csv)
    rotulos = base[["id_veiculo", "periodo", ALVO]]
    gap_consumo = pd.read_csv(regras_mensal_csv)[["id_veiculo", "periodo", "gap_consumo_desfavoravel_pct"]]
    df = ind.merge(rotulos, on=["id_veiculo", "periodo"], how="left", validate="one_to_one")
    df = df.merge(gap_consumo, on=["id_veiculo", "periodo"], how="left", validate="one_to_one")
    df["idade_veiculo"] = ANO_REFERENCIA - df["ano"]
    return df


def atributos_do_modelo() -> list[str]:
    return list(ATRIBUTOS_NUMERICOS)


def separar_por_veiculo(df: pd.DataFrame, semente: int = SEMENTE) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Sorteia veículos (estratificado pelo rótulo) e leva todos os meses de cada um."""
    veiculos = df.groupby("id_veiculo")[ALVO].max().reset_index()
    ids_treino, ids_teste = train_test_split(
        veiculos["id_veiculo"],
        test_size=FRACAO_TESTE,
        random_state=semente,
        stratify=veiculos[ALVO],
    )
    treino = df[df["id_veiculo"].isin(ids_treino)].copy()
    teste = df[df["id_veiculo"].isin(ids_teste)].copy()
    return treino, teste


def treinar_e_avaliar(df: pd.DataFrame) -> dict:
    atributos = atributos_do_modelo()
    # km=0 deixa consumo indefinido; a linha não entra no modelo (e fica registrada).
    sem_consumo = df[df["gap_consumo_desfavoravel_pct"].isna()][["id_veiculo", "periodo"]]
    df_ok = df.dropna(subset=atributos + [ALVO]).copy()

    treino, teste = separar_por_veiculo(df_ok)
    modelo = DecisionTreeClassifier(max_depth=PROFUNDIDADE_MAX, random_state=SEMENTE)
    modelo.fit(treino[atributos], treino[ALVO])

    teste["previsao_modelo"] = modelo.predict(teste[atributos])
    teste["acertou"] = (teste["previsao_modelo"] == teste[ALVO]).astype(int)
    acc_teste = accuracy_score(teste[ALVO], teste["previsao_modelo"])
    acc_treino = accuracy_score(treino[ALVO], modelo.predict(treino[atributos]))
    matriz = confusion_matrix(teste[ALVO], teste["previsao_modelo"], labels=[0, 1])

    # Robustez: o teste tem poucos veículos, então repete a divisão com outras sementes.
    # Informação complementar (o edital não exige validação cruzada).
    acuracias = []
    erros_outras = []
    for s in range(20):
        tr, te = separar_por_veiculo(df_ok, semente=s)
        m = DecisionTreeClassifier(max_depth=PROFUNDIDADE_MAX, random_state=SEMENTE)
        m.fit(tr[atributos], tr[ALVO])
        te = te.copy()
        te["previsao_modelo"] = m.predict(te[atributos])
        acuracias.append(accuracy_score(te[ALVO], te["previsao_modelo"]))
        err = te[te["previsao_modelo"] != te[ALVO]].copy()
        err.insert(0, "semente_da_divisao", s)
        erros_outras.append(err)
    erros_outras = pd.concat(erros_outras, ignore_index=True)

    importancias = (
        pd.Series(modelo.feature_importances_, index=atributos)
        .sort_values(ascending=False)
        .rename("importancia")
    )
    return {
        "modelo": modelo,
        "treino": treino,
        "teste": teste,
        "atributos": atributos,
        "acc_treino": acc_treino,
        "acc_teste": acc_teste,
        "matriz": matriz,
        "importancias": importancias,
        "arvore_texto": export_text(modelo, feature_names=atributos),
        "linhas_sem_consumo": sem_consumo,
        "acc_repetidas": np.array(acuracias),
        "erros_outras_divisoes": erros_outras,
    }


def exemplos(teste: pd.DataFrame, acertou: int, n: int = 3) -> pd.DataFrame:
    colunas = ["id_veiculo", "periodo", "perfil_uso", "gap_consumo_desfavoravel_pct",
               "participacao_manutencao_pct", ALVO, "previsao_modelo"]
    sub = teste[teste["acertou"] == acertou]
    if sub.empty:
        return sub[colunas]
    return sub.sample(min(n, len(sub)), random_state=SEMENTE)[colunas].sort_values(["id_veiculo", "periodo"])


def comparar_com_regras(teste: pd.DataFrame, regras_mensal_csv: Path) -> dict:
    """Compara, nas linhas de teste, a previsão do modelo com o diagnóstico por regras."""
    regras = pd.read_csv(regras_mensal_csv)[["id_veiculo", "periodo", "diagnostico", "gap_custo_km_pct"]]
    regras = regras.rename(columns={"diagnostico": "nivel_regra"})
    comp = teste.merge(regras, on=["id_veiculo", "periodo"], how="left")
    comp["previsao_modelo_txt"] = comp["previsao_modelo"].map({0: "modelo: eficiente", 1: "modelo: ineficiente"})
    tabela = pd.crosstab(comp["nivel_regra"], comp["previsao_modelo_txt"])
    # Concordância (atenção conta como "não eficiente" apenas para esta contagem)
    regra_bin = (comp["nivel_regra"].isin(["ineficiente", "atencao"])).astype(int)
    comp["regra_binaria"] = regra_bin
    valido = comp["nivel_regra"] != "dados_insuficientes"
    concordam = (comp.loc[valido, "regra_binaria"] == comp.loc[valido, "previsao_modelo"])
    divergencias = comp[valido & (comp["regra_binaria"] != comp["previsao_modelo"])]
    # Regras e modelo contra o rótulo de simulação
    acc_regra = (comp.loc[valido, "regra_binaria"] == comp.loc[valido, ALVO]).mean()
    acc_modelo = (comp.loc[valido, "previsao_modelo"] == comp.loc[valido, ALVO]).mean()
    return {
        "comparacao": comp,
        "tabela_cruzada": tabela,
        "concordancia": float(concordam.mean()) if valido.any() else float("nan"),
        "n_comparadas": int(valido.sum()),
        "divergencias": divergencias,
        "acc_regra_vs_rotulo": float(acc_regra),
        "acc_modelo_vs_rotulo": float(acc_modelo),
    }


def salvar_graficos(res: dict, pasta_assets: Path) -> list[str]:
    pasta_assets.mkdir(parents=True, exist_ok=True)
    arquivos = []

    fig, ax = plt.subplots(figsize=(4.6, 4))
    ax.imshow(res["matriz"], cmap="Blues")
    for (i, j), v in np.ndenumerate(res["matriz"]):
        ax.text(j, i, str(v), ha="center", va="center", fontsize=14,
                color="white" if v > res["matriz"].max() / 2 else "black")
    ax.set_xticks([0, 1], ["eficiente", "ineficiente"])
    ax.set_yticks([0, 1], ["eficiente", "ineficiente"])
    ax.set_xlabel("Previsão do modelo")
    ax.set_ylabel("Rótulo de simulação")
    ax.set_title(f"Matriz de confusão (teste) — acurácia {res['acc_teste']:.1%}")
    fig.tight_layout()
    caminho = pasta_assets / "06_matriz_confusao_modelo.png"
    fig.savefig(caminho, dpi=150)
    plt.close(fig)
    arquivos.append(caminho.name)

    imp = res["importancias"].sort_values()
    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    ax.barh(imp.index, imp.values, color="#3b6fb6")
    ax.set_xlabel("Importância na árvore de decisão")
    ax.set_title("Atributos usados pelo modelo")
    fig.tight_layout()
    caminho = pasta_assets / "07_importancia_atributos_modelo.png"
    fig.savefig(caminho, dpi=150)
    plt.close(fig)
    arquivos.append(caminho.name)
    return arquivos


def escrever_resumo(res: dict, comp: dict, caminho: Path) -> None:
    t = res["teste"]
    tr = res["treino"]
    acc = res["acc_repetidas"]
    linhas = [
        "RESUMO DO MODELO INTRODUTÓRIO DE EFICIÊNCIA — Sem Parar, Sprint 2",
        "=" * 66,
        "Algoritmo: árvore de decisão (scikit-learn), profundidade máxima "
        f"{PROFUNDIDADE_MAX}, semente {SEMENTE}.",
        f"Rótulo: {ALVO} (condição plantada pelo simulador; dados simulados).",
        f"Atributos: {', '.join(res['atributos'])}",
        "",
        f"Treino: {tr['id_veiculo'].nunique()} veículos / {len(tr)} linhas "
        f"({int(tr[ALVO].sum())} ineficientes).",
        f"Teste:  {t['id_veiculo'].nunique()} veículos / {len(t)} linhas "
        f"({int(t[ALVO].sum())} ineficientes). Veículos de teste: "
        f"{', '.join(sorted(t['id_veiculo'].unique()))}.",
        f"Linhas fora do modelo por consumo indefinido (km=0): {len(res['linhas_sem_consumo'])}.",
        "",
        f"Acurácia no treino: {res['acc_treino']:.1%}",
        f"Acurácia no teste:  {res['acc_teste']:.1%}",
        "Matriz de confusão (linhas = rótulo, colunas = previsão; ordem: eficiente, ineficiente):",
        str(res["matriz"]),
        "",
        f"Robustez (informativo): 20 divisões diferentes por veículo → acurácia média "
        f"{acc.mean():.1%}, mínima {acc.min():.1%}, máxima {acc.max():.1%}.",
        "",
        "Importância dos atributos:",
        res["importancias"].round(3).to_string(),
        "",
        "Regras aprendidas pela árvore:",
        res["arvore_texto"],
        "",
        "COMPARAÇÃO COM O DIAGNÓSTICO POR REGRAS (linhas de teste)",
        "-" * 66,
        f"Linhas comparadas: {comp['n_comparadas']} "
        "(exclui meses com dados insuficientes).",
        "Tabela cruzada (regra x modelo):",
        comp["tabela_cruzada"].to_string(),
        f"Concordância (atenção contada como 'não eficiente'): {comp['concordancia']:.1%}",
        f"Divergências: {len(comp['divergencias'])} linha(s).",
        f"Regras vs rótulo de simulação:  {comp['acc_regra_vs_rotulo']:.1%}",
        f"Modelo vs rótulo de simulação:  {comp['acc_modelo_vs_rotulo']:.1%}",
        "",
        "AVISO: dados simulados. O resultado mede o reconhecimento de padrões sintéticos "
        "plantados pelo gerador, não a validade em uma frota real.",
    ]
    caminho.write_text("\n".join(linhas) + "\n", encoding="utf-8")


def executar_modelo(indicadores_csv: Path, base_csv: Path, regras_mensal_csv: Path,
                    pasta_saida: Path, pasta_assets: Path) -> dict:
    pasta_saida.mkdir(parents=True, exist_ok=True)
    df = montar_tabela_modelo(indicadores_csv, base_csv, regras_mensal_csv)
    res = treinar_e_avaliar(df)
    comp = comparar_com_regras(res["teste"], regras_mensal_csv)

    previsoes = res["teste"][["id_veiculo", "periodo", "perfil_uso", *res["atributos"][:6],
                              ALVO, "previsao_modelo", "acertou"]]
    previsoes.to_csv(pasta_saida / "modelo_previsoes_teste.csv", index=False, encoding="utf-8-sig")
    comp["comparacao"][["id_veiculo", "periodo", "perfil_uso", ALVO, "previsao_modelo",
                        "nivel_regra", "gap_custo_km_pct", "regra_binaria"]].to_csv(
        pasta_saida / "comparacao_regras_modelo.csv", index=False, encoding="utf-8-sig")
    comp["divergencias"][["id_veiculo", "periodo", "perfil_uso", ALVO, "previsao_modelo",
                          "nivel_regra", "gap_custo_km_pct"]].to_csv(
        pasta_saida / "comparacao_divergencias.csv", index=False, encoding="utf-8-sig")
    res["importancias"].to_csv(pasta_saida / "modelo_importancia_atributos.csv", encoding="utf-8-sig")
    escrever_resumo(res, comp, pasta_saida / "modelo_resumo.txt")
    res["graficos"] = salvar_graficos(res, pasta_assets)
    res["comparacao_regras"] = comp
    res["exemplos_acertos"] = exemplos(res["teste"], 1)
    res["exemplos_erros"] = exemplos(res["teste"], 0)
    # Se a divisão principal não tiver erros, mostra erros de outras divisões por veículo.
    colunas_erro = ["semente_da_divisao", "id_veiculo", "periodo", "perfil_uso", "gap_consumo_desfavoravel_pct",
                    "participacao_manutencao_pct", "qtd_anomalias_telemetria", ALVO, "previsao_modelo"]
    erros = res["erros_outras_divisoes"][colunas_erro]
    erros.to_csv(pasta_saida / "modelo_erros_outras_divisoes.csv", index=False, encoding="utf-8-sig")
    res["exemplos_erros_outras_divisoes"] = erros.head(5)
    return res
