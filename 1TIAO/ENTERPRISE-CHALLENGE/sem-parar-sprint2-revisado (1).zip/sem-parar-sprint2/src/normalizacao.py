import re
import pandas as pd


def padronizar_id_veiculo(valor) -> str | None:
    if pd.isna(valor) or str(valor).strip() == "":
        return None
    texto = str(valor).strip().upper()
    match = re.search(r"(\d+)", texto)
    if match:
        numero = int(match.group(1))
        return f"VEIC-{numero:03d}"
    return texto


def padronizar_categoria(valor) -> str:
    if pd.isna(valor) or str(valor).strip() == "":
        return "outros"
    texto = str(valor).strip().lower()
    if "combust" in texto:
        return "combustivel"
    if "manut" in texto or "revisao" in texto or "reparo" in texto:
        return "manutencao"
    if "pedag" in texto:
        return "pedagio"
    if "multa" in texto:
        return "multas"
    if "imposto" in texto or "taxa" in texto or "ipva" in texto:
        return "impostos"
    return "outros"


def normalizar_dados(dfs_brutos: dict[str, pd.DataFrame]) -> tuple[dict[str, pd.DataFrame], list[dict]]:
    dfs = {k: v.copy() for k, v in dfs_brutos.items()}
    inconsistencias = []

    # 1. Padronizar IDs de veículos em todas as tabelas
    for nome_tabela, df in dfs.items():
        if "id_veiculo" in df.columns:
            ids_originais = df["id_veiculo"].copy()
            ids_padronizados = df["id_veiculo"].apply(padronizar_id_veiculo)

            # Registra casos em que o ID não estava vazio, mas precisou ser padronizado (ex: veic-1 -> VEIC-001)
            mask_alterado = (
                ids_originais.notna()
                & (ids_originais.astype(str).str.strip() != "")
                & (ids_originais.astype(str).str.strip() != ids_padronizados)
            )
            for idx in df[mask_alterado].index:
                inconsistencias.append({
                    "arquivo": df.loc[idx, "origem_arquivo"],
                    "registro_1base": int(df.loc[idx, "registro_1base"]),
                    "campo": "id_veiculo",
                    "tipo": "id_nao_padronizado",
                    "valor_encontrado": str(ids_originais.loc[idx]),
                    "id_veiculo": ids_padronizados.loc[idx],
                    "acao_tomada": "corrigido",
                    "detalhe": f"Padronizado de '{ids_originais.loc[idx]}' para '{ids_padronizados.loc[idx]}'",
                })

            df["id_veiculo"] = ids_padronizados

    # 2. Padronizar categorias em multas_impostos.csv (ex: 'Impostos e taxas' -> 'impostos')
    df_mi = dfs["multas_impostos"]
    cats_originais = df_mi["tipo"].copy()
    cats_padronizadas = df_mi["tipo"].apply(padronizar_categoria)

    mask_cat_alterada = cats_originais.notna() & (cats_originais.astype(str).str.strip() != cats_padronizadas)
    for idx in df_mi[mask_cat_alterada].index:
        inconsistencias.append({
            "arquivo": df_mi.loc[idx, "origem_arquivo"],
            "registro_1base": int(df_mi.loc[idx, "registro_1base"]),
            "campo": "tipo",
            "tipo": "categoria_nao_padronizada",
            "valor_encontrado": str(cats_originais.loc[idx]),
            "id_veiculo": df_mi.loc[idx, "id_veiculo"],
            "acao_tomada": "corrigido",
            "detalhe": f"Normalizado de '{cats_originais.loc[idx]}' para '{cats_padronizadas.loc[idx]}'",
        })
    df_mi["categoria"] = cats_padronizadas

    # 3. Garantir tipos numéricos limpos
    dfs["combustivel"]["litros"] = pd.to_numeric(dfs["combustivel"]["litros"], errors="coerce")
    dfs["combustivel"]["valor_reais"] = pd.to_numeric(dfs["combustivel"]["valor_reais"], errors="coerce")
    dfs["manutencao"]["valor"] = pd.to_numeric(dfs["manutencao"]["valor"], errors="coerce")
    dfs["pedagios"]["valor"] = pd.to_numeric(dfs["pedagios"]["valor"], errors="coerce")
    dfs["multas_impostos"]["valor"] = pd.to_numeric(dfs["multas_impostos"]["valor"], errors="coerce")
    dfs["km_mensal"]["km_rodados"] = pd.to_numeric(dfs["km_mensal"]["km_rodados"], errors="coerce")

    return dfs, inconsistencias