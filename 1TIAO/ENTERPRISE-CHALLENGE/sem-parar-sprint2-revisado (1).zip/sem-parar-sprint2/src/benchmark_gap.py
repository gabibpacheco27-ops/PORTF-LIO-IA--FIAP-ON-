"""Benchmark, indicadores e gaps de eficiência para o projeto Sem Parar.

Entradas esperadas: base_integrada.csv e custos_padronizados.csv produzidos
pelo módulo de ingestão/normalização/qualidade do Integrante 2.

Uso pelo orquestrador: importar executar_analise() ou executar diretamente:
    python src/benchmark_gap.py --base dados_entrada/base_integrada.csv \
        --custos dados_entrada/custos_padronizados.csv --saida outputs --assets assets
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

CATEGORIAS = ["combustivel", "manutencao", "pedagio", "multas", "impostos", "outros"]
COLUNAS_GRUPO = ["tipo", "porte", "perfil_uso"]
COLUNAS_OBRIGATORIAS_BASE = [
    "id_veiculo", "periodo", "km_rodados", "tipo", "porte", "perfil_uso"
]
COLUNAS_OBRIGATORIAS_CUSTOS = [
    "id_veiculo", "periodo", "categoria", "valor_reais", "litros", "km", "origem_arquivo"
]


def carregar_e_validar(base_path: Path, custos_path: Path) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Carrega os outputs do Integrante 2 e valida chaves e campos essenciais."""
    if not base_path.exists():
        raise FileNotFoundError(f"Base integrada não encontrada: {base_path}")
    if not custos_path.exists():
        raise FileNotFoundError(f"Custos padronizados não encontrados: {custos_path}")

    base = pd.read_csv(base_path)
    custos = pd.read_csv(custos_path)
    faltam_base = sorted(set(COLUNAS_OBRIGATORIAS_BASE) - set(base.columns))
    faltam_custos = sorted(set(COLUNAS_OBRIGATORIAS_CUSTOS) - set(custos.columns))
    if faltam_base:
        raise ValueError(f"Colunas ausentes em base_integrada.csv: {faltam_base}")
    if faltam_custos:
        raise ValueError(f"Colunas ausentes em custos_padronizados.csv: {faltam_custos}")

    base["km_rodados"] = pd.to_numeric(base["km_rodados"], errors="coerce")
    custos["valor_reais"] = pd.to_numeric(custos["valor_reais"], errors="coerce")
    custos["litros"] = pd.to_numeric(custos["litros"], errors="coerce").fillna(0.0)
    custos["km"] = pd.to_numeric(custos["km"], errors="coerce")
    custos["categoria"] = custos["categoria"].astype(str).str.strip().str.lower()
    base["periodo"] = base["periodo"].astype(str)
    custos["periodo"] = custos["periodo"].astype(str)
    base["id_veiculo"] = base["id_veiculo"].astype(str).str.strip().str.upper()
    custos["id_veiculo"] = custos["id_veiculo"].astype(str).str.strip().str.upper()

    if base.duplicated(["id_veiculo", "periodo"]).any():
        duplicadas = int(base.duplicated(["id_veiculo", "periodo"]).sum())
        raise ValueError(f"A base integrada deveria ter 1 linha por veículo/período; duplicadas: {duplicadas}")
    if not set(custos["categoria"].dropna().unique()).issubset(set(CATEGORIAS)):
        desconhecidas = sorted(set(custos["categoria"].dropna().unique()) - set(CATEGORIAS))
        raise ValueError(f"Categorias não reconhecidas em custos_padronizados.csv: {desconhecidas}")

    ids_base = set(base["id_veiculo"].dropna())
    ids_custos = set(custos["id_veiculo"].dropna())
    chaves_custos = set(map(tuple, custos[["id_veiculo", "periodo"]].drop_duplicates().to_numpy()))
    chaves_base = set(map(tuple, base[["id_veiculo", "periodo"]].drop_duplicates().to_numpy()))
    custos_sem_base = len(chaves_custos - chaves_base)
    negativos_custo = int((custos["valor_reais"] < 0).sum())
    reconciliacao = {}
    for categoria in CATEGORIAS:
        coluna_base = f"custo_{categoria}"
        if coluna_base in base.columns:
            agregado = (
                custos.loc[custos["categoria"].eq(categoria)]
                .groupby(["id_veiculo", "periodo"])["valor_reais"].sum()
            )
            chave_base = base.set_index(["id_veiculo", "periodo"])[coluna_base].fillna(0.0)
            agregado = agregado.reindex(chave_base.index, fill_value=0.0)
            reconciliacao[categoria] = float((chave_base - agregado).abs().max())

    metadados = {
        "linhas_base": int(len(base)),
        "veiculos": int(base["id_veiculo"].nunique()),
        "periodos": sorted(base["periodo"].dropna().unique().tolist()),
        "linhas_custos": int(len(custos)),
        "categorias": sorted(custos["categoria"].dropna().unique().tolist()),
        "ids_custo_sem_cadastro_na_base": int(len(ids_custos - ids_base)),
        "chaves_custo_sem_base_integrada": int(custos_sem_base),
        "registros_custo_negativos": negativos_custo,
        "reconciliacao_max_abs_por_categoria": reconciliacao,
    }
    if custos_sem_base:
        raise ValueError(f"Há {custos_sem_base} combinações veículo/período nos custos sem correspondência na base integrada.")
    return base, custos, metadados


def montar_indicadores(base: pd.DataFrame, custos: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Calcula indicadores por veículo/mês sem multiplicar quilometragem.

    custo/km = soma dos custos válidos do mês / km mensal.
    consumo km/l = km mensal / soma dos litros de combustível do mês.
    Participação = custo da categoria / custo total válido * 100.
    """
    # Custos totais e litros são agregados separadamente, evitando que a
    # quantidade de transações multiplique os km do veículo/mês.
    custos_ag = (
        custos.groupby(["id_veiculo", "periodo"], as_index=False)
        .agg(custo_total_calculado=("valor_reais", "sum"), litros_totais_calculados=("litros", "sum"))
    )
    pivot = (
        custos.pivot_table(
            index=["id_veiculo", "periodo"], columns="categoria", values="valor_reais", aggfunc="sum", fill_value=0
        )
        .reindex(columns=CATEGORIAS, fill_value=0)
        .reset_index()
    )
    pivot.columns.name = None
    pivot = pivot.rename(columns={c: f"custo_{c}" for c in CATEGORIAS})

    # Usa a base integrada como referência de cadastro, km e telemetria;
    # recalcula custos/litros diretamente do arquivo padronizado para evitar
    # duplicar colunas e validar a composição financeira.
    colunas_recalculadas = [
        "custo_total", "custo_por_km", "consumo_km_l", "litros_totais",
        "custo_combustivel", "custo_manutencao", "custo_pedagio",
        "custo_multas", "custo_impostos", "custo_outros",
    ]
    colunas_recalculadas += ["ineficiente_real", "motivo"]  # rótulo separado: não participa do benchmark
    base_info = base.drop(columns=[c for c in colunas_recalculadas if c in base.columns])
    dados = base_info.merge(custos_ag, on=["id_veiculo", "periodo"], how="left", validate="one_to_one")
    dados = dados.merge(pivot, on=["id_veiculo", "periodo"], how="left", validate="one_to_one")
    dados["custo_total_calculado"] = dados["custo_total_calculado"].fillna(0.0)
    dados["litros_totais_calculados"] = dados["litros_totais_calculados"].fillna(0.0)
    for c in CATEGORIAS:
        dados[f"custo_{c}"] = dados[f"custo_{c}"].fillna(0.0)

    dados["km_rodados"] = pd.to_numeric(dados["km_rodados"], errors="coerce")
    km_valido = dados["km_rodados"].where(dados["km_rodados"] > 0)
    litros_validos = dados["litros_totais_calculados"].where(dados["litros_totais_calculados"] > 0)
    dados["custo_por_km"] = dados["custo_total_calculado"] / km_valido
    dados["consumo_km_l"] = km_valido / litros_validos

    dados["grupo_comparacao"] = (
        dados["tipo"].astype(str) + " | " + dados["porte"].astype(str) + " | " + dados["perfil_uso"].astype(str)
    )
    for cat in CATEGORIAS:
        dados[f"custo_{cat}_por_km"] = dados[f"custo_{cat}"] / km_valido
        dados[f"participacao_{cat}_pct"] = np.where(
            dados["custo_total_calculado"] > 0,
            dados[f"custo_{cat}"] / dados["custo_total_calculado"] * 100,
            np.nan,
        )

    # Base longa por categoria: permite benchmark e gap por rubrica de custo.
    colunas_fixas = [
        "id_veiculo", "periodo", *COLUNAS_GRUPO, "grupo_comparacao", "km_rodados",
        "custo_total_calculado", "custo_por_km", "consumo_km_l",
    ]
    linhas_cat = []
    for cat in CATEGORIAS:
        parte = dados[colunas_fixas].copy()
        parte["categoria"] = cat
        parte["valor_categoria_reais"] = dados[f"custo_{cat}"]
        parte["custo_categoria_por_km"] = dados[f"custo_{cat}_por_km"]
        parte["participacao_categoria_pct"] = dados[f"participacao_{cat}_pct"]
        linhas_cat.append(parte)
    categoria_long = pd.concat(linhas_cat, ignore_index=True)

    return dados, categoria_long


def _estatisticas_serie(serie: pd.Series) -> pd.Series:
    valores = pd.to_numeric(serie, errors="coerce").dropna()
    if valores.empty:
        return pd.Series({"media": np.nan, "mediana": np.nan, "q1": np.nan, "q3": np.nan, "n": 0})
    return pd.Series({
        "media": valores.mean(), "mediana": valores.median(),
        "q1": valores.quantile(0.25), "q3": valores.quantile(0.75), "n": int(valores.count()),
    })


def calcular_benchmark(dados: pd.DataFrame, categoria_long: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Cria benchmark por grupo/período e resumo geral por grupo."""
    chaves = [*COLUNAS_GRUPO, "grupo_comparacao", "periodo"]
    linhas = []
    for key, sub in dados.groupby(chaves, dropna=False):
        registro = dict(zip(chaves, key if isinstance(key, tuple) else (key,)))
        registro["veiculos_no_grupo"] = int(sub["id_veiculo"].nunique())
        for indicador in ["custo_por_km", "consumo_km_l"]:
            stats = _estatisticas_serie(sub[indicador])
            for metrica in ["media", "mediana", "q1", "q3", "n"]:
                registro[f"{indicador}_{metrica}"] = stats[metrica]
        linhas.append(registro)
    benchmark_periodo = pd.DataFrame(linhas)

    resumo_linhas = []
    for key, sub in dados.groupby([*COLUNAS_GRUPO, "grupo_comparacao"], dropna=False):
        registro = dict(zip([*COLUNAS_GRUPO, "grupo_comparacao"], key if isinstance(key, tuple) else (key,)))
        registro["veiculos_no_grupo"] = int(sub["id_veiculo"].nunique())
        registro["observacoes_veiculo_periodo"] = int(len(sub))
        for indicador in ["custo_por_km", "consumo_km_l"]:
            stats = _estatisticas_serie(sub[indicador])
            for metrica in ["media", "mediana", "q1", "q3", "n"]:
                registro[f"{indicador}_{metrica}"] = stats[metrica]
        resumo_linhas.append(registro)
    benchmark_grupos = pd.DataFrame(resumo_linhas)

    cat_stats = (
        categoria_long.groupby([*chaves, "categoria"], as_index=False)
        .agg(
            custo_categoria_km_media=("custo_categoria_por_km", "mean"),
            custo_categoria_km_mediana=("custo_categoria_por_km", "median"),
            custo_categoria_km_q1=("custo_categoria_por_km", lambda x: x.quantile(0.25)),
            custo_categoria_km_q3=("custo_categoria_por_km", lambda x: x.quantile(0.75)),
            participacao_categoria_media_pct=("participacao_categoria_pct", "mean"),
            participacao_categoria_mediana_pct=("participacao_categoria_pct", "median"),
            participacao_categoria_q1_pct=("participacao_categoria_pct", lambda x: x.quantile(0.25)),
            participacao_categoria_q3_pct=("participacao_categoria_pct", lambda x: x.quantile(0.75)),
            n_custo_km_validos=("custo_categoria_por_km", "count"),
            n_participacao_validos=("participacao_categoria_pct", "count"),
        )
    )
    return benchmark_periodo, benchmark_grupos, cat_stats


def calcular_gaps(dados: pd.DataFrame, benchmark_periodo: pd.DataFrame,
                  categoria_long: pd.DataFrame, benchmark_categoria: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Calcula diferenças absolutas/percentuais frente à mediana do grupo."""
    chaves = [*COLUNAS_GRUPO, "grupo_comparacao", "periodo"]
    gaps = dados.merge(benchmark_periodo, on=chaves, how="left", validate="many_to_one")

    # Custo/km: positivo significa que o veículo gasta mais que a mediana do grupo.
    ref_cpk = gaps["custo_por_km_mediana"]
    gaps["gap_custo_km_diferenca"] = gaps["custo_por_km"] - ref_cpk
    gaps["gap_custo_km_absoluto"] = gaps["gap_custo_km_diferenca"].abs()
    gaps["gap_custo_km_pct"] = np.where(ref_cpk > 0, gaps["gap_custo_km_diferenca"] / ref_cpk * 100, np.nan)

    # Consumo km/L: consumo menor que a mediana é desfavorável.
    ref_cons = gaps["consumo_km_l_mediana"]
    gaps["gap_consumo_km_l_diferenca"] = gaps["consumo_km_l"] - ref_cons
    gaps["gap_consumo_km_l_absoluto"] = gaps["gap_consumo_km_l_diferenca"].abs()
    gaps["gap_consumo_km_l_pct"] = np.where(ref_cons > 0, gaps["gap_consumo_km_l_diferenca"] / ref_cons * 100, np.nan)
    gaps["gap_consumo_desfavoravel_pct"] = -gaps["gap_consumo_km_l_pct"]

    # Categoria: compara R$/km e também a participação no custo total (pontos percentuais).
    cat_keys = [*chaves, "categoria"]
    gaps_cat = categoria_long.merge(benchmark_categoria, on=cat_keys, how="left", validate="many_to_one")
    ref_cat = gaps_cat["custo_categoria_km_mediana"]
    gaps_cat["gap_categoria_km_diferenca"] = gaps_cat["custo_categoria_por_km"] - ref_cat
    gaps_cat["gap_categoria_km_absoluto"] = gaps_cat["gap_categoria_km_diferenca"].abs()
    gaps_cat["gap_categoria_km_pct"] = np.where(ref_cat > 0, gaps_cat["gap_categoria_km_diferenca"] / ref_cat * 100, np.nan)
    gaps_cat["gap_participacao_categoria_pp"] = (
        gaps_cat["participacao_categoria_pct"] - gaps_cat["participacao_categoria_mediana_pct"]
    )
    gaps_cat["referencia_categoria_zero"] = ref_cat.fillna(0).eq(0)

    ranking_veiculos = (
        gaps.groupby(["id_veiculo", *COLUNAS_GRUPO, "grupo_comparacao"], as_index=False)
        .agg(
            periodos_validos=("gap_custo_km_pct", "count"),
            gap_custo_km_pct_medio=("gap_custo_km_pct", "mean"),
            gap_custo_km_pct_mediano=("gap_custo_km_pct", "median"),
            custo_por_km_medio=("custo_por_km", "mean"),
            consumo_km_l_medio=("consumo_km_l", "mean"),
            custo_total_periodos=("custo_total_calculado", "sum"),
            km_total_periodos=("km_rodados", "sum"),
        )
    )
    ranking_veiculos = ranking_veiculos.sort_values(
        ["gap_custo_km_pct_medio", "gap_custo_km_pct_mediano"], ascending=False, na_position="last"
    ).reset_index(drop=True)
    ranking_veiculos.insert(0, "ranking", np.arange(1, len(ranking_veiculos) + 1))

    ranking_categoria = (
        gaps_cat.groupby(["id_veiculo", *COLUNAS_GRUPO, "grupo_comparacao", "categoria"], as_index=False)
        .agg(
            periodos_validos=("gap_categoria_km_diferenca", "count"),
            gap_categoria_km_diferenca_media=("gap_categoria_km_diferenca", "mean"),
            gap_categoria_km_abs_medio=("gap_categoria_km_absoluto", "mean"),
            gap_categoria_km_pct_medio=("gap_categoria_km_pct", "mean"),
            gap_participacao_pp_medio=("gap_participacao_categoria_pp", "mean"),
        )
    )
    # O ranking principal usa a diferença absoluta em R$/km. Percentuais de
    # categorias com referência pequena podem ficar muito grandes e devem ser
    # interpretados com cautela; o campo percentual continua disponível.
    ranking_categoria = ranking_categoria.sort_values(
        ["gap_categoria_km_abs_medio", "gap_categoria_km_pct_medio"], ascending=False, na_position="last"
    ).reset_index(drop=True)
    ranking_categoria.insert(0, "ranking", np.arange(1, len(ranking_categoria) + 1))

    return gaps, gaps_cat, ranking_veiculos, ranking_categoria


def calcular_participacao_grupo(categoria_long: pd.DataFrame) -> pd.DataFrame:
    """Participação ponderada: soma da categoria / soma dos custos do grupo."""
    totais = (
        categoria_long.groupby(["grupo_comparacao", "categoria"], as_index=False)["valor_categoria_reais"]
        .sum()
    )
    totais["custo_total_grupo"] = totais.groupby("grupo_comparacao")["valor_categoria_reais"].transform("sum")
    totais["participacao_categoria_pct"] = np.where(
        totais["custo_total_grupo"] > 0, totais["valor_categoria_reais"] / totais["custo_total_grupo"] * 100, np.nan
    )
    return totais


def calcular_correlacao(dados: pd.DataFrame) -> pd.DataFrame:
    candidatos = [
        "km_rodados", "custo_total_calculado", "custo_por_km", "consumo_km_l",
        "litros_totais_calculados", "custo_combustivel", "custo_manutencao",
        "custo_pedagio", "custo_multas", "custo_impostos",
        "qtd_anomalias_telemetria", "velocidade_media", "rpm_medio", "temperatura_media",
    ]
    colunas = [c for c in candidatos if c in dados.columns and pd.api.types.is_numeric_dtype(dados[c])]
    return dados[colunas].corr(method="pearson")


def gerar_graficos(dados: pd.DataFrame, ranking: pd.DataFrame, categoria_long: pd.DataFrame,
                   participacao_grupo: pd.DataFrame, correlacao: pd.DataFrame, pasta_assets: Path) -> list[str]:
    pasta_assets.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid", context="notebook")
    arquivos = []

    # 1. Boxplot do custo/km por grupo comparável.
    fig, ax = plt.subplots(figsize=(11, 6))
    sns.boxplot(data=dados, x="grupo_comparacao", y="custo_por_km", ax=ax)
    ax.set_title("Distribuição do custo por km por grupo de comparação")
    ax.set_xlabel("Grupo (tipo | porte | perfil de uso)")
    ax.set_ylabel("Custo por km (R$/km)")
    ax.tick_params(axis="x", rotation=15)
    fig.tight_layout()
    fig.savefig(pasta_assets / "01_boxplot_custo_por_km_grupo.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    arquivos.append("01_boxplot_custo_por_km_grupo.png")

    # 2. Ranking médio do gap do custo/km por veículo.
    top = ranking.dropna(subset=["gap_custo_km_pct_medio"]).head(10).sort_values("gap_custo_km_pct_medio")
    fig, ax = plt.subplots(figsize=(12, 6))
    if not top.empty:
        sns.barplot(data=top, x="gap_custo_km_pct_medio", y="id_veiculo", hue="grupo_comparacao", dodge=False, ax=ax)
        ax.legend(title="Grupo", fontsize=8, bbox_to_anchor=(1.02, 1), loc="upper left")
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title("10 maiores gaps médios de custo por km")
    ax.set_xlabel("Gap em relação à mediana do grupo (%) — positivo = custo maior")
    ax.set_ylabel("Veículo")
    fig.tight_layout(rect=[0, 0, 0.82, 1])
    fig.savefig(pasta_assets / "02_ranking_maiores_gaps_custo_km.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    arquivos.append("02_ranking_maiores_gaps_custo_km.png")

    # 3. Composição média dos custos por grupo.
    shares_pivot = participacao_grupo.pivot(index="grupo_comparacao", columns="categoria", values="participacao_categoria_pct").fillna(0)
    shares_pivot = shares_pivot.reindex(columns=CATEGORIAS, fill_value=0)
    fig, ax = plt.subplots(figsize=(11, 6))
    shares_pivot.plot(kind="bar", stacked=True, ax=ax)
    ax.set_title("Participação das categorias no custo total por grupo")
    ax.set_xlabel("Grupo (tipo | porte | perfil de uso)")
    ax.set_ylabel("Participação no custo total (%)")
    ax.legend(title="Categoria", bbox_to_anchor=(1.02, 1), loc="upper left")
    ax.tick_params(axis="x", rotation=15)
    fig.tight_layout()
    fig.savefig(pasta_assets / "03_participacao_categorias_grupo.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    arquivos.append("03_participacao_categorias_grupo.png")

    # 4. Heatmap de correlação.
    fig, ax = plt.subplots(figsize=(12, 9))
    sns.heatmap(correlacao, cmap="coolwarm", center=0, annot=True, fmt=".2f", square=False, ax=ax)
    ax.set_title("Correlação de Pearson entre indicadores operacionais e de custo")
    fig.tight_layout()
    fig.savefig(pasta_assets / "04_heatmap_correlacao.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    arquivos.append("04_heatmap_correlacao.png")

    # 5. Evolução mensal do custo/km mediano por grupo.
    mensal = (
        dados.groupby(["periodo", "grupo_comparacao"], as_index=False)["custo_por_km"].median()
    )
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.lineplot(data=mensal, x="periodo", y="custo_por_km", hue="grupo_comparacao", marker="o", ax=ax)
    ax.set_title("Evolução mensal da mediana do custo por km por grupo")
    ax.set_xlabel("Período")
    ax.set_ylabel("Custo por km mediano (R$/km)")
    ax.tick_params(axis="x", rotation=20)
    fig.tight_layout()
    fig.savefig(pasta_assets / "05_evolucao_custo_km_grupos.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    arquivos.append("05_evolucao_custo_km_grupos.png")

    return arquivos


def executar_analise(base_path: Path, custos_path: Path, pasta_saida: Path, pasta_assets: Path) -> dict:
    pasta_saida.mkdir(parents=True, exist_ok=True)
    base, custos, metadados = carregar_e_validar(base_path, custos_path)
    dados, categoria_long = montar_indicadores(base, custos)
    benchmark_periodo, benchmark_grupos, benchmark_categoria = calcular_benchmark(dados, categoria_long)
    gaps, gaps_cat, ranking_veiculos, ranking_categoria = calcular_gaps(
        dados, benchmark_periodo, categoria_long, benchmark_categoria
    )
    participacao_grupo = calcular_participacao_grupo(categoria_long)
    correlacao = calcular_correlacao(dados)
    graficos = gerar_graficos(dados, ranking_veiculos, categoria_long, participacao_grupo, correlacao, pasta_assets)

    # Exportações focadas no consumo do Integrante 3 e na integração do grupo.
    dados.to_csv(pasta_saida / "indicadores_veiculo_periodo.csv", index=False, encoding="utf-8-sig")
    benchmark_periodo.to_csv(pasta_saida / "benchmark_grupo_periodo.csv", index=False, encoding="utf-8-sig")
    benchmark_grupos.to_csv(pasta_saida / "benchmark_resumo_grupos.csv", index=False, encoding="utf-8-sig")
    benchmark_categoria.to_csv(pasta_saida / "benchmark_categoria_grupo_periodo.csv", index=False, encoding="utf-8-sig")
    participacao_grupo.to_csv(pasta_saida / "participacao_categoria_grupo.csv", index=False, encoding="utf-8-sig")
    gaps.to_csv(pasta_saida / "gaps_veiculo_periodo.csv", index=False, encoding="utf-8-sig")
    gaps_cat.to_csv(pasta_saida / "gaps_por_categoria.csv", index=False, encoding="utf-8-sig")
    ranking_veiculos.to_csv(pasta_saida / "ranking_maiores_gaps_veiculos.csv", index=False, encoding="utf-8-sig")
    ranking_categoria.to_csv(pasta_saida / "ranking_maiores_gaps_categorias.csv", index=False, encoding="utf-8-sig")
    correlacao.to_csv(pasta_saida / "matriz_correlacao_pearson.csv", index_label="variavel", encoding="utf-8-sig")

    return {
        "metadados": metadados,
        "dados": dados,
        "categoria_long": categoria_long,
        "benchmark_periodo": benchmark_periodo,
        "benchmark_grupos": benchmark_grupos,
        "benchmark_categoria": benchmark_categoria,
        "participacao_grupo": participacao_grupo,
        "gaps": gaps,
        "gaps_categoria": gaps_cat,
        "ranking_veiculos": ranking_veiculos,
        "ranking_categoria": ranking_categoria,
        "correlacao": correlacao,
        "graficos": graficos,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("dados_entrada/base_integrada.csv"))
    parser.add_argument("--custos", type=Path, default=Path("dados_entrada/custos_padronizados.csv"))
    parser.add_argument("--saida", type=Path, default=Path("outputs"))
    parser.add_argument("--assets", type=Path, default=Path("assets"))
    args = parser.parse_args()
    resultado = executar_analise(args.base, args.custos, args.saida, args.assets)
    print("Análise concluída.")
    print(f"Veículos: {resultado['metadados']['veiculos']} | períodos: {len(resultado['metadados']['periodos'])}")
    print("Resumo de benchmark:")
    print(resultado["benchmark_grupos"][["grupo_comparacao", "custo_por_km_mediana", "consumo_km_l_mediana"]].to_string(index=False))
    print(f"Arquivos gráficos: {', '.join(resultado['graficos'])}")


if __name__ == "__main__":
    main()
