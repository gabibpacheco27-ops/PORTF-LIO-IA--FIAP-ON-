"""Dados inteiramente sintéticos da POC Sem Parar; Python 3.10+, sem dependências."""
import argparse
import csv
import hashlib
import json
import random
from datetime import datetime, timedelta
from pathlib import Path

SEED = 20261114
PERIODOS = [f'2026-{mes:02d}' for mes in range(5, 11)]
PERFIS = [
    ('leve_urbana', 'automovel', 'leve', 1800, 2800, 11.5, 6.20, 240),
    ('mista', 'utilitario', 'medio', 3200, 5200, 8.5, 6.10, 520),
    ('pesada_rodoviaria', 'caminhao', 'pesado', 7000, 10500, 3.0, 6.10, 1600),
]


def salvar_csv(path, rows, campos=None):
    with path.open('w', encoding='utf-8', newline='') as arq:
        writer = csv.DictWriter(arq, fieldnames=campos or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def anomalia(vel, rpm, temp, nivel):
    return int(vel > 110 or rpm > 3500 or temp > 105 or nivel < 15)


def gerar(destino):
    rng = random.Random(SEED)
    raiz = Path(destino)
    bruto = raiz / 'dados' / 'brutos'
    docs = raiz / 'docs'
    bruto.mkdir(parents=True, exist_ok=True)
    docs.mkdir(parents=True, exist_ok=True)
    tabelas = {n: [] for n in ['cadastro_frota.csv', 'combustivel.csv', 'manutencao.json',
                                'pedagios.txt', 'multas_impostos.csv', 'km_mensal.csv',
                                'telemetria_esp32.csv']}
    rotulos = []
    for grupo, (perfil, tipo, porte, kmin, kmax, consumo, preco, manut) in enumerate(PERFIS):
        for j in range(12):
            num = grupo * 12 + j + 1
            vid = f'VEIC-{num:03d}'
            ruim = int(j in (2, 6, 10))
            # Propensão persistente por veículo; ruído mensal evita dados idênticos.
            fator_individual = rng.uniform(.90, 1.10)
            tabelas['cadastro_frota.csv'].append(dict(id_veiculo=vid, placa=f'SIM-{num:04d}',
                tipo=tipo, porte=porte, perfil_uso=perfil, ano=rng.randint(2015, 2024)))
            for periodo in PERIODOS:
                km = rng.randint(kmin, kmax)
                kml = consumo * fator_individual * rng.uniform(.88, 1.12)
                if ruim:
                    kml *= rng.uniform(.62, .78)
                litros = round(km / kml, 2)
                tabelas['km_mensal.csv'].append(dict(id_veiculo=vid, periodo=periodo, km_rodados=km))
                rotulos.append(dict(id_veiculo=vid, periodo=periodo, ineficiente_real=ruim,
                    motivo='consumo_e_manutencao_elevados' if ruim else 'operacao_referencia_simulada'))
                # Quatro resumos de abastecimento; não simulam a capacidade física de um tanque.
                partes = [round(litros / 4, 2)] * 3
                partes.append(round(litros - sum(partes), 2))
                for dia, volume in zip((4, 11, 18, 25), partes):
                    tabelas['combustivel.csv'].append(dict(id_veiculo=vid, data=f'{periodo}-{dia:02d}',
                        litros=volume, valor_reais=round(volume * preco, 2)))
                # Serviço preventivo mensal e corretivas adicionais nos veículos plantados.
                tabelas['manutencao.json'].append(dict(id_veiculo=vid, data=f'{periodo}-12',
                    descricao='preventiva: revisao e inspecao simuladas',
                    valor=round(manut * rng.uniform(.70, 1.30), 2)))
                if ruim:
                    for dia in (16, 23):
                        tabelas['manutencao.json'].append(dict(id_veiculo=vid, data=f'{periodo}-{dia}',
                            descricao='corretiva: reparo simulado', valor=round(manut * rng.uniform(.9, 1.7), 2)))
                taxa = (.012, .045, .10)[grupo]
                tabelas['pedagios.txt'].append(dict(id_veiculo=vid, data=f'{periodo}-20',
                    valor=round(km * taxa * rng.uniform(.8, 1.2), 2)))
                tabelas['multas_impostos.csv'].append(dict(id_veiculo=vid, data=f'{periodo}-10',
                    tipo='impostos', valor=(110, 190, 320)[grupo]))
                if rng.random() < .25:
                    tabelas['multas_impostos.csv'].append(dict(id_veiculo=vid, data=f'{periodo}-21',
                        tipo='multas', valor=rng.choice([130.16, 195.23, 293.47])))
                # 30 amostras mensais por veículo; não representam monitoramento contínuo.
                for t in range(30):
                    vel = round(rng.uniform(*[(15, 65), (25, 95), (60, 105)][grupo]), 1)
                    rpm = rng.randint(*[(900, 2900), (1100, 3000), (1100, 2400)][grupo])
                    temp = round(rng.uniform(82, 100), 1)
                    nivel = round(rng.uniform(20, 95), 1)
                    if rng.random() < (.16 if ruim else .025):
                        evento = rng.randrange(4)
                        if evento == 0: temp = round(rng.uniform(106, 120), 1)
                        elif evento == 1: rpm = rng.randint(3501, 4300)
                        elif evento == 2: nivel = round(rng.uniform(5, 14), 1)
                        else: vel = round(rng.uniform(111, 125), 1)
                    hora = datetime.fromisoformat(f'{periodo}-01T08:00:00') + timedelta(days=t % 25, minutes=t * 2)
                    tabelas['telemetria_esp32.csv'].append(dict(id_veiculo=vid,
                        timestamp=hora.isoformat(timespec='seconds'), velocidade=vel, rpm=rpm,
                        temperatura=temp, nivel_combustivel=nivel, anomalia=anomalia(vel, rpm, temp, nivel),
                        simulado=1, origem_leitura='gerador_python'))

    gabarito = []
    def alterar(nome, indice, campo, novo, classe, acao):
        registro = tabelas[nome][indice]
        antigo = registro[campo]
        registro[campo] = novo
        gabarito.append(dict(codigo=f'INC-{len(gabarito)+1:03d}', arquivo=nome,
            registro_1base=indice+1, campo=campo, tipo=classe, antes=antigo, depois=novo,
            id_veiculo=registro.get('id_veiculo',''), acao_esperada=acao))
    alterar('combustivel.csv', 0, 'valor_reais', -100, 'valor_negativo', 'sinalizar ou descartar; nao usar abs')
    alterar('combustivel.csv', 1, 'litros', -15, 'litros_negativos', 'sinalizar ou descartar')
    alterar('manutencao.json', 0, 'valor', '', 'obrigatorio_vazio', 'sinalizar ou descartar; nao imputar zero')
    alterar('pedagios.txt', 0, 'id_veiculo', 'VEIC-999', 'veiculo_inexistente', 'quarentena ate identificar veiculo')
    alterar('multas_impostos.csv', 0, 'data', '2026-02-30', 'data_impossivel', 'sinalizar ou descartar; nao inventar data')
    alterar('km_mensal.csv', 0, 'km_rodados', 0, 'km_zero_com_combustivel', 'sinalizar indicador indefinido; nao dividir por zero')
    alterar('combustivel.csv', 4, 'id_veiculo', '', 'obrigatorio_vazio', 'sinalizar ou descartar')
    alterar('combustivel.csv', 8, 'id_veiculo', 'veic-1', 'id_nao_padronizado', 'corrigir para VEIC-001 antes de validar cadastro')
    alterar('multas_impostos.csv', 1, 'tipo', 'Impostos e taxas', 'categoria_nao_padronizada', 'normalizar para impostos')
    alterar('telemetria_esp32.csv', 0, 'nivel_combustivel', 130, 'fora_de_faixa', 'sinalizar leitura invalida, diferente de anomalia operacional')
    for nome, indice in [('combustivel.csv', 12), ('manutencao.json', 4), ('telemetria_esp32.csv', 40)]:
        copia = tabelas[nome][indice].copy()
        tabelas[nome].append(copia)
        gabarito.append(dict(codigo=f'INC-{len(gabarito)+1:03d}', arquivo=nome,
            registro_1base=len(tabelas[nome]), campo='registro_inteiro', tipo='duplicado',
            antes=f'copia do registro {indice+1}', depois='duplicata exata',
            id_veiculo=copia['id_veiculo'], acao_esperada='manter uma ocorrencia e registrar descarte da copia'))
    for nome, rows in tabelas.items():
        path = bruto / nome
        if nome.endswith('.json'):
            path.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        elif nome.endswith('.txt'):
            with path.open('w', encoding='utf-8', newline='') as arq:
                writer = csv.DictWriter(arq, fieldnames=list(rows[0]), delimiter=';')
                writer.writeheader(); writer.writerows(rows)
        else:
            salvar_csv(path, rows)
    # Arquivo lateral: nao entra na soma de custos e nunca deve virar atributo do modelo.
    salvar_csv(bruto / 'rotulos_simulacao.csv', rotulos)
    salvar_csv(docs / 'gabarito_inconsistencias.csv', gabarito)
    manifesto = dict(seed=SEED, periodos=PERIODOS, veiculos=36, rotulos_ineficientes=9,
        natureza='100% sintetico; nenhuma leitura Wokwi capturada nesta entrega',
        arquivos={p.name: dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
            registros=len(rotulos) if p.name=='rotulos_simulacao.csv' else len(tabelas[p.name]))
            for p in sorted(bruto.iterdir()) if p.name in tabelas or p.name=='rotulos_simulacao.csv'})
    (docs / 'manifesto_dados.json').write_text(json.dumps(manifesto, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(f'Gerados 36 veiculos, 216 veiculo-meses e {len(gabarito)} casos documentados em {raiz.resolve()}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destino', type=Path, default=Path(__file__).resolve().parents[2],
                        help='Raiz de saida; o comando sobrescreve os arquivos gerados nesse destino.')
    gerar(parser.parse_args().destino)
