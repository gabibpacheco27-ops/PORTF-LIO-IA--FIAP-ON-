"""Combina uma captura verdadeira do simulador com a base sintética, em outro arquivo."""
import argparse
import csv
from datetime import datetime
from pathlib import Path
from gerar_dados_simulados import anomalia, salvar_csv


def combinar(captura, base, saida):
    if saida.resolve() in (base.resolve(), captura.resolve()):
        raise ValueError('A saída deve ser diferente das entradas para preservar os dados brutos.')
    leituras = []
    with captura.open(encoding='utf-8-sig') as arq:
        for linha in arq:
            if not linha.startswith('VEIC-'):
                continue  # Ignora cabeçalho e mensagens de inicialização.
            campos = next(csv.reader([linha]))
            if len(campos) != 9:
                raise ValueError(f'Linha serial inválida: {linha!r}')
            vid, data, vel, rpm, temp, nivel, flag, simulado, origem = campos
            datetime.fromisoformat(data)
            if vid != 'VEIC-007':
                raise ValueError('Captura esperada para VEIC-007; ajuste o importador se mudar o firmware.')
            valores = float(vel), int(rpm), float(temp), float(nivel)
            if not (0 <= valores[0] <= 160 and 0 <= valores[1] <= 5000 and
                    60 <= valores[2] <= 140 and 0 <= valores[3] <= 100):
                raise ValueError('Leitura fora das faixas dos potenciômetros.')
            if int(flag) != anomalia(*valores) or simulado != '1' or origem != 'wokwi_serial':
                raise ValueError('Flag ou procedência inconsistente.')
            leituras.append(dict(zip(['id_veiculo','timestamp','velocidade','rpm','temperatura',
                'nivel_combustivel','anomalia','simulado','origem_leitura'], campos)))
    if not leituras:
        raise ValueError('Nenhuma leitura encontrada. Cole a saída real do Monitor Serial no arquivo.')
    with base.open(encoding='utf-8') as arq:
        sinteticas = list(csv.DictReader(arq))
    chaves = set()
    unicas = []
    for row in leituras:
        chave = tuple(row.values())
        if chave not in chaves:
            unicas.append(row)
            chaves.add(chave)
    saida.parent.mkdir(parents=True, exist_ok=True)
    salvar_csv(saida, sinteticas + unicas)
    print(f'{len(unicas)} leituras Wokwi adicionadas; base original preservada.')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--captura', type=Path, required=True)
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--saida', type=Path, required=True)
    a = p.parse_args()
    combinar(a.captura, a.base, a.saida)
