"""Executa o fluxo completo da Sprint 2 — Calculadora de Redução de Custos de Frota (Sem Parar).

    arquivos brutos (CSV/TXT/JSON) -> ingestão -> normalização -> verificações de qualidade
    -> base integrada -> indicadores e benchmark -> gap de eficiência
    -> diagnóstico por regras -> modelo supervisionado -> comparação regras x modelo

Uso (na pasta do projeto):
    python main.py

Todos os dados são simulados (ver docs/CONTRATO_DADOS.md). Nenhum dado real de cliente.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

from src.benchmark_gap import executar_analise
from src.diagnostico_regras import gerar_diagnosticos
from src.ingestao import carregar_dados_brutos
from src.modelo import executar_modelo
from src.normalizacao import normalizar_dados
from src.qualidade import validar_e_integrar

RAIZ = Path(__file__).resolve().parent
RAW = RAIZ / "data" / "raw"
PROCESSED = RAIZ / "data" / "processed"
SAIDAS = RAIZ / "outputs"
ASSETS = RAIZ / "assets"
TELEMETRIA_ORIGINAL = RAIZ / "data" / "raw" / "telemetria_esp32.csv"
TELEMETRIA_COMBINADA = RAIZ / "data" / "complementares" / "telemetria_esp32_com_wokwi.csv"


def etapa(numero: int, titulo: str) -> None:
    print(f"\n[{numero}/6] {titulo}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--telemetria", choices=["combinada", "original"], default="combinada",
        help="combinada (padrão): telemetria sintética + 9 leituras capturadas no Wokwi; "
             "original: apenas a telemetria sintética. Nunca se usam os dois ao mesmo tempo.",
    )
    args = parser.parse_args()
    caminho_tel = TELEMETRIA_COMBINADA if args.telemetria == "combinada" else TELEMETRIA_ORIGINAL

    print("=" * 70)
    print("SEM PARAR - SPRINT 2 - fluxo completo (dados simulados)")
    print("=" * 70)

    etapa(1, "Ingestão dos arquivos brutos (CSV, TXT e JSON)")
    print(f"    Telemetria: {caminho_tel.relative_to(RAIZ)}")
    dfs_brutos = carregar_dados_brutos(RAW, PROCESSED, caminho_telemetria=caminho_tel)
    for nome, df in dfs_brutos.items():
        print(f"    {nome:<16} {len(df):>6} registros")

    etapa(2, "Normalização (IDs, categorias, tipos numéricos)")
    dfs_norm, inconsistencias_iniciais = normalizar_dados(dfs_brutos)
    print(f"    {len(inconsistencias_iniciais)} ajustes de padronização registrados")

    etapa(3, "Verificações de qualidade e integração da base")
    custos, base, relatorio = validar_e_integrar(dfs_norm, inconsistencias_iniciais)
    PROCESSED.mkdir(parents=True, exist_ok=True)
    custos.to_csv(PROCESSED / "custos_padronizados.csv", index=False)
    base.to_csv(PROCESSED / "base_integrada.csv", index=False)
    relatorio.to_csv(PROCESSED / "relatorio_inconsistencias.csv", index=False)
    print(f"    {len(custos)} lançamentos de custo | base integrada {base.shape[0]} linhas x {base.shape[1]} colunas")
    print(f"    {len(relatorio)} inconsistências registradas -> data/processed/relatorio_inconsistencias.csv")
    print(relatorio["acao_tomada"].value_counts().to_string(header=False))

    etapa(4, "Indicadores, benchmark por grupo e gap de eficiência")
    analise = executar_analise(
        PROCESSED / "base_integrada.csv", PROCESSED / "custos_padronizados.csv", SAIDAS, ASSETS
    )
    print(f"    Grupos de comparação: {analise['benchmark_grupos']['grupo_comparacao'].nunique()}")
    print("    Maiores gaps de custo/km (top 5 veículos):")
    print(analise["ranking_veiculos"].head(5).to_string(index=False))

    etapa(5, "Diagnóstico por regras de negócio")
    mensal, resumo = gerar_diagnosticos(SAIDAS / "gaps_veiculo_periodo.csv", SAIDAS)
    print("    Diagnóstico por veículo:")
    print(resumo["diagnostico"].value_counts().to_string(header=False))

    etapa(6, "Modelo supervisionado (árvore de decisão) e comparação com as regras")
    res = executar_modelo(
        SAIDAS / "indicadores_veiculo_periodo.csv",
        PROCESSED / "base_integrada.csv",
        SAIDAS / "diagnostico_regras_mensal.csv",
        SAIDAS,
        ASSETS,
    )
    comp = res["comparacao_regras"]
    print(f"    Treino: {res['treino']['id_veiculo'].nunique()} veículos | Teste: {res['teste']['id_veiculo'].nunique()} veículos")
    print(f"    Acurácia treino: {res['acc_treino']:.1%} | teste: {res['acc_teste']:.1%}")
    print(f"    Matriz de confusão (teste): {res['matriz'].tolist()}")
    print(f"    Concordância regras x modelo: {comp['concordancia']:.1%} em {comp['n_comparadas']} linhas")
    pd.set_option("display.width", 160)
    print("    Exemplos de acertos:")
    print(res["exemplos_acertos"].to_string(index=False))
    if len(res["exemplos_erros"]):
        print("    Exemplos de erros:")
        print(res["exemplos_erros"].to_string(index=False))
    else:
        print("    Nenhum erro nesta divisão de teste. Erros em outras divisões por veículo (exemplos):")
        print(res["exemplos_erros_outras_divisoes"].to_string(index=False))

    print("\nConcluído. Resultados em outputs/, gráficos em assets/, base em data/processed/.")
    print("Aviso: dados simulados; os resultados não valem para uma frota real.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
