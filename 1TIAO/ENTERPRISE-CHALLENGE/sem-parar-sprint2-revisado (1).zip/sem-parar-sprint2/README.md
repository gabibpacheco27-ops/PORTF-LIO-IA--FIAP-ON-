# Calculadora de Redução de Custos de Frota — Sem Parar Empresas — Sprint 2

**Etapa: Inteligência e Diagnóstico.** Neste repositório, custos de frota que estavam em arquivos separados (combustível, manutenção, pedágio, multas e impostos) são lidos, padronizados, verificados, comparados com um benchmark e diagnosticados por regras e por um modelo de Machine Learning introdutório.

> **Dados 100% simulados.** Não há dados reais de clientes da Sem Parar Empresas nem senhas neste repositório. Frota, custos, telemetria e rótulos foram gerados pelo grupo para demonstração (ver [Natureza dos dados](#natureza-dos-dados)).

- **Vídeo demonstrativo (YouTube, não listado):** [Assistir à demonstração](https://youtu.be/hlGBrp3aKME)
- **Projeto Wokwi (ESP32, MicroPython):** https://wokwi.com/projects/480683672811316225
- **Participação no prêmio:** O grupo deseja concorrer ao prêmio de melhor projeto Sem Parar.

## Integrantes

| Integrante | Nome | RM | Responsabilidade |
|---|---|---|---|
| 1 | Gabriela Pacheco | RM575120 | Telemetria ESP32 no Wokwi, anomalias e geração dos dados simulados |
| 2 | Leonardo Kenji | RM575829 | Ingestão, normalização, verificações de qualidade e base integrada |
| 3 | Gabriel Pietrobon | RM574967 | Indicadores, benchmark, gap de eficiência e diagnóstico por regras |
| 4 | Raila Cruz | RM576112 | Modelo de Machine Learning, integração do protótipo, repositório, README e vídeo |

## Evolução desde a Sprint 1

**Sprint 1 (planejamento, sem protótipo):** compreensão do problema dos custos de frota dispersos em diferentes fontes, seleção das User Stories, organização dos dados necessários e arquitetura planejada da calculadora.

**Sprint 2 (esta entrega):** o planejamento virou um fluxo funcional e reproduzível com um único comando (`python main.py`):

1. gerador de dados simulados com inconsistências e ineficiências plantadas de propósito;
2. ESP32 simulado no Wokwi produzindo leituras e sinalizando anomalias;
3. ingestão de CSV, TXT e JSON e normalização para um padrão único;
4. verificações de qualidade com relatório do que foi corrigido, descartado ou sinalizado;
5. benchmark por grupos comparáveis e gap de eficiência por veículo e por categoria;
6. diagnóstico por regras de negócio;
7. modelo supervisionado introdutório e comparação descritiva com as regras.

**Fica para a Sprint 3:** estimativa de economia em reais e motor de recomendações. Não estão implementados aqui.

## Como executar

Requisitos: Python 3.10 ou superior.

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows   (Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt
python main.py
```

O `main.py` lê os arquivos de `data/raw/`, grava a base integrada e o relatório de inconsistências em `data/processed/`, as tabelas em `outputs/` e os gráficos em `assets/`. A execução leva alguns segundos e usa semente fixa, então o resultado é o mesmo a cada vez.

Telemetria: por padrão o fluxo usa `data/complementares/telemetria_esp32_com_wokwi.csv` (telemetria sintética **mais** 9 leituras capturadas no Wokwi). Para usar somente a telemetria sintética: `python main.py --telemetria original`. Nunca se usam os dois arquivos ao mesmo tempo, para não duplicar leituras.

Testes das regras de diagnóstico: `python -m unittest discover -s tests -p 'teste_*.py' -v`.

## Estrutura do repositório

```
main.py                 fluxo completo (ingestão -> modelo)
requirements.txt
src/
  ingestao.py           lê CSV, TXT e JSON e marca a origem de cada registro
  normalizacao.py       padroniza IDs de veículo, categorias e tipos numéricos
  qualidade.py          verificações de consistência e integração da base
  benchmark_gap.py      indicadores, benchmark por grupo, gaps e gráficos
  diagnostico_regras.py classificação por regras (eficiente / atenção / ineficiente)
  modelo.py             árvore de decisão, avaliação e comparação com as regras
data/
  raw/                  dados brutos de entrada (não são alterados)
  complementares/       telemetria combinada com as leituras do Wokwi
  processed/            base integrada, custos padronizados, relatório e log
outputs/                tabelas de benchmark, gaps, diagnósticos e resultados do modelo
assets/                 gráficos e diagrama da arquitetura
wokwi/                  firmware MicroPython, circuito (diagram.json) e capturas seriais
telemetria/             gerador dos dados simulados e importador da captura serial
docs/                   contrato dos dados, gabarito de inconsistências, evidências, roteiro do vídeo
notebooks/              notebook da análise de benchmark
tests/                  testes das regras de diagnóstico
```

## Arquitetura e fluxo de processamento

![Fluxo de processamento](assets/08_arquitetura_fluxo.png)

Em laranja, as entradas **simuladas**. Em verde, o que está **funcional** e executa no `main.py`. O ESP32 é simulado no Wokwi (um único veículo, relógio fictício): o código é real, mas o circuito e as leituras não vêm de um veículo físico.

| Etapa | Situação |
|---|---|
| Geração dos dados de entrada | Simulada (gerador com semente fixa) |
| Telemetria do ESP32 | Simulada (Wokwi + amostras geradas) |
| Ingestão, normalização, qualidade, benchmark, gap, regras, modelo | Funcional |
| Estimativa de economia e recomendações | Não implementado (Sprint 3) |

## Natureza dos dados

- **Origem:** tudo foi gerado por `telemetria/gerar_dados_simulados.py` (semente 20261114). Placas `SIM-xxxx`, preços e impostos são fictícios e não representam cotações, alíquotas oficiais ou benchmarks de mercado.
- **Frota:** 36 veículos em 3 perfis (12 automóveis leves urbanos, 12 utilitários de uso misto e 12 caminhões pesados rodoviários), de maio a outubro de 2026, 216 linhas veículo/mês.
- **Inconsistências plantadas:** 13 casos documentados em `docs/gabarito_inconsistencias.csv`, para demonstrar as verificações de qualidade.
- **Ineficiências plantadas:** 9 veículos (3 de cada perfil) com consumo menor e manutenção corretiva extra. A marcação fica em `data/raw/rotulos_simulacao.csv`, separada das transações.
- **Telemetria:** 30 amostras por veículo/mês, não uma série contínua. Não serve para estimar tempo de condução nem consumo.
- **Custo total:** soma só das categorias disponíveis (combustível, manutenção, pedágio, multas e impostos). Não é TCO (sem depreciação, seguro ou salários).

Contrato completo dos arquivos e campos: [`docs/CONTRATO_DADOS.md`](docs/CONTRATO_DADOS.md).

## Padrão de dados

Arquivos de entrada (`data/raw/`): `cadastro_frota.csv`, `combustivel.csv`, `manutencao.json`, `pedagios.txt` (separador `;`), `multas_impostos.csv`, `km_mensal.csv`, `telemetria_esp32.csv` e `rotulos_simulacao.csv`.

Saídas padronizadas (`data/processed/`):

- `custos_padronizados.csv`: `id_veiculo, periodo (AAAA-MM), categoria, valor_reais, litros, km, origem_arquivo`. Categorias: combustivel, manutencao, pedagio, multas, impostos, outros.
- `base_integrada.csv`: uma linha por veículo e mês, com cadastro, km, custos por categoria, litros, resumo da telemetria (leituras, anomalias, médias), rótulo de simulação e os indicadores `custo_total`, `custo_por_km` e `consumo_km_l`.
- `relatorio_inconsistencias.csv`: cada problema encontrado e a ação tomada.
- `log_processamento.txt`: arquivos lidos e quantidade de registros.

## Verificações de qualidade

O `relatorio_inconsistencias.csv` registra 13 ocorrências, **todas as 13 do gabarito do Integrante 1 foram localizadas**. Ação tomada: 2 corrigidas, 9 descartadas e 2 sinalizadas.

| Verificação | Tratamento |
|---|---|
| ID fora do padrão (`veic-1`) | Corrigido para `VEIC-001` |
| Categoria fora do padrão (`Impostos e taxas`) | Normalizada para `impostos` |
| Valor ou litros negativos | Descartado; não se usa valor absoluto |
| Campo obrigatório vazio (ID, valor) | Descartado; não se imputa zero |
| Veículo inexistente no cadastro (`VEIC-999`) | Descartado (quarentena) |
| Data impossível (`2026-02-30`) | Descartado; não se inventa data |
| Registro duplicado exato | Mantida a primeira ocorrência |
| Nível de combustível 130% | Sinalizado como falha de sensor |
| `km = 0` com abastecimento | Sinalizado; custo/km e consumo ficam indefinidos, nunca zero |

Observação: com a telemetria combinada, as duas ocorrências de telemetria citam o arquivo `telemetria_esp32_com_wokwi.csv` (e não `telemetria_esp32.csv`) na coluna `arquivo`. A posição do registro é a mesma.

## Benchmark e gap de eficiência

**Grupos de comparação:** `tipo + porte + perfil_uso`, o que gera 3 grupos de 12 veículos. Um caminhão pesado rodoviário não é comparado com um automóvel leve urbano.

**Indicadores (por veículo e mês):** custo por km = custos válidos do mês / km do mês; consumo (km/L) = km do mês / litros válidos; participação da categoria (%) = custo da categoria / custo total.

**Benchmark:** mediana do grupo no mesmo mês (também média, Q1 e Q3). Medianas consolidadas:

| Grupo | Mediana custo/km | Mediana consumo |
|---|---:|---:|
| Automóvel leve urbano | R$ 0,7663 | 10,88 km/L |
| Utilitário médio misto | R$ 0,9935 | 7,90 km/L |
| Caminhão pesado rodoviário | R$ 2,3807 | 2,99 km/L |

**Gap:** `gap = custo/km do veículo − mediana do grupo no mês`, em R$/km e em %. Os gaps por categoria usam o custo da categoria por km. Rankings completos em `outputs/ranking_maiores_gaps_veiculos.csv` e `outputs/ranking_maiores_gaps_categorias.csv`. Os cinco maiores gaps médios de custo/km: VEIC-007 (+83,4%), VEIC-027 (+74,5%), VEIC-015 (+72,2%), VEIC-003 (+60,9%) e VEIC-011 (+59,3%).

Gráficos em `assets/` (boxplot de custo/km por grupo, ranking de gaps, participação das categorias, correlação e evolução mensal). Mais detalhes em [`docs/secao_pdf_integrante3.md`](docs/secao_pdf_integrante3.md).

## Diagnóstico por regras de negócio

Regra aplicada ao gap percentual de custo/km (`src/diagnostico_regras.py`, com `if/elif`):

| Nível | Critério |
|---|---|
| Eficiente | gap ≤ 10% |
| Atenção | 10% < gap ≤ 25% |
| Ineficiente | gap > 25% |
| Dados insuficientes | custo/km ou benchmark indisponível |

Os limites são **didáticos**, escolhidos para separar uma folga normal de variação (até 10%) de um desvio claro (acima de 25%). Não são especificações da Sem Parar e devem ser recalibrados com dados reais.

Resultado por veículo (média dos 6 meses): 27 eficientes e 9 ineficientes. Resultado mensal: 153 eficientes, 53 ineficientes, 9 em atenção e 1 com dados insuficientes (VEIC-001 em 2026-05, com km = 0).

## Telemetria ESP32 e detecção de anomalias

O firmware (`wokwi/main.py`, MicroPython, ESP32 DevKitC V4) lê quatro entradas analógicas a cada 2 segundos e imprime no Monitor Serial a linha `id_veiculo,timestamp,velocidade,rpm,temperatura,nivel_combustivel,anomalia,simulado,origem_leitura`. A anomalia é sinalizada por `if/else` e pelo LED:

| Variável | Limite de anomalia |
|---|---|
| Velocidade | acima de 110 km/h |
| Rotação | acima de 3.500 rpm |
| Temperatura | acima de 105 °C |
| Nível de combustível | abaixo de 15% |

Os quatro alertas foram testados um a um no Wokwi (LED aceso, flag 1) e a recuperação final trouxe flag 0 (ver `docs/TESTES_ALERTAS.md` e os prints em `docs/evidencias/`). As leituras exportadas estão em `wokwi/leituras_exportadas_wokwi.csv` e entram na base pela telemetria combinada (9 leituras do VEIC-007 em outubro). O circuito está em `wokwi/diagram.json`.

## Modelo supervisionado introdutório

- **Pergunta:** o veículo, em um dado mês, é eficiente (0) ou ineficiente (1)?
- **Algoritmo:** árvore de decisão (scikit-learn), profundidade máxima 3, semente 42.
- **Rótulo:** `ineficiente_real`, a condição que o simulador plantou nos 9 veículos (arquivo lateral `data/raw/rotulos_simulacao.csv`). O rótulo **não vem de medição real**.
- **Atributos:** quanto o consumo está abaixo da mediana do grupo (%), participação da manutenção no custo (%), km rodados, idade do veículo, número de anomalias de telemetria e custo de multas. **Ficam de fora** `ineficiente_real`, `motivo`, IDs, placa, o custo por km e o gap de custo por km (base das regras de negócio).
- **Consumo relativo ao grupo:** o km/L absoluto mistura perfis muito diferentes (automóvel ~11 km/L, caminhão ~3 km/L). Por isso o modelo usa o consumo em relação à mediana do grupo, que vem do benchmark e não usa o rótulo. Foi uma escolha pela interpretabilidade: o km/L absoluto deu acurácia equivalente, mas uma árvore mais difícil de explicar.
- **Treino e teste por veículo:** 27 veículos (161 linhas) para treino e 9 veículos (54 linhas) para teste, sorteados com a proporção de ineficientes mantida. Os seis meses de um mesmo veículo ficam sempre do mesmo lado. Uma linha com `km = 0` (consumo indefinido) fica fora do modelo.

**Resultado:**

| Medida | Valor |
|---|---|
| Acurácia no treino | 100% |
| Acurácia no teste (9 veículos, 54 linhas) | 100% (42 eficientes e 12 ineficientes classificados corretamente) |
| Acurácia em 20 divisões diferentes por veículo (informativo) | média 97,8%, mínima 85,2%, máxima 100% |

**Regra aprendida pela árvore (divisão principal):** se o consumo está mais de 14,4% abaixo da mediana do grupo, o veículo é ineficiente; caso contrário, se a manutenção passa de 24,5% do custo, também é ineficiente; nos demais casos é eficiente. O consumo relativo tem importância 0,91 e a manutenção 0,09; anomalias de telemetria, idade, km e multas não foram usadas.

**Interpretação.** O teste principal não teve nenhum erro, mas isso deve ser lido com cautela: são só 9 veículos de teste e os dados são sintéticos. O gerador planta, nos veículos ineficientes, consumo menor e manutenção maior, então esses atributos separam bem as classes. O modelo mede o reconhecimento desses padrões sintéticos e **não** a capacidade de acertar em uma frota real.

Ao repetir a divisão com outras sementes aparecem erros (24 em 20 divisões, listados em `outputs/modelo_erros_outras_divisoes.csv`). Exemplos:

- VEIC-029 (eficiente, caminhão) em 2026-07 foi previsto como ineficiente: o consumo estava 13,4% abaixo da mediana do grupo e, naquela divisão, a árvore aprendeu um limite de 11,1%.
- VEIC-019 (ineficiente) em 2026-06 foi previsto como eficiente: consumo 15,5% abaixo da mediana, mas a árvore daquela divisão usou o limite de 16,6%.
- Metade dos erros (12) é do VEIC-027, ineficiente, com consumo 31% a 46% abaixo da mediana. Em 4 das 20 divisões a árvore, treinada com poucos veículos, aprendeu regras que classificam meses desse caminhão como eficientes (na divisão de semente 4, por exemplo: consumo acima de 11% com manutenção até 12,8% do custo = eficiente). É um sinal de ajuste excessivo a uma amostra pequena.

Arquivos: `outputs/modelo_resumo.txt` (regras, matriz, importâncias), `outputs/modelo_previsoes_teste.csv`, `assets/06_matriz_confusao_modelo.png` e `assets/07_importancia_atributos_modelo.png`.

## Regras versus modelo (linhas de teste)

| Regra \ Modelo | Eficiente | Ineficiente |
|---|---:|---:|
| Eficiente | 40 | 0 |
| Atenção | 2 | 0 |
| Ineficiente | 0 | 12 |

Regras e modelo coincidem em 52 das 54 linhas (96,3%, contando "atenção" como "não eficiente"). As duas divergências são do mesmo veículo (VEIC-009, em 2026-06 e 2026-09): o gap de custo/km ficou em 12% e 15%, logo acima do limite de 10%, e a regra marcou "atenção"; o modelo, que olha o consumo e a manutenção, previu eficiente, e o rótulo de simulação também é eficiente. Ou seja, a faixa de atenção é um efeito do limite escolhido e não uma ineficiência plantada. Em relação ao rótulo de simulação, as regras acertam 96,3% e o modelo 100% nessas linhas. Em todos os 12 casos que a regra chamou de "ineficiente", o modelo concordou. Arquivos: `outputs/comparacao_regras_modelo.csv` e `outputs/comparacao_divergencias.csv`.

## Rastreabilidade e cuidados com os dados

- Os arquivos de `data/raw/` são mantidos intactos; todo o tratamento acontece em memória e grava em `data/processed/`.
- Cada registro lido leva a coluna `origem_arquivo` e a posição no arquivo. O `log_processamento.txt` registra quais arquivos foram processados e quantos registros cada um tinha.
- `data/raw/telemetria_esp32.csv` e `data/complementares/telemetria_esp32_com_wokwi.csv` têm origem no mesmo gerador; o combinado só acrescenta as 9 leituras capturadas no Wokwi. O arquivo original da captura está em `wokwi/captura_serial.txt`.
- O manifesto `docs/manifesto_dados.json` descreve os arquivos gerados. Não há dados reais de clientes, senhas ou credenciais.

## Limitações

- Frota, custos, telemetria e rótulos são simulados; o benchmark é interno à frota simulada e não é referência de mercado.
- Poucos veículos (36), 6 meses e apenas 9 ineficientes: a avaliação do modelo é instável (ver a variação entre divisões).
- O rótulo do modelo vem do simulador; não há validação com especialista em frotas.
- Limites do diagnóstico por regras e das anomalias do ESP32 são didáticos.
- A telemetria é amostral (30 leituras por veículo/mês) e o Wokwi representa um único veículo.
- Custo total sem depreciação, seguros e salários; sem estimativa de economia em reais.

## Próximos passos (Sprint 3)

Estimar a economia em reais ao levar cada veículo ao benchmark do grupo, gerar recomendações por categoria de custo e recalibrar limites com dados reais. As responsabilidades estão no Kanban.
