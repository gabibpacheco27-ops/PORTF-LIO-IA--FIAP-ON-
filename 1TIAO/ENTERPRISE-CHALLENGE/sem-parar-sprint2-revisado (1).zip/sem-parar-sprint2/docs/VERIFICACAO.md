# Verificação realizada nesta entrega

- Os dois scripts Python passaram pela verificação de sintaxe.
- O gerador foi executado duas vezes em pastas diferentes: os oito arquivos de dados coincidiram byte a byte.
- Confirmados 36 IDs únicos, três perfis com 12 veículos, 216 combinações de veículo/mês, 54 rótulos positivos e 162 negativos.
- Os 13 registros do gabarito foram conferidos contra os valores efetivamente gravados; as três duplicatas foram conferidas como cópias exatas.
- As flags de anomalia geradas foram verificadas contra os limites; igualdade e os quatro cruzamentos de limite foram testados na função Python.
- O importador foi testado com uma linha artificial de teste (não evidência Wokwi), gerando uma saída separada; captura sem leituras foi rejeitada.
- `diagram.json` passou pela leitura JSON. Isso não comprova pinos, compilação ou funcionamento visual no simulador.

Atualização: versão MicroPython executada no Wokwi, com leitura normal e alerta de temperatura verificados. A tentativa Arduino falhou na linkedição. Captura efetiva do simulador e prints anexados separadamente. Trello e módulos dos demais integrantes permanecem fora desta validação; os quatro alertas foram verificados no Wokwi.

O relatório de qualidade completo deve ser produzido pelo integrante 2, e a validação de indicadores, benchmark e modelo pelos integrantes 3 e 4. Os requisitos de telemetria foram conferidos com o edital oficial; os nomes de pastas do template devem ser alinhados na integração do grupo.


## Testes complementares concluídos

Os alertas de velocidade, rotação e combustível foram acionados individualmente no Wokwi, mantendo as demais grandezas normais. LED aceso e anomalia=1 observados em cada cenário; LED apagado e anomalia=0 após retorno à condição normal. Evidências 04 a 07 em docs/evidencias/. A captura completa está em wokwi/captura_serial_todos_alertas.txt e o CSV em wokwi/leituras_todos_alertas.csv. Esta atualização substitui as pendências de testes individuais descritas acima.
