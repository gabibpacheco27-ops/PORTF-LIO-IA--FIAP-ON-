# Desenvolvimento — Benchmark, gaps de eficiência e diagnóstico por regras

A etapa de benchmark utilizou os arquivos `base_integrada.csv` e `custos_padronizados.csv` produzidos pelo Integrante 2. A base contém 36 veículos ao longo de seis meses, de maio a outubro de 2026, totalizando 216 registros de veículo/período. Os dados são inteiramente simulados.

## Critério de comparação

Para evitar comparações inadequadas entre operações com características distintas, os grupos foram definidos pela combinação de tipo, porte e perfil de uso. Foram obtidos três grupos, cada um com 12 veículos: automóveis leves urbanos, utilitários médios de uso misto e caminhões pesados rodoviários. Cada veículo foi comparado somente aos demais integrantes do próprio grupo.

A referência de cada mês foi a mediana do grupo naquele mesmo período. Além da mediana, o benchmark apresenta média, primeiro quartil (Q1) e terceiro quartil (Q3) para custo por quilômetro e consumo. A mediana foi escolhida por ser menos sensível a valores extremos inseridos deliberadamente na simulação.

## Indicadores e gaps

O custo por quilômetro foi calculado pela soma dos custos padronizados do veículo no mês dividida pelos quilômetros rodados. O consumo foi calculado pela quilometragem mensal dividida pelos litros válidos de combustível. A participação percentual de cada categoria corresponde ao custo da categoria dividido pelo custo total válido do mesmo período.

O gap do custo/km foi calculado como a diferença entre o indicador do veículo e a mediana do grupo. O gap percentual corresponde a essa diferença dividida pela mediana de referência. Assim, um gap positivo indica custo por quilômetro acima da mediana do grupo. Para consumo, valores abaixo da mediana representam desempenho desfavorável. Os gaps por categoria foram calculados em R$/km e também em pontos percentuais de participação no custo. Quando uma categoria possui referência mediana igual a zero, o gap percentual não é calculado para evitar divisão por zero.

## Resultados obtidos

| Grupo | Média custo/km | Mediana custo/km | Q1 | Q3 | Mediana consumo |
|---|---:|---:|---:|---:|---:|
| Automóvel leve urbano | R$ 0,8817 | R$ 0,7663 | R$ 0,7042 | R$ 0,9958 | 10,8842 km/L |
| Utilitário médio misto | R$ 1,1232 | R$ 0,9935 | R$ 0,9453 | R$ 1,1607 | 7,8992 km/L |
| Caminhão pesado rodoviário | R$ 2,6818 | R$ 2,3807 | R$ 2,2002 | R$ 2,8720 | 2,9941 km/L |

O custo por quilômetro mediano dos caminhões foi superior ao dos automóveis e utilitários, mas isso não deve ser interpretado como ineficiência entre grupos: o caminhão pesado possui um perfil operacional diferente. A comparação de eficiência foi feita dentro de cada grupo.

A participação ponderada de combustível foi de 70,05% nos automóveis leves urbanos, 73,18% nos utilitários mistos e 83,58% nos caminhões pesados. A manutenção respondeu por 20,09%, 17,51% e 11,30%, respectivamente. Esses percentuais descrevem a composição dos custos disponíveis na base, não o custo total de propriedade, pois a simulação não contém depreciação, salários, seguros ou outras categorias não fornecidas.

O ranking dos maiores gaps médios de custo/km destacou VEIC-007 (+83,42%), VEIC-027 (+74,52%), VEIC-015 (+72,17%), VEIC-003 (+60,90%), VEIC-011 (+59,35%), VEIC-035 (+54,11%), VEIC-023 (+53,25%), VEIC-031 (+52,76%) e VEIC-019 (+51,04%). Todos foram comparados à mediana mensal do respectivo grupo.

## Diagnóstico por regras

O diagnóstico consolidado foi calculado pela média dos gaps percentuais mensais válidos de cada veículo. Foram adotados os seguintes limites didáticos: eficiente quando o gap é menor ou igual a 10%; atenção quando acima de 10% e até 25%; e ineficiente quando acima de 25%. Caso não exista custo/km ou referência válida, o status é “dados insuficientes”.

No resumo de seis meses, 27 veículos foram classificados como eficientes e 9 como ineficientes. Na visão mensal, foram 153 registros eficientes, 9 em atenção, 53 ineficientes e 1 com dados insuficientes. O caso de dados insuficientes ocorreu para VEIC-001 em maio de 2026, pois o registro de quilometragem foi zero apesar da existência de abastecimentos. O indicador foi mantido indefinido, sem divisão por zero ou substituição por zero artificial.

## Análise de correlação

Na matriz de Pearson, custo total e custo por km apresentaram correlação de 0,967; quilometragem e custo total, 0,912; custo por km e consumo, -0,895. A quantidade de anomalias de telemetria apresentou correlação de 0,281 com custo/km e de 0,429 com custo de manutenção. Essas relações são descritivas: o conjunto reúne três perfis operacionais simulados e não permite concluir que uma variável cause a outra.

## Limitações

A base é sintética, limitada a 36 veículos e seis meses. Os valores de referência são benchmarks internos da simulação, não benchmarks de mercado. O custo por km considera somente as categorias disponíveis nos arquivos padronizados. A telemetria também é simulada e composta por amostras discretas. Os limites de classificação são regras didáticas que precisariam de calibração com dados reais e participação da gestão de frota antes de qualquer uso operacional.

A rotina de benchmark e diagnóstico não utiliza `ineficiente_real` nem `motivo`, campos reservados como gabarito de simulação para a etapa de Machine Learning. O diagnóstico por regras é calculado exclusivamente a partir dos indicadores e da referência do grupo.

## Legendas sugeridas para as figuras

- **Figura 1 —** Distribuição do custo por quilômetro nos três grupos comparáveis. O gráfico evidencia que os níveis de custo variam conforme o perfil de uso, reforçando a necessidade de benchmarks separados.
- **Figura 2 —** Dez maiores gaps médios de custo por quilômetro. Valores positivos indicam custo acima da mediana do próprio grupo.
- **Figura 3 —** Participação das categorias no custo total de cada grupo. Combustível é a principal categoria nos três perfis.
- **Figura 4 —** Matriz de correlação de Pearson entre indicadores de custo, utilização e telemetria. As correlações não representam causalidade.
- **Figura 5 —** Evolução mensal da mediana de custo por quilômetro para cada grupo.
