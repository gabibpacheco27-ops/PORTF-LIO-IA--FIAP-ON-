# Contrato dos dados e integração

## Formatos e chaves

UTF-8, cabeçalho nos CSV/TXT, decimal com ponto, CSV separado por vírgula, TXT por ponto e vírgula. JSON: lista de objetos; `registro_1base` do gabarito é a posição nessa lista, não a linha física do arquivo. CSV/TXT: registro 1 é a primeira linha depois do cabeçalho.

Chaves: cadastro por `id_veiculo`; quilômetros e rótulos por `(id_veiculo, periodo)`; custos e telemetria têm várias linhas por chave mensal. IDs canônicos VEIC-001 a VEIC-036. Datas AAAA-MM-DD; período AAAA-MM; timestamp ISO com T, interpretado como UTC nesta POC. A data impossível é intencional.

| Arquivo | Campos | Granularidade |
|---|---|---|
| cadastro_frota.csv | id_veiculo, placa, tipo, porte, perfil_uso, ano | Um veículo |
| combustivel.csv | id_veiculo, data, litros, valor_reais | Resumo de abastecimento, quatro/mês |
| manutencao.json | id_veiculo, data, descricao, valor | Serviço preventivo/corretivo |
| pedagios.txt | id_veiculo;data;valor | Resumo mensal das passagens |
| multas_impostos.csv | id_veiculo, data, tipo, valor | Despesa de multa ou imposto |
| km_mensal.csv | id_veiculo, periodo, km_rodados | Km percorridos no mês, não odômetro |
| telemetria_esp32.csv | id_veiculo, timestamp, velocidade, rpm, temperatura, nivel_combustivel, anomalia, simulado, origem_leitura | Amostra de telemetria |
| rotulos_simulacao.csv | id_veiculo, periodo, ineficiente_real, motivo | Gabarito do ML, separado dos atributos |

As duas colunas extras da telemetria documentam sua procedência: `simulado=1` em todas as linhas; `origem_leitura=gerador_python` para dados gerados e `wokwi_serial` somente para captura efetiva do simulador. Mesmo uma captura Wokwi continua simulada. A captura efetiva está em wokwi/captura_serial.txt; as três linhas exportadas estão em wokwi/leituras_exportadas_wokwi.csv e no arquivo combinado em dados/complementares/.

Unidades: velocidade km/h, rotação rpm, temperatura °C, nível %, combustível L, distância km e valores R$. `anomalia` é 0 ou 1, calculada por OU dos quatro limites descritos no roteiro do circuito. Leitura fora da faixa física é defeito de qualidade, não diagnóstico mecânico.

Perfis: 12 automóveis leves urbanos, 12 utilitários de uso misto e 12 caminhões pesados rodoviários. `tipo` e `perfil_uso` permitem os grupos propostos pelo integrante 3. A frota é fixa durante seis meses. Os intervalos de km e consumo-base estão no gerador e são premissas didáticas.

## Integrante 2

1. Preserve entradas brutas. Acrescente `origem_arquivo` durante a ingestão.
2. Normalize IDs e categorias antes de consultar o cadastro. `veic-1` é VEIC-001, não veículo desconhecido. `Impostos e taxas` vira `impostos`.
3. Valide campos, datas, números e duplicatas. Consulte os 13 casos no gabarito. Alertas adicionais justificáveis podem existir: os 13 são casos plantados, não promessa de 13 linhas no relatório final.
4. `km=0` com abastecimento exige alerta; não transforme consumo ou CPK indefinidos em zero. Valores negativos plantados não são estornos legítimos. Não corrija com valor absoluto.
5. Agregue separadamente custos e litros por veículo/mês; telemetria por veículo/mês (contagem de amostras e anomalias); depois una com cadastro, km e rótulos. Unir tabelas transacionais diretamente multiplica linhas e custos.
6. Nunca some `km_mensal` repetido por categoria. Preserve os quilômetros uma única vez na base integrada, com uma linha por veículo/mês. Em custos padronizados, `km` pode ficar vazio nas transações; os indicadores usam a tabela mensal.
7. Não descarte silenciosamente: registre ação e motivo, inclusive para a data inválida e nível de combustível de 130%.

Saída de custos esperada: `id_veiculo,periodo,categoria,valor_reais,litros,km,origem_arquivo`. Categorias: `combustivel,manutencao,pedagio,multas,impostos,outros`. `manutencao.json` e `pedagios.txt` usam `valor`, que deve virar `valor_reais`. `outros` é aceito no padrão, mas não tem despesas neste conjunto.

## Integrantes 3 e 4

Consumo = km mensal / soma de litros válidos; CPK = soma de custos válidos / km mensal; participação = custo da categoria / custo total válido × 100. Categorias ausentes devem ser explicitadas. Os veículos plantados não precisam coincidir exatamente com o diagnóstico por regras: os rótulos representam uma condição geradora, e os dados têm ruído e erros de qualidade.

`ineficiente_real=1` para VEIC-003, 007, 011, 015, 019, 023, 027, 031 e 035 em todos os meses. O gerador reduz km/L e adiciona duas corretivas mensais a esses veículos. São 54 exemplos positivos e 162 negativos antes do tratamento. O rótulo está em arquivo lateral para não misturar referência de avaliação com transações.

Para ML, una o rótulo após montar a base mensal. Exclua dos atributos `ineficiente_real`, `motivo`, IDs, placa e qualquer dado auxiliar do gerador que revele a marcação. Separe treino/teste por veículo, mantendo os seis meses juntos. Se usar o rótulo do simulador, consumo e manutenção são atributos intencionalmente informativos, mas resultados medem reconhecimento de padrões sintéticos, não validade em frotas reais. Se usar rótulo derivado do gap, exclua a variável geradora e proxies que reconstruam diretamente a regra.
