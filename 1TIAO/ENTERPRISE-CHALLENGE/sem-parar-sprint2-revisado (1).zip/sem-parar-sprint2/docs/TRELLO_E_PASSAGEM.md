# Passagem para o grupo e conteúdo para o Trello

Não houve acesso ao quadro: cartões abaixo preparados para copiar. Nomes dos responsáveis devem ser substituídos pelos nomes do grupo.

## Concluído — Integrante 1

- Gerador Python sem dependências, seed fixa, 36 veículos e seis meses.
- Entradas CSV, JSON e TXT com documentação dos campos e da procedência.
- Consumo elevado e excesso de manutenção em nove veículos; rótulos separados.
- Treze casos de inconsistência com localização e ação esperada.
- Firmware e circuito preparados; roteiro de teste e importador serial.

## Em andamento — Integrante 1

- Versão MicroPython importada, executada e salva; revisar evidências de temperatura.
- Capturar leituras verdadeiras do simulador, exportar telemetria combinada.
- Link e prints de normal/temperatura salvos; evidências dos quatro alertas e da recuperação final disponíveis.
- Atualizar o próprio Trello e conferir a estrutura oficial de pastas com o integrante 4.

## A fazer — Integração da Sprint 2

- Integrante 2: ingestão e qualidade; conciliar relatório com gabarito; preservar brutos.
- Integrante 3: indicadores e benchmark por tipo/perfil; regras e gaps.
- Integrante 4: ML, integração, revisão do template, repositório, README e vídeo.
- Todos: confirmar edital oficial e executar o fluxo integrado do zero.

## Planejamento para Sprint 3 — confirmar com o grupo e edital

- Integrante 1: manter telemetria e documentar calibração dos limites e novas capturas.
- Integrante 2: manter o contrato, rastreabilidade e qualidade da base.
- Integrante 3: apoiar estimativas de economia e recomendações com hipóteses explícitas.
- Integrante 4: integrar evolução do protótipo e coordenar validação e entrega.

## Mensagem de passagem

A base sintética já pode ser usada. Leiam o contrato antes de unir os arquivos. As inconsistências são intencionais e estão no gabarito; a coluna ineficiente_real está em rotulos_simulacao.csv e não pode virar atributo do modelo. A base inicial vem do gerador Python. A captura Wokwi já está incorporada no arquivo combinado: usem dados/complementares/telemetria_esp32_com_wokwi.csv no lugar da telemetria inicial, sem ingerir os dois. Os prints mostram condição normal, os quatro alertas individuais e recuperação final.
