# Testes dos quatro alertas no Wokwi

Projeto: https://wokwi.com/projects/480683672811316225

Os valores abaixo foram lidos do Monitor Serial, com uma única condição anormal por teste.

| Alerta | Instante fictício | Velocidade km/h | Rotação rpm | Temperatura °C | Combustível % | Anomalia | LED |
|---|---|---|---|---|---|---|---|
| Velocidade | 2026-10-01T08:00:12 | 132.9 | 2199 | 95.2 | 58.7 | 1 | Aceso |
| Rotação | 2026-10-01T08:00:14 | 54.7 | 4153 | 95.2 | 58.7 | 1 | Aceso |
| Temperatura | 2026-10-01T08:00:04 | 54.7 | 2199 | 126.5 | 58.7 | 1 | Aceso |
| Combustível | 2026-10-01T08:00:16 | 54.7 | 2199 | 95.2 | 7.8 | 1 | Aceso |
| Recuperação final | 2026-10-01T08:00:18 | 54.7 | 2199 | 95.2 | 58.7 | 0 | Apagado |

As datas são do relógio fictício do firmware. O circuito é inteiramente simulado; os prints são capturas efetivas dessa execução, sem montagem ou alteração de resultados.
