# Nota para integração com o grupo

1. Os arquivos utilizados são as saídas efetivamente entregues pelo Integrante 2: `base_integrada.csv` e `custos_padronizados.csv`.
2. Os totais por categoria em `custos_padronizados.csv` foram reconciliados com as colunas `custo_*` de `base_integrada.csv`; as diferenças máximas foram inferiores a 0,00000000001 (ponto flutuante).
3. `ineficiente_real` e `motivo` não foram utilizados no benchmark nem na classificação por regras. Eles são mantidos como rótulos de simulação para o Integrante 4 avaliar o modelo.
4. O log de ingestão indica 6.481 linhas lidas de `telemetria_esp32.csv`. O Integrante 1 também entregou um arquivo combinado com as leituras Wokwi. O grupo deve confirmar se o Integrante 2 quis usar esse arquivo combinado; se sim, ele precisa regenerar a base integrada usando o combinado no lugar do original, sem somar os dois arquivos.
5. O registro de `VEIC-001` em `2026-05` tem `km_rodados=0` e litros abastecidos. Custo/km e consumo foram mantidos indefinidos; o diagnóstico mensal apresenta `dados_insuficientes` nesse período.
6. Os limites de diagnóstico são didáticos: gap de custo/km até 10% = eficiente; acima de 10% até 25% = atenção; acima de 25% = ineficiente. Devem ser justificados e não descritos como especificações oficiais da Sem Parar.
