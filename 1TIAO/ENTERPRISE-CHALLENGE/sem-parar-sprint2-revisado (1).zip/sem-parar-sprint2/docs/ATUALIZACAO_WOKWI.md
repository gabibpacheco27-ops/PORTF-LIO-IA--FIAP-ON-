# Atualização do circuito

Projeto atual: https://wokwi.com/projects/480683672811316225

O firmware atual usa MicroPython (`wokwi/main.py`) e ESP32 DevKitC V4. A versão Arduino anterior apresentou falha de linkedição nas bibliotecas do ESP32 (referências a uartGetEventQueue e app_main). A mudança de ambiente elimina a necessidade dessa compilação Arduino. A causa interna do compilador não foi comprovada.

Também foi corrigida a identificação da placa no circuito: o modelo DevKitC V4 usa os nomes numéricos de GPIO presentes nas conexões. O diagrama anterior usava outro modelo de placa, cujos nomes de pino não correspondiam a essas conexões. Essa correção elétrica é independente da falha de compilação.

As regras continuam iguais: temperatura >105 °C, rpm >3500, velocidade >110 km/h ou combustível <15%. Leituras a cada 2 segundos simulados, com relógio fictício, identificador VEIC-007 e procedência wokwi_serial.

A aba `main.py` do Wokwi é o firmware do ESP32, não o orquestrador Python do integrante 4. O script não roda no Python comum do computador: depende de machine.Pin e machine.ADC do MicroPython.

Para tirar prints, aguarde o boot terminar e aparecerem linhas iniciadas por VEIC-007. O navegador pode executar abaixo de 100% de velocidade, então dois segundos simulados podem demorar mais que dois segundos reais. Não reinicie enquanto aguarda.

## Resultado observado

Três leituras efetivamente capturadas do Monitor Serial:

| Instante fictício | Temperatura | Anomalia | LED observado |
|---|---|---|---|
| 08:00:02 | 95,2 °C | 0 | Apagado |
| 08:00:04 | 126,5 °C | 1 | Aceso |
| 08:00:06 | 95,2 °C | 0 | Apagado |

Velocidade 54,7 km/h, rotação 2.199 rpm e combustível 58,7% mantidos nesses testes. Os prints estão em docs/evidencias/. O cabeçalho foi recomposto em uma linha no CSV exportado porque o terminal o quebrou visualmente; os valores das três leituras foram preservados. O TXT mantém o texto observado no terminal, incluindo mensagens de boot disponíveis.

As três leituras foram combinadas com as 6.481 linhas da base sintética: a primeira versão complementar continha 6.484 linhas de dados; a versão atual, com os testes adicionais, contém 6.490. Não ingerir simultaneamente a base inicial e a combinada. Os alertas de rpm, velocidade e combustível foram testados individualmente na atualização seguinte, registrada abaixo.


## Testes complementares concluídos

Os alertas de velocidade, rotação e combustível foram acionados individualmente no Wokwi, mantendo as demais grandezas normais. LED aceso e anomalia=1 observados em cada cenário; LED apagado e anomalia=0 após retorno à condição normal. Evidências 04 a 07 em docs/evidencias/. A captura completa está em wokwi/captura_serial_todos_alertas.txt e o CSV em wokwi/leituras_todos_alertas.csv. Esta atualização substitui as pendências de testes individuais descritas acima.
