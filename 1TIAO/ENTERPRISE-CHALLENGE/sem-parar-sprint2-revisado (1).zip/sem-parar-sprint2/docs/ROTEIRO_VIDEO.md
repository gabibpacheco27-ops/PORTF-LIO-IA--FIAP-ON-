# Narração da demonstração · Sem Parar Sprint 2

O MP4 está sem áudio. Comece cada trecho no tempo indicado e faça uma pausa se terminar antes da próxima tela.

### 0:00–0:15 · Abertura

Oi, eu sou a Gabriela e vou apresentar a Sprint 2 do nosso projeto para o Challenge Sem Parar. A ideia é reunir os custos de uma frota e ajudar a identificar quais veículos estão gastando mais por quilômetro do que o esperado. Todos os dados são simulados.

### 0:15–0:42 · Telemetria no Wokwi

Na minha parte, simulamos um ESP32 no Wokwi para acompanhar velocidade, rotação, temperatura e nível de combustível. Nessa captura, a temperatura passou de 105 graus, o LED acendeu e o campo de anomalia mudou para um. Quando a leitura voltou ao normal, o alerta desligou. Também foram testados os alertas de velocidade, rotação e combustível. Nove leituras do Wokwi entraram na base junto com a telemetria sintética.

### 0:42–1:08 · Ingestão e qualidade

Agora, rodando o programa principal, a gente reúne os arquivos de combustível, manutenção, pedágios e outras fontes. O programa padroniza os dados e monta uma base de 36 veículos acompanhados ao longo de seis meses. Nessa execução, apareceram 13 inconsistências. Duas foram corrigidas, nove foram descartadas e duas ficaram sinalizadas para revisão.

### 1:08–1:36 · Benchmark e diagnóstico

Aqui a gente compara veículos de perfis semelhantes, porque um caminhão de estrada tem custos diferentes de um carro leve que roda na cidade. A barra mostra quanto cada veículo ficou acima da referência de custo por quilômetro do seu grupo. O veículo zero zero sete, por exemplo, ficou cerca de 83 por cento acima. Pela regra, até 10 por cento acima é eficiente, acima de 10 até 25 é atenção e acima de 25 é ineficiente.

### 1:36–2:09 · Modelo e comparação

Também treinamos uma árvore de decisão para classificar os veículos. O treino e o teste foram separados por veículo, assim os meses de um mesmo veículo ficam todos de um lado. No teste principal, o modelo acertou as 54 linhas de nove veículos. As regras e o modelo concordaram em 52 dessas linhas. Como os dados são simulados e a amostra é pequena, esse resultado é da demonstração. Em outras divisões de treino e teste, também houve erros.

### 2:09–2:23 · Encerramento

Com isso, a Sprint 2 entrega um fluxo que vai da leitura dos dados ao diagnóstico da frota. A próxima etapa é usar esse diagnóstico para estimar possíveis economias e recomendar ações para cada perfil de veículo.
