# Checklist de entrega — Sprint 2

## Antes de enviar
- [ ] Repositório **privado** no GitHub e convite enviado **só** a `fiap-tutoria` e aos integrantes (o convite precisa ser aceito em até 7 dias).
- [ ] Nomes, RMs e link do vídeo preenchidos no README (procurar por `[`).
- [ ] Decisão do grupo sobre o prêmio registrada no topo do README.
- [ ] Link do quadro Trello no README e quadro atualizado (entregue, pendente, responsabilidades da Sprint 3).
- [ ] `python main.py` roda do zero em outra máquina (ambiente virtual novo e `pip install -r requirements.txt`).
- [ ] Nenhuma senha ou dado real no repositório.
- [ ] Vídeo de até 5 minutos, com narração, publicado no YouTube como **Não listado**.
- [ ] Arquivo `.txt` do Portal contendo apenas o link do repositório.
- [ ] Depois da data limite, **não alterar mais** o repositório.

## Conferência com o edital
| Exigência | Onde está |
|---|---|
| Telemetria ESP32 (código, link Wokwi, imagem do circuito, CSV, evidências das anomalias) | `wokwi/`, `docs/evidencias/`, `docs/TESTES_ALERTAS.md` |
| Base integrada e verificações de qualidade (CSV padronizados, código, relatório de inconsistências e tratamento) | `data/processed/`, `src/ingestao.py`, `src/normalizacao.py`, `src/qualidade.py` |
| Modelo introdutório (código, atributos e rótulos, treino/teste, resultados) | `src/modelo.py`, `outputs/modelo_resumo.txt`, README |
| Organização e rastreabilidade (pastas, fontes, cuidados com dados simulados) | README, `docs/CONTRATO_DADOS.md`, `docs/manifesto_dados.json`, `data/processed/log_processamento.txt` |
| Protótipo executável (scripts, diagrama, instruções, exemplos de resultados) | `main.py`, `assets/08_arquitetura_fluxo.png`, README |
| Diagnóstico por regras e comparação com o modelo | `src/diagnostico_regras.py`, `outputs/diagnostico_regras*.csv`, `outputs/comparacao_*.csv`, README |
| Ingestão e normalização | `src/ingestao.py`, `src/normalizacao.py` |
| Benchmark e gap de eficiência (grupos, indicadores, ranking, análise) | `src/benchmark_gap.py`, `outputs/`, `assets/`, `notebooks/` |
| Kanban atualizado | Trello (link no README) |
| Vídeo | Link no README |
| README com a evolução desde a Sprint 1 | `README.md` |

## Pontos que o grupo precisa decidir
1. **Telemetria:** o `main.py` usa, por padrão, o arquivo combinado (sintética + 9 leituras do Wokwi), como o Integrante 1 recomendou. Os resultados principais (diagnóstico por regras, acurácia e comparação com o modelo) não mudaram em relação ao uso só da telemetria sintética; muda apenas o resumo de telemetria do VEIC-007 em 2026-10 (39 leituras e 11 anomalias, em vez de 30 e 7). Os arquivos entregues pelos Integrantes 2 e 3 foram gerados só com a telemetria original; no repositório final, usem os arquivos gerados pelo `main.py`.
2. **Prêmio ou sigilo:** o edital pede que, se o grupo quiser sigilo, isso seja declarado na primeira capa.
3. **Nomes das pastas:** conferir com o template da coordenação (https://github.com/CaiqueFiap-2026/TEMPLATE-TIAO-2026) e renomear, se necessário, ajustando os caminhos no `main.py`.
