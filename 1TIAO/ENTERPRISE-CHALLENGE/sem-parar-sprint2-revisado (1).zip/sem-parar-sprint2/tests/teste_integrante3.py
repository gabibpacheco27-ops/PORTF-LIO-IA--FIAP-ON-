"""Testes automatizados mínimos dos cálculos do Integrante 3."""
import unittest
import pandas as pd
from src.diagnostico_regras import classificar_gap


class TesteRegrasDiagnostico(unittest.TestCase):
    def test_limite_eficiente(self):
        self.assertEqual(classificar_gap(-12.0), "eficiente")
        self.assertEqual(classificar_gap(10.0), "eficiente")

    def test_limite_atencao(self):
        self.assertEqual(classificar_gap(10.01), "atencao")
        self.assertEqual(classificar_gap(25.0), "atencao")

    def test_limite_ineficiente(self):
        self.assertEqual(classificar_gap(25.01), "ineficiente")

    def test_dados_insuficientes(self):
        self.assertEqual(classificar_gap(None), "dados_insuficientes")
        self.assertEqual(classificar_gap(float("nan")), "dados_insuficientes")


if __name__ == "__main__":
    unittest.main(verbosity=2)
