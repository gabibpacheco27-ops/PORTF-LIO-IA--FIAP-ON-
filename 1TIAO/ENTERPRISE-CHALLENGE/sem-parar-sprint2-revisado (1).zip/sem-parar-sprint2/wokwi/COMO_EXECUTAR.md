# Executar, testar e salvar as evidências

**Situação atual:** versão MicroPython executada e salva. Condição normal e alerta de temperatura observados no Serial e LED. Os demais cenários da tabela continuam sendo roteiro para testes adicionais. Consulte docs/ATUALIZACAO_WOKWI.md.

1. Abra o projeto atual: https://wokwi.com/projects/480683672811316225. Para recriar, use https://wokwi.com/projects/new/micropython-esp32.
2. Na versão atual use `main.py` e `diagram.json`. Não use `sketch.ino`: ele é o código Arduino anterior, preservado como histórico.
3. Inicie a simulação. Se houver erro, preserve a mensagem para correção antes de produzir as evidências.
4. Espere o Monitor Serial mostrar o cabeçalho CSV e leituras a cada dois segundos.
5. Mova cada potenciômetro. Da esquerda para a direita: velocidade, rpm, temperatura e combustível. As posições iniciais foram escolhidas para não acionar os alertas.
6. Para cada teste da tabela, mantenha as outras grandezas normais e observe LED e coluna `anomalia`. Aguarde nova linha após cada mudança.
7. Copie as linhas realmente emitidas para `wokwi/captura_serial.txt` (não existe captura pré-preenchida). O importador ignora cabeçalho e mensagens de boot.
8. Salve o projeto e preencha `wokwi/link_projeto.txt`. Faça prints do circuito e dos testes com as leituras visíveis; salve em `docs/evidencias/`. Não use saídas inventadas como prova.
9. Rode o importador do README e encaminhe a telemetria combinada ao integrante 2.

## Conexões

| Sinal | Pino do ESP32 | Faixa representada |
|---|---|---|
| Velocidade, potenciômetro 1 | GPIO34 | 0 a 160 km/h |
| Rotação, potenciômetro 2 | GPIO35 | 0 a 5.000 rpm |
| Temperatura, potenciômetro 3 | GPIO32 | 60 a 140 °C |
| Nível, potenciômetro 4 | GPIO33 | 0 a 100% |
| LED vermelho, resistor de 220 Ω em série | GPIO25 | Aceso quando qualquer alerta ocorre |

Todos os potenciômetros usam VCC em 3V3 e GND comum. O LED liga GPIO25 → resistor → ânodo; cátodo → GND. O `value` inicial do componente Wokwi usa escala 0–1023; a leitura configurada no firmware usa ADC de 12 bits (0–4095). Referência do componente: https://docs.wokwi.com/parts/wokwi-potentiometer.

## Limites e justificativas da POC

| Grandeza | Anomalia | Justificativa didática |
|---|---|---|
| Temperatura | >105 °C | Demonstra alerta de aquecimento acima da faixa sintética normal de 82–100 °C |
| Rotação | >3.500 rpm | Demonstra esforço elevado em relação às faixas normais geradas por perfil |
| Velocidade | >110 km/h | Política interna fictícia da POC, sem representar limite legal de uma via |
| Combustível | <15% | Reserva operacional fictícia para demonstrar necessidade de abastecimento |

Esses limites não são especificações de fabricante, diagnósticos de defeito ou recomendações de segurança para um veículo real. Em produção seriam calibrados por modelo, combustível, operação e manual. Um limite de rotação comum serve à demonstração; não compara a eficiência de motores leves e pesados. O benchmark dos custos continua separado por perfil.

A igualdade ao limite não aciona o alerta: 105 °C, 3.500 rpm e 110 km/h são normais para esta regra; combustível em 15% também. Os quatro testes usam if/else independentes para detectar condições simultâneas.

## Roteiro de evidências

| Teste | Ajuste aproximado | Resultado a confirmar | Print sugerido |
|---|---|---|---|
| Normal | 55 km/h, 2.200 rpm, 95 °C, 60% | anomalia 0, LED apagado | 01_normal.png |
| Aquecimento | Temperatura perto de 120 °C | anomalia 1, LED aceso | 02_temperatura.png |
| Rotação | Rotação perto de 4.000 rpm | anomalia 1, LED aceso | 03_rpm.png |
| Velocidade | Velocidade perto de 125 km/h | anomalia 1, LED aceso | 04_velocidade.png |
| Reserva | Combustível perto de 10% | anomalia 1, LED aceso | 05_combustivel.png |
| Recuperação | Retornar todas as grandezas ao normal | anomalia 0, LED apagado | 06_recuperacao.png |

Inclua também um print completo do circuito. Os potenciômetros podem não atingir o valor exato desejado; use valores afastados dos limites. O teste de igualdade pode ser feito separadamente com valores constantes temporários no firmware e deve ser identificado dessa forma.

## Tempo e procedência

O timestamp começa em 01/10/2026 08:00:00 UTC e avança com `millis()`. É uma referência fictícia, não a data atual, nem um RTC. Reiniciar a simulação reinicia esse relógio. Não misture capturas de reinicializações como se fossem uma sequência contínua. Preserve cada captura original e documente reinícios.

`simulado=1` continua correto para Wokwi; `origem_leitura=wokwi_serial` distingue captura do circuito de linhas produzidas pelo gerador Python. Não extrapole frequência de alertas de 30 amostras mensais para incidentes reais ou horas de operação.


## Testes complementares concluídos

Os alertas de velocidade, rotação e combustível foram acionados individualmente no Wokwi, mantendo as demais grandezas normais. LED aceso e anomalia=1 observados em cada cenário; LED apagado e anomalia=0 após retorno à condição normal. Evidências 04 a 07 em docs/evidencias/. A captura completa está em wokwi/captura_serial_todos_alertas.txt e o CSV em wokwi/leituras_todos_alertas.csv. Esta atualização substitui as pendências de testes individuais descritas acima.
