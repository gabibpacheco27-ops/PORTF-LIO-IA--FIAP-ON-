from machine import Pin, ADC
import time

VEICULO = "VEIC-007"
INTERVALO_MS = 2000
led = Pin(25, Pin.OUT)
entradas = []
for pino in (34, 35, 32, 33):
    sensor = ADC(Pin(pino))
    sensor.atten(ADC.ATTN_11DB)
    sensor.width(ADC.WIDTH_12BIT)
    entradas.append(sensor)

print("id_veiculo,timestamp,velocidade,rpm,temperatura,nivel_combustivel,anomalia,simulado,origem_leitura")
inicio = time.ticks_ms()
ultima = inicio
while True:
    agora = time.ticks_ms()
    if time.ticks_diff(agora, ultima) < INTERVALO_MS:
        time.sleep_ms(10)
        continue
    ultima = agora
    velocidade = round(entradas[0].read() * 160 / 4095, 1)
    rpm = int(entradas[1].read() * 5000 / 4095)
    temperatura = round(60 + entradas[2].read() * 80 / 4095, 1)
    combustivel = round(entradas[3].read() * 100 / 4095, 1)
    if velocidade > 110:
        alerta_vel = True
    else:
        alerta_vel = False
    if rpm > 3500:
        alerta_rpm = True
    else:
        alerta_rpm = False
    if temperatura > 105:
        alerta_temp = True
    else:
        alerta_temp = False
    if combustivel < 15:
        alerta_comb = True
    else:
        alerta_comb = False
    anomalia = int(alerta_vel or alerta_rpm or alerta_temp or alerta_comb)
    led.value(anomalia)
    # Relogio ficticio iniciado em 01/10/2026 08:00:00 UTC.
    segundos = time.ticks_diff(agora, inicio) // 1000
    base = time.mktime((2026, 10, 1, 8, 0, 0, 0, 0))
    d = time.localtime(base + segundos)
    timestamp = "%04d-%02d-%02dT%02d:%02d:%02d" % d[:6]
    print("%s,%s,%.1f,%d,%.1f,%.1f,%d,1,wokwi_serial" % (VEICULO, timestamp, velocidade, rpm, temperatura, combustivel, anomalia))
