#include <Arduino.h>
#include <time.h>

// Potenciômetros representam sinais, não sensores automotivos reais.
const char* VEICULO = "VEIC-007";
const int PIN_VEL = 34, PIN_RPM = 35, PIN_TEMP = 32, PIN_COMB = 33;
const int LED_ALERTA = 25;
const unsigned long INTERVALO_MS = 2000;
unsigned long ultimaLeitura = 0;
// Relógio fictício: 01/10/2026 08:00 UTC; não há RTC/NTP no circuito.
const time_t INICIO_SIMULADO = 1790841600;

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  pinMode(LED_ALERTA, OUTPUT);
  digitalWrite(LED_ALERTA, LOW);
  Serial.println("id_veiculo,timestamp,velocidade,rpm,temperatura,nivel_combustivel,anomalia,simulado,origem_leitura");
}

void loop() {
  unsigned long agora = millis();
  if (agora - ultimaLeitura < INTERVALO_MS) return;
  ultimaLeitura = agora;
  float velocidade = analogRead(PIN_VEL) * (160.0 / 4095.0);
  int rpm = (int)(analogRead(PIN_RPM) * (5000.0 / 4095.0));
  float temperatura = 60.0 + analogRead(PIN_TEMP) * (80.0 / 4095.0);
  float combustivel = analogRead(PIN_COMB) * (100.0 / 4095.0);

  // Comparações independentes: mais de uma condição pode ocorrer ao mesmo tempo.
  bool alertaVel, alertaRpm, alertaTemp, alertaComb;
  if (velocidade > 110.0) alertaVel = true; else alertaVel = false;
  if (rpm > 3500) alertaRpm = true; else alertaRpm = false;
  if (temperatura > 105.0) alertaTemp = true; else alertaTemp = false;
  if (combustivel < 15.0) alertaComb = true; else alertaComb = false;
  bool anomalia = alertaVel || alertaRpm || alertaTemp || alertaComb;
  if (anomalia) digitalWrite(LED_ALERTA, HIGH);
  else digitalWrite(LED_ALERTA, LOW);

  time_t instante = INICIO_SIMULADO + agora / 1000;
  struct tm *data = gmtime(&instante);
  char timestamp[21];
  strftime(timestamp, sizeof(timestamp), "%Y-%m-%dT%H:%M:%S", data);
  Serial.printf("%s,%s,%.1f,%d,%.1f,%.1f,%d,1,wokwi_serial\n",
                VEICULO, timestamp, velocidade, rpm, temperatura, combustivel, anomalia ? 1 : 0);
}
