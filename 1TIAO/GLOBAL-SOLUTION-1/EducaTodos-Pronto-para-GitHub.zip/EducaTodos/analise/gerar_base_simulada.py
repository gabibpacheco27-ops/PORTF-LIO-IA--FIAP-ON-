"""
Projeto EducaTodos — Integrante 2 (Versão Atualizada)
Script: gerar_base_simulada.py

AVISO IMPORTANTE:
    Todos os dados gerados por este script são 100% SIMULADOS (sintéticos),
    criados exclusivamente para fins acadêmicos e de prototipagem de Ciência de Dados
    e Machine Learning no projeto EducaTodos. Não há qualquer dado de alunos reais.

Descrição:
    1. Gera a base simulada de avaliação diagnóstica prévia ('diagnostico_alunos.csv')
       para 250 alunos distribuídos de forma equilibrada nas 7 séries escolares
       (6º Ano EF, 7º Ano EF, 8º Ano EF, 9º Ano EF, 1º Ano EM, 2º Ano EM, 3º Ano EM)
       e nas 4 disciplinas (Matemática, Português, Ciências, História), totalizando
       1.000 combinações únicas, sem vazamento de dados (gerada independentemente
       das respostas das interações).
    2. Gera a base bruta de interações na plataforma com injeção controlada de
       anomalias (duplicatas, nulos, tempos <= 0, acertos > tentativas e valores
       inválidos de uso de dica), executa o pipeline de higienização e exporta
       exatamente 11.991 interações válidas para 'interacoes_alunos.csv', contendo
       a variável binária 'usou_dica' (0 ou 1) e garantindo >= 10 interações
       válidas por combinação (id_aluno, disciplina).
    3. Executa auditoria e validação cruzada automática entre os dois arquivos.
"""

import numpy as np
import pandas as pd


SERIES_ESCOLARES = [
    "6º Ano EF",
    "7º Ano EF",
    "8º Ano EF",
    "9º Ano EF",
    "1º Ano EM",
    "2º Ano EM",
    "3º Ano EM",
]

DISCIPLINAS = ["Matemática", "Português", "Ciências", "História"]


def classificar_nivel_diagnostico(nota: float) -> str:
    """
    Classifica a nota diagnóstica (escala 0 a 100) em três níveis:
        - Básico:        0.00 a 59.99 (< 60.0)
        - Intermediário: 60.00 a 79.99 (>= 60.0 e < 80.0)
        - Avançado:      80.00 a 100.00 (>= 80.0)
    """
    if nota < 60.0:
        return "Básico"
    elif nota < 80.0:
        return "Intermediário"
    else:
        return "Avançado"


def gerar_perfis_e_diagnostico(seed: int = 42):
    """
    Gera o cadastro simulado dos 250 alunos nas 7 séries e a avaliação diagnóstica
    prévia ('diagnostico_alunos.csv') para as 1.000 combinações (aluno x disciplina).

    A nota diagnóstica é gerada a partir de uma habilidade latente do aluno,
    afinidade latente por disciplina e ruído próprio da prova diagnóstica,
    de forma totalmente independente dos resultados das interações futuras
    (evitando data leakage para o modelo do Integrante 3).
    """
    rng = np.random.default_rng(seed)
    n_alunos = 250

    alunos = [f"ALU_{i:03d}" for i in range(1, n_alunos + 1)]

    # Distribuição equilibrada dos 250 alunos nas 7 séries (36 alunos em 5 séries e 35 em 2 séries)
    series_embaralhadas = SERIES_ESCOLARES.copy()
    rng.shuffle(series_embaralhadas)
    serie_por_aluno = {
        aluno: series_embaralhadas[i % len(series_embaralhadas)]
        for i, aluno in enumerate(alunos)
    }

    # Traços latentes individuais do aluno (não observados diretamente)
    habilidade_latente_aluno = {
        aluno: float(rng.normal(0.0, 1.0)) for aluno in alunos
    }
    propensao_dica_aluno = {
        aluno: float(np.clip(rng.beta(2.2, 4.5), 0.05, 0.85)) for aluno in alunos
    }

    # Parâmetros de dificuldade base por disciplina na avaliação diagnóstica
    base_diag_disciplina = {
        "Matemática": 61.0,
        "Ciências":   65.5,
        "Português":  68.5,
        "História":   70.5,
    }

    afinidade_latente = {}
    registros_diag = []

    for aluno in alunos:
        serie = serie_por_aluno[aluno]
        hab_geral = habilidade_latente_aluno[aluno]

        for disc in DISCIPLINAS:
            # Afinidade específica do aluno na disciplina (traço latente)
            afinidade = float(rng.normal(0.0, 0.55))
            afinidade_latente[(aluno, disc)] = afinidade

            # Ruído próprio da prova diagnóstica (independente das interações)
            ruido_prova = float(rng.normal(0.0, 8.5))
            nota_bruta = (
                base_diag_disciplina[disc]
                + 11.5 * hab_geral
                + 6.5 * afinidade
                + ruido_prova
            )
            nota_diag = float(np.round(np.clip(nota_bruta, 0.0, 100.0), 1))
            nivel_diag = classificar_nivel_diagnostico(nota_diag)

            registros_diag.append(
                {
                    "id_aluno": aluno,
                    "serie": serie,
                    "disciplina": disc,
                    "nota_diagnostica": nota_diag,
                    "nivel_diagnostico": nivel_diag,
                }
            )

    df_diagnostico = pd.DataFrame(registros_diag).sort_values(
        by=["id_aluno", "disciplina"]
    ).reset_index(drop=True)

    perfis_latentes = {
        "alunos": alunos,
        "serie_por_aluno": serie_por_aluno,
        "habilidade_latente_aluno": habilidade_latente_aluno,
        "afinidade_latente": afinidade_latente,
        "propensao_dica_aluno": propensao_dica_aluno,
    }
    return df_diagnostico, perfis_latentes


def gerar_interacoes_brutas(perfis_latentes: dict, seed: int = 42) -> pd.DataFrame:
    """
    Gera a base bruta de interações dos 250 alunos nas 4 disciplinas,
    incluindo a variável binária 'usou_dica' (0/1) e injeção controlada
    de anomalias para validar o pipeline de limpeza.
    """
    rng = np.random.default_rng(seed + 100)

    alunos = perfis_latentes["alunos"]
    serie_por_aluno = perfis_latentes["serie_por_aluno"]
    habilidade_latente_aluno = perfis_latentes["habilidade_latente_aluno"]
    afinidade_latente = perfis_latentes["afinidade_latente"]
    propensao_dica_aluno = perfis_latentes["propensao_dica_aluno"]

    perfil_disciplina = {
        "Matemática": {"p_acerto": 0.63, "tempo_medio": 195.0, "tempo_sd": 55.0, "dica_base": 0.36},
        "Ciências":   {"p_acerto": 0.69, "tempo_medio": 165.0, "tempo_sd": 48.0, "dica_base": 0.28},
        "Português":  {"p_acerto": 0.73, "tempo_medio": 145.0, "tempo_sd": 42.0, "dica_base": 0.23},
        "História":   {"p_acerto": 0.75, "tempo_medio": 150.0, "tempo_sd": 40.0, "dica_base": 0.20},
    }

    ajuste_serie = {
        "6º Ano EF": -0.04,
        "7º Ano EF": -0.025,
        "8º Ano EF": -0.01,
        "9º Ano EF":  0.005,
        "1º Ano EM":  0.015,
        "2º Ano EM":  0.03,
        "3º Ano EM":  0.045,
    }

    datas_possiveis = pd.date_range("2026-08-03", "2026-11-16", freq="D")

    registros = []
    # 1.000 combinações (250 alunos x 4 disciplinas), 10 a 14 interações cada -> média 12.000
    for aluno in alunos:
        serie = serie_por_aluno[aluno]
        hab_geral = habilidade_latente_aluno[aluno]
        prop_dica = propensao_dica_aluno[aluno]

        for disc in DISCIPLINAS:
            n_interacoes = int(rng.integers(10, 15))  # 10 a 14 interações
            cfg = perfil_disciplina[disc]
            afinidade = afinidade_latente[(aluno, disc)]

            datas_escolhidas = np.sort(
                rng.choice(datas_possiveis, size=n_interacoes, replace=True)
            )

            for idx, dt in enumerate(datas_escolhidas):
                progresso_temporal = 0.03 * (idx / max(1, n_interacoes - 1))
                dificuldade_sessao = float(rng.normal(0.0, 0.06))

                # Probabilidade de utilização de dica (0 ou 1):
                # Depende do perfil comportamental do aluno, da disciplina,
                # da dificuldade da sessão e parcialmente da habilidade latente
                prob_dica = float(
                    np.clip(
                        0.45 * cfg["dica_base"]
                        + 0.45 * prop_dica
                        + 0.65 * max(0.0, dificuldade_sessao)
                        - 0.055 * hab_geral
                        - 0.03 * afinidade,
                        0.03,
                        0.92,
                    )
                )
                usou_dica = int(rng.binomial(1, prob_dica))

                # Probabilidade de acerto na sessão (com leve ganho quando usa dica)
                bonus_dica = 0.04 if usou_dica == 1 else 0.0
                prob_acerto = float(
                    np.clip(
                        cfg["p_acerto"]
                        + ajuste_serie[serie]
                        + 0.085 * hab_geral
                        + 0.045 * afinidade
                        + progresso_temporal
                        - dificuldade_sessao
                        + bonus_dica,
                        0.15,
                        0.98,
                    )
                )

                tentativas = int(rng.integers(3, 11))  # 3 a 10 questões por sessão
                acertos = int(rng.binomial(tentativas, prob_acerto))

                # Tempo de resolução influenciado pela disciplina, dificuldade e uso de dica
                fator_tempo_dica = 1.08 if usou_dica == 1 else 1.0
                tempo_seg = float(
                    np.round(
                        np.clip(
                            rng.normal(cfg["tempo_medio"], cfg["tempo_sd"]) * fator_tempo_dica,
                            25.0,
                            600.0,
                        ),
                        1,
                    )
                )

                registros.append(
                    {
                        "id_aluno": aluno,
                        "serie": serie,
                        "disciplina": disc,
                        "data_interacao": pd.Timestamp(dt).strftime("%Y-%m-%d"),
                        "tentativas": tentativas,
                        "acertos": acertos,
                        "tempo_seg": tempo_seg,
                        "usou_dica": usou_dica,
                    }
                )

    df = pd.DataFrame(registros)

    # Ajuste fino para 12.000 registros antes da injeção controlada de anomalias,
    # preservando o piso mínimo de 10 interações por combinação (id_aluno, disciplina)
    contagens = df.groupby(["id_aluno", "disciplina"]).size()
    while len(df) > 12000:
        candidatos = contagens[contagens > 10].index
        par = candidatos[int(rng.integers(0, len(candidatos)))]
        idx_remover = df[
            (df["id_aluno"] == par[0]) & (df["disciplina"] == par[1])
        ].index[-1]
        df = df.drop(index=idx_remover)
        contagens[par] -= 1

    while len(df) < 12000:
        candidatos = contagens[contagens < 14].index
        par = candidatos[int(rng.integers(0, len(candidatos)))]
        amostra = df[
            (df["id_aluno"] == par[0]) & (df["disciplina"] == par[1])
        ].iloc[-1].copy()
        amostra["tempo_seg"] = round(float(amostra["tempo_seg"]) + 1.5, 1)
        df = pd.concat([df, pd.DataFrame([amostra])], ignore_index=True)
        contagens[par] += 1

    df = df.reset_index(drop=True)

    # Injeção controlada de 9 anomalias em grupos com >= 12 registros
    # (12.000 - 9 = 11.991 registros válidos, preservando o piso >= 10 por par)
    contagens = df.groupby(["id_aluno", "disciplina"]).size()
    pares_folga = contagens[contagens >= 12].index.tolist()

    # 3 registros com tempo_seg negativo ou zero
    for i in range(3):
        par = pares_folga[i]
        idx = df[(df["id_aluno"] == par[0]) & (df["disciplina"] == par[1])].index[0]
        df.loc[idx, "tempo_seg"] = -12.0 * (i + 1)

    # 3 registros com acertos > tentativas (inconsistência lógica)
    for i in range(3, 6):
        par = pares_folga[i]
        idx = df[(df["id_aluno"] == par[0]) & (df["disciplina"] == par[1])].index[0]
        df.loc[idx, "acertos"] = int(df.loc[idx, "tentativas"]) + 3

    # 3 registros com valores ausentes em campos críticos (incluindo usou_dica)
    for i in range(6, 9):
        par = pares_folga[i]
        idx = df[(df["id_aluno"] == par[0]) & (df["disciplina"] == par[1])].index[0]
        if i == 8:
            df.loc[idx, "usou_dica"] = np.nan
        else:
            df.loc[idx, "tempo_seg"] = np.nan

    # 4 duplicatas exatas (serão removidas na etapa de deduplicação)
    duplicadas = df.iloc[[15, 320, 2100, 5400]].copy()
    df = pd.concat([df, duplicadas], ignore_index=True)

    return df


def higienizar_interacoes(df_bruto: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """
    Executa o tratamento de qualidade de dados sobre a base bruta de interações:
        1. Remoção de linhas duplicadas exatas;
        2. Remoção de registros com valores ausentes (NaN);
        3. Remoção de tempos inválidos (tempo_seg <= 0);
        4. Remoção de inconsistências entre tentativas e acertos;
        5. Validação do domínio binário de 'usou_dica' (0 ou 1);
        6. Cálculo de 'taxa_acerto' e ordenação canônica das colunas.
    """
    total_bruto = len(df_bruto)

    df = df_bruto.drop_duplicates().copy()
    removidas_dup = total_bruto - len(df)

    antes_nulos = len(df)
    df = df.dropna(
        subset=[
            "id_aluno",
            "serie",
            "disciplina",
            "data_interacao",
            "tentativas",
            "acertos",
            "tempo_seg",
            "usou_dica",
        ]
    ).copy()
    removidas_nulos = antes_nulos - len(df)

    antes_tempo = len(df)
    df = df[df["tempo_seg"] > 0].copy()
    removidas_tempo = antes_tempo - len(df)

    antes_acertos = len(df)
    df = df[
        (df["tentativas"] > 0)
        & (df["acertos"] >= 0)
        & (df["acertos"] <= df["tentativas"])
    ].copy()
    removidas_acertos = antes_acertos - len(df)

    antes_dica = len(df)
    df = df[df["usou_dica"].isin([0, 1, 0.0, 1.0])].copy()
    removidas_dica = antes_dica - len(df)

    df["tentativas"] = df["tentativas"].astype(int)
    df["acertos"] = df["acertos"].astype(int)
    df["usou_dica"] = df["usou_dica"].astype(int)
    df["taxa_acerto"] = (df["acertos"] / df["tentativas"]).round(4)

    colunas_finais = [
        "id_aluno",
        "serie",
        "disciplina",
        "data_interacao",
        "tentativas",
        "acertos",
        "taxa_acerto",
        "tempo_seg",
        "usou_dica",
    ]
    df = (
        df[colunas_finais]
        .sort_values(by=["id_aluno", "disciplina", "data_interacao"])
        .reset_index(drop=True)
    )

    stats_limpeza = {
        "total_bruto": total_bruto,
        "removidas_dup": removidas_dup,
        "removidas_nulos": removidas_nulos,
        "removidas_tempo": removidas_tempo,
        "removidas_acertos": removidas_acertos,
        "removidas_dica": removidas_dica,
        "total_valido": len(df),
    }
    return df, stats_limpeza


def validar_bases(
    df_interacoes: pd.DataFrame,
    df_diagnostico: pd.DataFrame,
    stats_limpeza: dict,
) -> None:
    """
    Executa validação automática com assertions para garantir integridade estrutural,
    ausência de anomalias e correspondência exata entre 'interacoes_alunos.csv'
    e 'diagnostico_alunos.csv'.
    """
    # --- Validações de interacoes_alunos.csv ---
    n_alunos_int = df_interacoes["id_aluno"].nunique()
    n_reg_int = len(df_interacoes)
    n_disc_int = df_interacoes["disciplina"].nunique()
    n_series_int = df_interacoes["serie"].nunique()

    contagem_pares = df_interacoes.groupby(["id_aluno", "disciplina"]).size()
    n_comb_int = len(contagem_pares)
    min_comb = int(contagem_pares.min())
    max_comb = int(contagem_pares.max())
    media_comb = float(contagem_pares.mean())
    mediana_comb = float(contagem_pares.median())
    comb_menor_10 = int((contagem_pares < 10).sum())

    nulos_int = int(df_interacoes.isna().sum().sum())
    dup_int = int(df_interacoes.duplicated().sum())

    assert n_alunos_int == 250, f"Esperado 250 alunos, obtido {n_alunos_int}"
    assert n_reg_int == 11991, f"Esperado 11.991 registros válidos, obtido {n_reg_int}"
    assert n_disc_int == 4, f"Esperado 4 disciplinas, obtido {n_disc_int}"
    assert n_series_int == 7, f"Esperado 7 séries, obtido {n_series_int}"
    assert set(df_interacoes["serie"].unique()) == set(SERIES_ESCOLARES)
    assert set(df_interacoes["disciplina"].unique()) == set(DISCIPLINAS)
    assert n_comb_int == 1000, f"Esperado 1.000 combinações, obtido {n_comb_int}"
    assert min_comb >= 10, f"Combinação com menos de 10 interações: {min_comb}"
    assert comb_menor_10 == 0, f"Existem {comb_menor_10} combinações com < 10 interações"
    assert nulos_int == 0, f"Existem {nulos_int} valores ausentes em interacoes_alunos.csv"
    assert dup_int == 0, f"Existem {dup_int} duplicatas em interacoes_alunos.csv"
    assert set(df_interacoes["usou_dica"].unique()).issubset({0, 1})
    assert (df_interacoes["tempo_seg"] > 0).all()
    assert (df_interacoes["acertos"] >= 0).all()
    assert (df_interacoes["acertos"] <= df_interacoes["tentativas"]).all()

    # Consistência de série por aluno
    series_por_aluno_int = df_interacoes.groupby("id_aluno")["serie"].nunique()
    assert (series_por_aluno_int == 1).all(), "Aluno com mais de uma série em interacoes_alunos.csv"

    # --- Validações de diagnostico_alunos.csv ---
    n_reg_diag = len(df_diagnostico)
    nulos_diag = int(df_diagnostico.isna().sum().sum())
    dup_diag = int(df_diagnostico.duplicated(subset=["id_aluno", "disciplina"]).sum())

    assert n_reg_diag == 1000, f"Esperado 1.000 registros no diagnóstico, obtido {n_reg_diag}"
    assert nulos_diag == 0, f"Existem {nulos_diag} valores ausentes em diagnostico_alunos.csv"
    assert dup_diag == 0, "Existem pares duplicados em diagnostico_alunos.csv"
    assert df_diagnostico["nota_diagnostica"].between(0.0, 100.0).all()
    assert set(df_diagnostico["nivel_diagnostico"].unique()) == {
        "Básico",
        "Intermediário",
        "Avançado",
    }

    # Correspondência exata (id_aluno, serie, disciplina) entre os dois arquivos
    pares_int = (
        df_interacoes[["id_aluno", "serie", "disciplina"]]
        .drop_duplicates()
        .sort_values(by=["id_aluno", "disciplina"])
        .reset_index(drop=True)
    )
    pares_diag = (
        df_diagnostico[["id_aluno", "serie", "disciplina"]]
        .sort_values(by=["id_aluno", "disciplina"])
        .reset_index(drop=True)
    )
    pd.testing.assert_frame_equal(pares_int, pares_diag)

    # Impressão do relatório completo
    print("=" * 70)
    print("RELATÓRIO DE VALIDAÇÃO AUTOMÁTICA — PROJETO EDUCATODOS (INTEGRANTE 2)")
    print("AVISO: DADOS 100% SIMULADOS PARA FINS ACADÊMICOS (SEM ALUNOS REAIS)")
    print("=" * 70)
    print("\n[1] HIGIENIZAÇÃO DE interacoes_alunos.csv")
    print(f"  - Registros brutos gerados:               {stats_limpeza['total_bruto']:,}")
    print(f"  - (-) Duplicatas removidas:               {stats_limpeza['removidas_dup']:,}")
    print(f"  - (-) Valores ausentes removidos:         {stats_limpeza['removidas_nulos']:,}")
    print(f"  - (-) Tempos inválidos (<= 0s):           {stats_limpeza['removidas_tempo']:,}")
    print(f"  - (-) Inconsistências acertos/tentativas: {stats_limpeza['removidas_acertos']:,}")
    print(f"  - (-) Valores inválidos em usou_dica:     {stats_limpeza['removidas_dica']:,}")
    print(f"  - Total de interações válidas finais:     {n_reg_int:,}")

    print("\n[2] AUDITORIA DE interacoes_alunos.csv")
    print(f"  - Quantidade de alunos únicos:            {n_alunos_int}")
    print(f"  - Quantidade total de interações válidas: {n_reg_int:,}")
    print(f"  - Quantidade de disciplinas:              {n_disc_int} ({', '.join(sorted(df_interacoes['disciplina'].unique()))})")
    print(f"  - Quantidade de séries escolares:         {n_series_int} ({', '.join(SERIES_ESCOLARES)})")
    print(f"  - Combinações (aluno × disciplina):       {n_comb_int:,}")
    print(f"  - Interações/combinação (mín / máx):      {min_comb} / {max_comb}")
    print(f"  - Interações/combinação (média / med.):   {media_comb:.2f} / {mediana_comb:.1f}")
    print(f"  - Combinações com < 10 interações:        {comb_menor_10}")
    print(f"  - Valores ausentes (NaN):                 {nulos_int}")
    print(f"  - Registros duplicados:                   {dup_int}")
    print(f"  - Taxa global de uso de dicas:            {df_interacoes['usou_dica'].mean():.2%}")

    print("\n[3] AUDITORIA DE diagnostico_alunos.csv")
    print(f"  - Total de registros:                     {n_reg_diag:,}")
    print(f"  - Valores ausentes (NaN):                 {nulos_diag}")
    print(f"  - Correspondência aluno/série/disciplina: 100% IDÊNTICA (1.000/1.000)")

    print("\n  Distribuição de Alunos Únicos por Série Escolar:")
    alunos_serie = (
        df_diagnostico[["id_aluno", "serie"]]
        .drop_duplicates()
        .groupby("serie")
        .size()
        .reindex(SERIES_ESCOLARES)
    )
    for serie, qtd in alunos_serie.items():
        print(f"    * {serie:<10}: {qtd} alunos")

    print("\n  Distribuição dos Níveis Diagnósticos (1.000 combinações):")
    dist_niveis = df_diagnostico["nivel_diagnostico"].value_counts().reindex(
        ["Básico", "Intermediário", "Avançado"]
    )
    for nivel, qtd in dist_niveis.items():
        print(f"    * {nivel:<14}: {qtd:3d} ({qtd / n_reg_diag:.1%})")
    print("=" * 70)


if __name__ == "__main__":
    df_diag, perfis = gerar_perfis_e_diagnostico(seed=42)
    df_raw = gerar_interacoes_brutas(perfis, seed=42)
    df_clean, stats = higienizar_interacoes(df_raw)

    validar_bases(df_clean, df_diag, stats)

    df_clean.to_csv("interacoes_alunos.csv", index=False, encoding="utf-8")
    df_diag.to_csv("diagnostico_alunos.csv", index=False, encoding="utf-8")
    print("Arquivos 'interacoes_alunos.csv' e 'diagnostico_alunos.csv' exportados com sucesso!")
