# Projeto EducaTodos — Entrega Consolidada (Integrante 2)

> **AVISO DE NATUREZA DOS DADOS:** Todos os registros contidos neste diretório (`interacoes_alunos.csv` e `diagnostico_alunos.csv`) são **100% simulados (dados sintéticos)**, gerados computacionalmente com semente reprodutível (`seed=42`) exclusivamente para fins acadêmicos e de prototipagem de Ciência de Dados e Machine Learning. **Nenhum dado de aluno real foi utilizado.**

---

## 1. Estrutura da Pasta

Esta pasta reúne os 5 entregáveis atualizados da etapa de **Engenharia e Análise Exploratória de Dados (Integrante 2)**:

| Arquivo | Descrição |
| :--- | :--- |
| `gerar_base_simulada.py` | Script Python reprodutível (`seed=42`) que gera os perfis latentes, a avaliação diagnóstica prévia, as interações brutas com anomalias injetadas, executa a higienização e roda as asserções de validação cruzada. |
| `interacoes_alunos.csv` | Base higienizada com **11.991 interações válidas** de **250 alunos** ao longo das **7 séries** e **4 disciplinas**, incluindo a variável binária `usou_dica` e garantindo **≥ 10 interações** por combinação aluno × disciplina. |
| `diagnostico_alunos.csv` | Base separada de avaliação diagnóstica prévia contendo **1.000 registros** (1 por combinação aluno × disciplina), com `nota_diagnostica` e `nivel_diagnostico` gerados **sem vazamento de dados**. |
| `Integrante 2.ipynb` | Notebook Jupyter totalmente executado contendo a auditoria técnica, estatísticas descritivas, 5 painéis gráficos e preparação da tabela agregada para o Integrante 3. |
| `README.md` | Documentação técnica sobre geração, regras de negócio, tratamento de qualidade, contrato de integração para ML e limitações da base simulada. |

---

## 2. Escopo Pedagógico e Cobertura

* **Total de Alunos Simulados:** `250` (`ALU_001` a `ALU_250`), cada qual vinculado a uma única série consistente em todos os registros.
* **Séries Escolares Contempladas (7 séries — distribuição equilibrada de 35 a 36 alunos por série):**
  * **Ensino Fundamental II:** `6º Ano EF`, `7º Ano EF`, `8º Ano EF`, `9º Ano EF`
  * **Ensino Médio:** `1º Ano EM`, `2º Ano EM`, `3º Ano EM`
* **Disciplinas Contempladas (4 disciplinas):** `Matemática`, `Português`, `Ciências`, `História`
* **Combinações Únicas (`id_aluno` × `disciplina`):** `1.000` combinações, todas com **10 a 14 interações válidas** (média de `11,99` e mediana de `12,0` interações por combinação).

---

## 3. Dicionário de Dados

### 3.1. `interacoes_alunos.csv` (11.991 linhas × 9 colunas)

| Coluna | Tipo | Descrição |
| :--- | :--- | :--- |
| `id_aluno` | `string` | Identificador único do aluno simulado (`ALU_001` a `ALU_250`). |
| `serie` | `string` | Série escolar do aluno (`6º Ano EF` a `3º Ano EM`). |
| `disciplina` | `string` | Disciplina avaliada (`Matemática`, `Português`, `Ciências`, `História`). |
| `data_interacao` | `date` | Data da sessão de exercícios (`YYYY-MM-DD`, semestre letivo de 2026). |
| `tentativas` | `int` | Quantidade de questões tentadas na sessão (3 a 10). |
| `acertos` | `int` | Quantidade de questões respondidas corretamente (`0 <= acertos <= tentativas`). |
| `taxa_acerto` | `float` | Proporção de acertos na sessão (`acertos / tentativas`, arredondada em 4 casas). |
| `tempo_seg` | `float` | Tempo total gasto na sessão em segundos (`tempo_seg > 0`). |
| `usou_dica` | `int` | Indicador binário de utilização de dica pedagógica (`0` = não utilizou; `1` = utilizou). |

### 3.2. `diagnostico_alunos.csv` (1.000 linhas × 5 colunas)

| Coluna | Tipo | Descrição |
| :--- | :--- | :--- |
| `id_aluno` | `string` | Identificador único do aluno simulado (`ALU_001` a `ALU_250`). |
| `serie` | `string` | Série escolar correspondente ao aluno em `interacoes_alunos.csv`. |
| `disciplina` | `string` | Disciplina correspondente ao diagnóstico. |
| `nota_diagnostica` | `float` | Nota de avaliação diagnóstica prévia (escala de `0.0` a `100.0`). |
| `nivel_diagnostico` | `string` | Classe alvo categorizada (`Básico`, `Intermediário` ou `Avançado`). |

---

## 4. Critérios da Avaliação Diagnóstica e Prevenção de Vazamento (*Data Leakage*)

### 4.1. Limites de Classificação de `nivel_diagnostico`
A variável `nota_diagnostica` (escala de 0 a 100) é convertida nas três classes diagnósticas conforme os seguintes intervalos:

* **`Básico`:** `0.0` a `59.9` (`nota_diagnostica < 60.0`)
* **`Intermediário`:** `60.0` a `79.9` (`60.0 <= nota_diagnostica < 80.0`)
* **`Avançado`:** `80.0` a `100.0` (`nota_diagnostica >= 80.0`)

### 4.2. Independência Estatística (Sem *Data Leakage*)
Para evitar vazamento de informação na etapa de Machine Learning (Integrante 3), `nota_diagnostica` **não é calculada a partir da `taxa_acerto` nem das respostas registradas em `interacoes_alunos.csv`**. Em vez disso:
1. Cada aluno recebe um traço latente de habilidade geral e uma afinidade latente específica por disciplina;
2. A `nota_diagnostica` é gerada previamente a partir desses traços latentes somados a um ruído próprio da avaliação diagnóstica;
3. As interações na plataforma são simuladas separadamente, incorporando evolução temporal ao longo do semestre, variação de dificuldade por sessão, efeito do uso de dicas (`usou_dica`) e aleatoriedade binomial por questão.

---

## 5. Pipeline de Higienização e Validação

O script `gerar_base_simulada.py` injeta anomalias controladas na base bruta (`12.004` registros) para simular falhas reais de telemetria e valida a limpeza antes da exportação:
1. **Remoção de duplicatas exatas:** `-4` registros;
2. **Remoção de valores ausentes (`NaN`):** `-3` registros;
3. **Remoção de tempos inválidos (`tempo_seg <= 0`):** `-3` registros;
4. **Remoção de inconsistências lógicas (`acertos > tentativas`):** `-3` registros;
5. **Base final validada:** **`11.991` registros**, com `0` nulos, `0` duplicatas e `100%` das `1.000` combinações possuindo `>= 10` interações válidas.

---

## 6. Compatibilidade com o Integrante 3 (Modelagem de Machine Learning)

Para treinar o modelo de classificação supervisonada cujo alvo (`y`) é `nivel_diagnostico`:
1. Agrupar `interacoes_alunos.csv` por `["id_aluno", "serie", "disciplina"]` calculando:
   * `taxa_acerto`: média de `taxa_acerto`
   * `tempo_medio`: média de `tempo_seg`
   * `media_tentativas`: média de `tentativas`
   * `taxa_dicas`: média de `usou_dica`
2. Realizar `merge` com `diagnostico_alunos.csv` pelas chaves `["id_aluno", "serie", "disciplina"]`.
3. **Regra obrigatória:** Não utilizar `nota_diagnostica` como variável explicativa (`X`), pois `nivel_diagnostico` é derivado diretamente dela.

---

## 7. Limitações dos Dados Simulados

* **Natureza Sintética:** Embora calibremos progressão por série, diferenças entre disciplinas, propensão individual ao uso de dicas e ruído realista, os padrões comportamentais não capturam toda a complexidade socioemocional, evasão ou heterogeneidade curricular de escolas reais.
* **Granularidade de Sessão:** Cada linha de `interacoes_alunos.csv` representa uma sessão agregada de 3 a 10 questões em uma data, e não o log individual de cada clique ou questão isolada.
* **Uso Recomendado:** Os dados são adequados para validar pipelines de engenharia de atributos, comparação de algoritmos de classificação e avaliação de métricas multiclasse no escopo do projeto EducaTodos, devendo o modelo ser retreinado caso dados reais venham a ser coletados futuramente.

## Indicadores para o relatório final

| Indicador | Valor medido na base simulada | Como medir no uso real |
|---|---|---|
| Taxa média de acerto | 72,42% por sessão | Calcular a média da proporção de questões corretas em cada sessão. |
| Tempo médio | 168,27 s por sessão | Somar o tempo das questões de cada sessão e calcular a média das sessões. |
| Evolução semestral de nível | Indisponível com uma avaliação diagnóstica por aluno e disciplina | Aplicar avaliações comparáveis no início e no fim do semestre e calcular a proporção dos alunos com avanço entre os dois momentos. |
| Redução da diferença de desempenho | Indisponível com uma avaliação diagnóstica por aluno e disciplina | Definir os grupos e comparar a diferença em pontos percentuais no início e no fim, sob a mesma escala de avaliação. |

A telemetria simulada tem uma linha por sessão. A ligação com o catálogo é feita
por série e disciplina. As sessões agregadas não têm ID individual de questão.
