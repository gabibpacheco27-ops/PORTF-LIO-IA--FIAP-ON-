# EducaTodos — Global Solution 2026.2

Projeto CitizenTech da FIAP para reforço escolar do 6º ao 9º ano do Ensino Fundamental e do
1º ao 3º ano do Ensino Médio. O aplicativo oferece exercícios de Matemática, Português,
Ciências e História com explicações adaptadas ao nível estimado do estudante.

## Executar

Use Python 3.11 ou superior. Depois de extrair o ZIP, abra o Terminal na pasta que contém este README.

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m src.main_sqlite
```

O SQLite cria `dados/educatodos.db` no primeiro uso. O mesmo comando recupera o progresso ao reabrir.
O aplicativo registra a alternativa final, o número de tentativas, as dicas e o identificador da rodada.
O nível começa em Básico e usa o modelo após dez rodadas elegíveis de 3 a 10 questões concluídas na
mesma disciplina. A modalidade JSON continua disponível com `python3 src/educatodos.py` e usa
um histórico separado. O áudio é opcional. Instale `src/requirements-audio.txt` para habilitá-lo.

## Banco de demonstração e testes

```bash
python3 scripts/popular_demo.py
python3 scripts/executar_consultas.py dados/demo.db
python3 -m unittest discover -s tests -v
(cd ml && python3 -m unittest discover -s testes -v)
```

O banco de demonstração reúne registros de exercícios fictícios e 11.991 sessões simuladas.
Para repetir a carga, passe um novo caminho a `scripts/popular_demo.py`.
Para testar com um SQLite isolado, use `EDUCATODOS_DB=/tmp/educatodos-teste.db python3 -m src.main_sqlite`.

## Arquivos

| Pasta | Conteúdo |
|---|---|
| `src/` | Aplicativo, catálogo de 40 questões, integração com SQLite e modelo treinado |
| `scripts/` | Esquema SQLite, carga de demonstração e 12 consultas SQL |
| `data/` | CSVs simulados de interações e diagnóstico |
| `analise/` | Gerador com semente fixa e notebook de análise |
| `ml/` | Notebook, treinamento, métricas e testes do modelo |
| `assets/` | Diagrama do banco e gráficos |
| `document/` | Relatório e roteiro do vídeo |

Para abrir o notebook de análise, instale `analise/requirements.txt` e abra `analise/Integrante 2.ipynb`.
Para reproduzir o treinamento, instale `ml/requirements.txt` e execute `python3 ml/treinar_modelo.py`.
Os dados são sintéticos. A Random Forest teve 59,5% de acurácia no teste separado por aluno.

## Entrega acadêmica

Completar a identificação do grupo e da turma e inserir os links do repositório privado e do vídeo
final no relatório. O vídeo deve ter até cinco minutos e mostrar a contribuição dos quatro integrantes.
