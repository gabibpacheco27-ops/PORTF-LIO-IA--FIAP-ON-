"""Executa scripts/consultas.sql e imprime os resultados como texto.

Uso:  python scripts/executar_consultas.py [banco.db] [--saida arquivo.txt]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from src.banco import RepositorioSQLite, listar_consultas  # noqa: E402


def tabela(colunas, linhas):
    textos = [[("" if v is None else str(v)) for v in l] for l in linhas]
    larguras = [max([len(c)] + [len(l[i]) for l in textos]) for i, c in enumerate(colunas)]
    formato = " | ".join(f"{{:<{w}}}" for w in larguras)
    saida = [formato.format(*colunas), "-+-".join("-" * w for w in larguras)]
    saida += [formato.format(*l) for l in textos]
    return "\n".join(saida)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("banco", nargs="?", default=str(RAIZ / "dados" / "educatodos.db"))
    p.add_argument("--saida", help="grava o resultado também neste arquivo de texto")
    p.add_argument("--max-linhas", type=int, default=15)
    args = p.parse_args()
    if not Path(args.banco).exists():
        print(f"Banco não encontrado: {args.banco}. Rode antes scripts/popular_demo.py "
              "ou o aplicativo.")
        return 1
    repo = RepositorioSQLite(args.banco)
    partes = [f"Banco: {args.banco}", f"Linhas por tabela: {repo.contagens()}"]
    for nome, descricao, sql in listar_consultas():
        colunas, linhas = repo.executar_consulta(sql)
        partes += ["", f"### {nome}", descricao, f"({len(linhas)} linha(s))"]
        partes.append(tabela(colunas, linhas[:args.max_linhas]) if linhas else "(sem linhas)")
        if len(linhas) > args.max_linhas:
            partes.append(f"... mais {len(linhas) - args.max_linhas} linha(s)")
    texto = "\n".join(partes) + "\n"
    print(texto)
    if args.saida:
        Path(args.saida).write_text(texto, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
