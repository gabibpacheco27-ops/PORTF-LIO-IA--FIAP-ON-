"""Cria um SQLite de demonstração com alunos e sessões inteiramente fictícios."""
import argparse
from pathlib import Path
import sys

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))

from src import armazenamento, educatodos
from src.banco import RepositorioSQLite, agora
from src.nivel_aluno import ORIGEM_INICIAL


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("banco", nargs="?", type=Path, default=RAIZ / "dados" / "demo.db")
    caminho = parser.parse_args().banco
    if caminho.resolve() == (RAIZ / "dados" / "educatodos.db").resolve():
        parser.error("Use um arquivo separado do banco de progresso.")

    repo = RepositorioSQLite(caminho)
    if any(repo.contagens()[tabela] for tabela in ("ALUNO", "RESPOSTA", "DESEMPENHO")):
        parser.error("O banco já contém progresso. Informe outro caminho.")

    estado = armazenamento.dados_vazios()
    id_resposta = 0
    for id_aluno, serie in enumerate(educatodos.SERIES, start=1):
        estado["alunos"].append(dict(id_aluno=id_aluno, nome=f"Aluno Demo {id_aluno}",
                                     serie=serie, data_cadastro=agora()))
        for disciplina in educatodos.DISCIPLINAS:
            questao = educatodos.sortear_questao(disciplina, serie, "Básico")
            id_resposta += 1
            acertou = id_resposta % 3 != 0
            alternativa = questao["gabarito"]
            if not acertou:
                alternativa = next(letra for letra in "ABCD" if letra != alternativa)
            estado["respostas"].append(dict(
                id_resposta=id_resposta, id_aluno=id_aluno, id_questao=questao["id_questao"],
                alternativa=alternativa, acertou=int(acertou), tempo_seg=20,
                tentativas=1 if acertou else educatodos.MAX_TENTATIVAS, usou_dica=0,
                data_resposta=agora(),
            ))
            estado["desempenho"].append(dict(
                id_aluno=id_aluno, disciplina=disciplina, taxa_acerto=100 * int(acertou),
                nivel_previsto="Básico", origem_nivel=ORIGEM_INICIAL, data_calculo=agora(),
            ))
    repo.importar_interacoes_csv(RAIZ / "data" / "interacoes_alunos.csv")
    repo.salvar(estado)
    print(f"Banco de demonstração: {caminho}")
    print(repo.contagens())


if __name__ == "__main__":
    main()
