-- =====================================================================
-- EducaTodos - consultas analíticas (Integrante 4)
-- Execução: python scripts/executar_consultas.py [caminho_do_banco]
-- Formato: cada consulta começa com "-- @consulta nome", seguido de
-- comentários com a descrição e de um SELECT terminado em ponto e vírgula.
-- Consultas 1 a 8 usam os dados do aplicativo (ALUNO, RESPOSTA, ...).
-- Consultas 9 a 11 usam a base SIMULADA (INTERACAO_SIMULADA).
-- =====================================================================

-- @consulta 01_taxa_acerto_por_aluno_disciplina
-- Quantidade de respostas, acertos e taxa de acerto de cada aluno em cada disciplina.
SELECT a.id_aluno, a.nome, q.disciplina,
       COUNT(*)                         AS respostas,
       SUM(r.acertou)                   AS acertos,
       ROUND(100.0 * AVG(r.acertou), 1) AS taxa_acerto_pct
  FROM RESPOSTA r
  JOIN ALUNO a   ON a.id_aluno   = r.id_aluno
  JOIN QUESTAO q ON q.id_questao = r.id_questao
 GROUP BY a.id_aluno, a.nome, q.disciplina
 ORDER BY a.id_aluno, q.disciplina;

-- @consulta 02_taxa_acerto_por_serie_disciplina
-- Taxa de acerto agregada por série e disciplina (visão da turma).
SELECT a.serie, q.disciplina,
       COUNT(DISTINCT a.id_aluno)       AS alunos,
       COUNT(*)                         AS respostas,
       ROUND(100.0 * AVG(r.acertou), 1) AS taxa_acerto_pct
  FROM RESPOSTA r
  JOIN ALUNO a   ON a.id_aluno   = r.id_aluno
  JOIN QUESTAO q ON q.id_questao = r.id_questao
 GROUP BY a.serie, q.disciplina
 ORDER BY a.serie, q.disciplina;

-- @consulta 03_questoes_mais_erradas
-- Ranking das questões com maior percentual de erro (útil para revisar o banco de questões).
SELECT q.id_questao, q.disciplina, q.serie, q.dificuldade,
       COUNT(*)                                AS respostas,
       COUNT(*) - SUM(r.acertou)               AS erros,
       ROUND(100.0 * (1 - AVG(r.acertou)), 1)  AS erro_pct
  FROM RESPOSTA r
  JOIN QUESTAO q ON q.id_questao = r.id_questao
 GROUP BY q.id_questao, q.disciplina, q.serie, q.dificuldade
 ORDER BY erro_pct DESC, erros DESC, q.id_questao
 LIMIT 10;

-- @consulta 04_tempo_e_dicas_por_disciplina
-- Tempo médio por resposta, uso de dica e taxa de acerto com e sem dica.
SELECT q.disciplina,
       COUNT(*)                                                    AS respostas,
       ROUND(AVG(r.tempo_seg), 1)                                  AS tempo_medio_seg,
       ROUND(100.0 * AVG(r.usou_dica), 1)                          AS usou_dica_pct,
       ROUND(100.0 * AVG(CASE WHEN r.usou_dica = 1 THEN r.acertou END), 1) AS acerto_com_dica_pct,
       ROUND(100.0 * AVG(CASE WHEN r.usou_dica = 0 THEN r.acertou END), 1) AS acerto_sem_dica_pct
  FROM RESPOSTA r
  JOIN QUESTAO q ON q.id_questao = r.id_questao
 GROUP BY q.disciplina
 ORDER BY q.disciplina;

-- @consulta 05_historico_nivel_por_aluno
-- Histórico completo de níveis calculados, com a origem (modelo ou provisório).
SELECT d.id_aluno, a.nome, d.disciplina, d.data_calculo,
       ROUND(100.0 * d.taxa_acerto, 1) AS taxa_acerto_pct,
       d.nivel_previsto, d.origem_nivel
  FROM DESEMPENHO d
  JOIN ALUNO a ON a.id_aluno = d.id_aluno
 ORDER BY d.id_aluno, d.disciplina, d.id_desempenho;

-- @consulta 06_nivel_atual_por_aluno_disciplina
-- Última medição de cada aluno em cada disciplina (nível atual).
SELECT id_aluno, disciplina, nivel_previsto AS nivel_atual, origem_nivel,
       ROUND(100.0 * taxa_acerto, 1) AS taxa_acerto_pct, data_calculo
  FROM (SELECT d.*, ROW_NUMBER() OVER (PARTITION BY id_aluno, disciplina
                                       ORDER BY id_desempenho DESC) AS posicao
          FROM DESEMPENHO d)
 WHERE posicao = 1
 ORDER BY id_aluno, disciplina;

-- @consulta 07_evolucao_somente_nivel_do_modelo
-- Variação da taxa de acerto entre a primeira e a última medição por aluno e disciplina,
-- contando APENAS medições cuja origem é modelo (nível provisório não é avanço de aprendizado).
-- Sem medições de modelo, o resultado é vazio por definição.
WITH m AS (SELECT * FROM DESEMPENHO WHERE origem_nivel LIKE 'modelo%'),
     ext AS (SELECT id_aluno, disciplina, COUNT(*) AS n,
                    MIN(id_desempenho) AS primeira, MAX(id_desempenho) AS ultima
               FROM m GROUP BY id_aluno, disciplina HAVING COUNT(*) >= 2)
SELECT e.id_aluno, e.disciplina, e.n AS medicoes,
       p.nivel_previsto AS nivel_inicial, u.nivel_previsto AS nivel_atual,
       ROUND(100.0 * (u.taxa_acerto - p.taxa_acerto), 1) AS variacao_taxa_pontos
  FROM ext e
  JOIN m p ON p.id_desempenho = e.primeira
  JOIN m u ON u.id_desempenho = e.ultima
 ORDER BY e.id_aluno, e.disciplina;

-- @consulta 08_alunos_para_reforco
-- Combinações aluno/disciplina com pelo menos 3 respostas e taxa de acerto abaixo de 50%
SELECT a.id_aluno, a.nome, a.serie, q.disciplina,
       COUNT(*) AS respostas,
       ROUND(100.0 * AVG(r.acertou), 1) AS taxa_acerto_pct
  FROM RESPOSTA r
  JOIN ALUNO a   ON a.id_aluno   = r.id_aluno
  JOIN QUESTAO q ON q.id_questao = r.id_questao
 GROUP BY a.id_aluno, a.nome, a.serie, q.disciplina
HAVING COUNT(*) >= 3 AND AVG(r.acertou) < 0.5
 ORDER BY taxa_acerto_pct, a.id_aluno;

-- @consulta 09_simulado_resumo_por_serie_disciplina
-- BASE SIMULADA: volume, taxa de acerto, tempo médio e uso de dica por série e disciplina.
SELECT serie, disciplina,
       COUNT(*)                         AS interacoes,
       COUNT(DISTINCT id_aluno_sim)     AS alunos_simulados,
       ROUND(100.0 * AVG(COALESCE(taxa_acerto, acertou)), 1)   AS taxa_acerto_pct,
       ROUND(AVG(tempo_seg), 1)         AS tempo_medio_seg,
       ROUND(100.0 * AVG(usou_dica), 1) AS usou_dica_pct
  FROM INTERACAO_SIMULADA
 GROUP BY serie, disciplina
 ORDER BY serie, disciplina;

-- @consulta 10_simulado_nivel_diagnostico_por_disciplina
-- BASE SIMULADA: distribuição do nível diagnóstico (alvo simulado) por disciplina.
SELECT disciplina, nivel_diagnostico, COUNT(*) AS interacoes,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY disciplina), 1) AS pct_na_disciplina
  FROM INTERACAO_SIMULADA
 GROUP BY disciplina, nivel_diagnostico
 ORDER BY disciplina, nivel_diagnostico;

-- @consulta 11_simulado_interacoes_por_aluno_disciplina
-- BASE SIMULADA: quantas interações cada par aluno/disciplina tem (pouca evidência por par limita o modelo).
SELECT disciplina, COUNT(*) AS pares_aluno_disciplina,
       ROUND(AVG(n), 1) AS media_interacoes, MAX(n) AS maximo_interacoes,
       SUM(CASE WHEN n < 10 THEN 1 ELSE 0 END) AS com_menos_de_10_interacoes
  FROM (SELECT id_aluno_sim, disciplina, COUNT(*) AS n
          FROM INTERACAO_SIMULADA GROUP BY id_aluno_sim, disciplina)
 GROUP BY disciplina
 ORDER BY disciplina;

-- @consulta 12_verificacao_respostas_orfas
-- Conferência de integridade: deve retornar 0 (o banco já impede respostas sem aluno ou questão).
SELECT COUNT(*) AS respostas_orfas
  FROM RESPOSTA r
  LEFT JOIN ALUNO a   ON a.id_aluno   = r.id_aluno
  LEFT JOIN QUESTAO q ON q.id_questao = r.id_questao
 WHERE a.id_aluno IS NULL OR q.id_questao IS NULL;
