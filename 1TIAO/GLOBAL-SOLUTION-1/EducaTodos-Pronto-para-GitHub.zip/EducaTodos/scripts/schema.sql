-- =====================================================================
-- EducaTodos - esquema do banco de dados SQLite (Integrante 4)
-- Execucao segura mais de uma vez (CREATE ... IF NOT EXISTS).
-- Uso manual:  sqlite3 dados/educatodos.db < scripts/schema.sql
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- ALUNO: cadastro local (use apelido; nao armazenar dados pessoais).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ALUNO (
    id_aluno       INTEGER PRIMARY KEY,
    nome           TEXT NOT NULL CHECK (length(trim(nome)) BETWEEN 2 AND 80),
    serie          TEXT NOT NULL CHECK (serie IN
                   ('6º Ano','7º Ano','8º Ano','9º Ano','1º Médio','2º Médio','3º Médio')),
    data_cadastro  TEXT NOT NULL            -- ISO 8601
);

-- ---------------------------------------------------------------------
-- QUESTAO: banco de questoes do aplicativo (fonte: src/questoes.py).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS QUESTAO (
    id_questao                INTEGER PRIMARY KEY,
    disciplina                TEXT NOT NULL CHECK (disciplina IN
                              ('Matemática','Português','Ciências','História')),
    serie                     TEXT NOT NULL CHECK (serie IN
                              ('6º Ano','7º Ano','8º Ano','9º Ano','1º Médio','2º Médio','3º Médio')),
    dificuldade               TEXT NOT NULL CHECK (dificuldade IN ('Básico','Intermediário','Avançado')),
    enunciado                 TEXT NOT NULL,
    alternativa_A             TEXT NOT NULL,
    alternativa_B             TEXT NOT NULL,
    alternativa_C             TEXT NOT NULL,
    alternativa_D             TEXT NOT NULL,
    gabarito                  TEXT NOT NULL CHECK (gabarito IN ('A','B','C','D')),
    dica                      TEXT,
    explicacao_basica         TEXT NOT NULL,
    explicacao_intermediaria  TEXT NOT NULL,
    explicacao_avancada       TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- RESPOSTA: uma linha por questao apresentada ao aluno.
-- serie e disciplina NAO sao gravadas aqui: obtidas por JOIN
-- (evita redundancia e inconsistencia).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RESPOSTA (
    id_resposta    INTEGER PRIMARY KEY,
    id_aluno       INTEGER NOT NULL REFERENCES ALUNO(id_aluno),
    id_questao     INTEGER NOT NULL REFERENCES QUESTAO(id_questao),
    alternativa    TEXT NOT NULL CHECK (alternativa IN ('A','B','C','D')),
    acertou        INTEGER NOT NULL CHECK (acertou IN (0,1)),
    tempo_seg      REAL NOT NULL CHECK (tempo_seg >= 0),
    tentativas     INTEGER NOT NULL CHECK (tentativas >= 1),
    usou_dica      INTEGER NOT NULL CHECK (usou_dica IN (0,1)),
    data_resposta  TEXT NOT NULL,           -- ISO 8601
    id_sessao      TEXT
);
CREATE INDEX IF NOT EXISTS idx_resposta_aluno   ON RESPOSTA(id_aluno);
CREATE INDEX IF NOT EXISTS idx_resposta_questao ON RESPOSTA(id_questao);

-- Regras que o SQLite nao expressa com CHECK (dependem de outras tabelas):
--   1) aluno e questao precisam existir;
--   2) a questao pode estar ate duas series distante da serie do aluno;
--   3) acertou deve conferir com o gabarito.
DROP TRIGGER IF EXISTS trg_resposta_coerencia;
CREATE TRIGGER trg_resposta_coerencia
BEFORE INSERT ON RESPOSTA
BEGIN
    SELECT RAISE(ABORT, 'Aluno inexistente')
    WHERE NOT EXISTS (SELECT 1 FROM ALUNO WHERE id_aluno = NEW.id_aluno);
    SELECT RAISE(ABORT, 'Questao inexistente')
    WHERE NOT EXISTS (SELECT 1 FROM QUESTAO WHERE id_questao = NEW.id_questao);
    SELECT RAISE(ABORT, 'Questao fora da faixa de series do aluno')
    WHERE ABS(
        (SELECT INSTR('6789123', SUBSTR(serie,1,1)) FROM ALUNO WHERE id_aluno = NEW.id_aluno)
        - (SELECT INSTR('6789123', SUBSTR(serie,1,1)) FROM QUESTAO WHERE id_questao = NEW.id_questao)
    ) > 2;
    SELECT RAISE(ABORT, 'Campo acertou nao confere com o gabarito')
    WHERE NEW.acertou IS NOT
          (NEW.alternativa = (SELECT gabarito FROM QUESTAO WHERE id_questao = NEW.id_questao));
END;

-- ---------------------------------------------------------------------
-- DESEMPENHO: historico de niveis calculados (varias linhas por
-- aluno/disciplina). origem_nivel distingue nivel previsto por modelo de
-- nivel provisorio, para que o provisorio nao conte como aprendizado.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS DESEMPENHO (
    id_desempenho   INTEGER PRIMARY KEY AUTOINCREMENT,
    id_aluno        INTEGER NOT NULL REFERENCES ALUNO(id_aluno),
    disciplina      TEXT NOT NULL CHECK (disciplina IN
                    ('Matemática','Português','Ciências','História')),
    taxa_acerto     REAL NOT NULL CHECK (taxa_acerto BETWEEN 0 AND 1),
    nivel_previsto  TEXT NOT NULL CHECK (nivel_previsto IN ('Básico','Intermediário','Avançado')),
    origem_nivel    TEXT NOT NULL,
    data_calculo    TEXT NOT NULL            -- ISO 8601
);
CREATE INDEX IF NOT EXISTS idx_desempenho_aluno ON DESEMPENHO(id_aluno, disciplina);

-- ---------------------------------------------------------------------
-- INTERACAO_SIMULADA: base estatistica SIMULADA do Integrante 2
-- (data/interacoes_alunos.csv). Fica em tabela separada, SEM chave
-- estrangeira: os ids de aluno e de questao do CSV nao correspondem aos
-- do aplicativo. Nao misturar com resultados de alunos reais.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS INTERACAO_SIMULADA (
    id_interacao       INTEGER PRIMARY KEY AUTOINCREMENT,
    id_aluno_sim       INTEGER NOT NULL,
    disciplina         TEXT NOT NULL,
    id_questao_sim     INTEGER NOT NULL,
    serie              TEXT NOT NULL,
    tentativas         INTEGER NOT NULL CHECK (tentativas >= 1),
    usou_dica          INTEGER NOT NULL CHECK (usou_dica IN (0,1)),
    tempo_seg          REAL NOT NULL CHECK (tempo_seg > 0),
    data               TEXT NOT NULL,
    nota_diagnostica   REAL NOT NULL,
    nivel_diagnostico  TEXT NOT NULL CHECK (nivel_diagnostico IN ('Básico','Intermediário','Avançado')),
    acertou            INTEGER NOT NULL CHECK (acertou IN (0,1)),
    taxa_acerto        REAL CHECK (taxa_acerto BETWEEN 0 AND 1),
    origem             TEXT NOT NULL DEFAULT 'simulado'
);
CREATE INDEX IF NOT EXISTS idx_sim_aluno ON INTERACAO_SIMULADA(id_aluno_sim, disciplina);
