"""Aplicação Python do EducaTodos."""
