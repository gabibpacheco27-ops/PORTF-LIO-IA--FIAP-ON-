"""
EducaTodos - plataforma de reforço escolar (POC)
Integrante 1: Aplicação Python (núcleo do sistema)

O aluno escolhe a disciplina, responde exercícios da sua série e recebe a
explicação adaptada ao seu nível (Básico, Intermediário ou Avançado).
O nível vem do modelo de Machine Learning do integrante 3 (nivel_aluno.py),
o progresso é gravado em JSON e no banco do integrante 4 (armazenamento.py)
e os textos podem ser ouvidos em voz alta (audio.py).

Como rodar:  python educatodos.py
"""

import random
import sys
import time
from datetime import date, datetime

from uuid import uuid4

if __package__:
    from . import armazenamento
    from . import audio
    from . import nivel_aluno
    from .nivel_aluno import NIVEIS
    from .questoes import DISCIPLINAS, QUESTOES, SERIES, normalizar_serie
else:
    import armazenamento
    import audio
    import nivel_aluno
    from nivel_aluno import NIVEIS
    from questoes import DISCIPLINAS, QUESTOES, SERIES, normalizar_serie


# Nível do aluno -> dificuldade da questão sorteada
DIFICULDADE_POR_NIVEL = {"Básico": "fácil", "Intermediário": "média", "Avançado": "difícil"}
ORDEM_DIFICULDADE = ("fácil", "média", "difícil")
MAX_TENTATIVAS = 3
MAX_QUESTOES_POR_RODADA = 10
MAX_DISTANCIA_SERIE = 2  # no máximo 2 séries acima ou abaixo da série do aluno

# Estado da sessão: quem está usando o programa agora e as preferências dele
sessao = {"aluno": None, "ultima_explicacao": None, "modo_acessivel": False}


# ======================================================================
# VALIDAÇÃO DE ENTRADAS (try/except)
# ======================================================================

def ler_inteiro(mensagem, minimo, maximo):
    """Pede um número inteiro até o usuário digitar um valor válido entre minimo e maximo."""
    while True:
        texto = input(mensagem).strip()
        try:
            # isdecimal + isascii recusam coisas como "1_0" ou "+3", que o int() aceitaria
            if not (texto.isascii() and texto.isdecimal()):
                raise ValueError
            numero = int(texto)
        except ValueError:
            print(f"  Entrada inválida: '{texto}' não é um número inteiro.")
            continue
        if minimo <= numero <= maximo:
            return numero
        print(f"  Digite um número entre {minimo} e {maximo}.")


def formatar_nome(nome):
    """Deixa a 1ª letra de cada palavra maiúscula, menos 'da', 'de', 'do', 'das', 'dos' e 'e'."""
    minusculas = ("da", "de", "do", "das", "dos", "e")
    palavras = nome.lower().split()
    return " ".join(p if (p in minusculas and i > 0) else p.capitalize()
                    for i, p in enumerate(palavras))


def ler_nome(mensagem):
    """Pede um nome com pelo menos 2 letras, só letras, espaços, hífen e apóstrofo."""
    while True:
        nome = " ".join(input(mensagem).split())  # tira espaços sobrando
        try:
            if sum(c.isalpha() for c in nome) < 2:
                raise ValueError("o nome precisa ter pelo menos 2 letras")
            if len(nome) > 60:
                raise ValueError("o nome pode ter no máximo 60 caracteres")
            if not all(c.isalpha() or c in " '-" for c in nome):
                raise ValueError("use apenas letras e espaços")
            return formatar_nome(nome)
        except ValueError as erro:
            print(f"  Nome inválido: {erro}.")


def ler_sim_nao(mensagem):
    """Pergunta de sim ou não. Devolve True para sim e False para não."""
    while True:
        resposta = input(mensagem).strip().upper()
        if resposta in ("S", "SIM"):
            return True
        if resposta in ("N", "NAO", "NÃO"):
            return False
        print("  Responda S para sim ou N para não.")


def escolher_da_lista(titulo, opcoes):
    """Mostra uma lista numerada e devolve o item escolhido."""
    print(f"\n{titulo}")
    for numero, opcao in enumerate(opcoes, start=1):
        print(f"  {numero} - {opcao}")
    escolha = ler_inteiro("Escolha: ", 1, len(opcoes))
    return opcoes[escolha - 1]


def decimal_br(numero, casas=1):
    """Formata número com vírgula, como se escreve em português: 12.5 -> '12,5'."""
    return f"{numero:.{casas}f}".replace(".", ",")


# ======================================================================
# FUNÇÕES PRINCIPAIS
# ======================================================================

def cadastrar_aluno(dados):
    """Cadastra um aluno novo (tabela ALUNO) e já deixa ele conectado."""
    print("\n--- Cadastro de aluno ---")
    nome = ler_nome("Nome do aluno: ")
    for existente in dados["alunos"]:
        if existente["nome"] == nome:
            print(f"  Já existe um aluno com esse nome (nº {existente['id_aluno']}, {existente['serie']}).")
            if not ler_sim_nao("  Cadastrar outro aluno com o mesmo nome? (S/N): "):
                print("  Para continuar com o cadastro existente, use a opção 2.")
                return None
            break
    serie = escolher_da_lista("Em qual série você está?", SERIES)
    aluno = {
        "id_aluno": armazenamento.proximo_id(dados["alunos"], "id_aluno",
                                             armazenamento.PRIMEIRO_ID_ALUNO),
        "nome": nome,
        "serie": serie,
        "data_cadastro": date.today().isoformat(),
    }
    armazenamento.registrar_aluno(dados, aluno)
    sessao["aluno"] = aluno
    print(f"\nBem-vindo(a), {nome}! Seu número de aluno é {aluno['id_aluno']}. Guarde para entrar depois.")
    return aluno


def entrar_aluno(dados):
    """Entra com um aluno já cadastrado, pelo número de aluno."""
    if not dados["alunos"]:
        print("\nNenhum aluno cadastrado ainda. Use a opção 1.")
        return None
    print("\nAlunos cadastrados:")
    for aluno in dados["alunos"]:
        print(f"  {aluno['id_aluno']} - {aluno['nome']} ({aluno['serie']})")
    ids = [aluno["id_aluno"] for aluno in dados["alunos"]]
    while True:
        id_digitado = ler_inteiro("Digite o seu número de aluno: ", min(ids), max(ids))
        for aluno in dados["alunos"]:
            if aluno["id_aluno"] == id_digitado:
                sessao["aluno"] = aluno
                print(f"\nOlá de novo, {aluno['nome']}!")
                return aluno
        print("  Esse número não existe. Confira a lista acima.")


def sortear_questao(disciplina, serie, nivel, excluir=(), banco=QUESTOES, rng=random):
    """
    Sorteia uma questão da disciplina, o mais perto possível da série do aluno
    e da dificuldade do nível dele. Não repete questões em 'excluir' e não passa
    de MAX_DISTANCIA_SERIE séries de distância. Devolve None se não houver questão.

    Distância = 2 x (diferença de série) + (diferença de dificuldade):
    a série pesa o dobro, porque conteúdo de outra série atrapalha mais que a dificuldade.
    ('banco' e 'rng' existem para os testes poderem usar dados e sorteios controlados.)
    """
    if disciplina not in DISCIPLINAS:
        raise ValueError(f"disciplina inválida: {disciplina}")
    serie = normalizar_serie(serie)
    if serie not in SERIES:
        raise ValueError(f"série inválida: {serie}")
    if nivel not in DIFICULDADE_POR_NIVEL:
        raise ValueError(f"nível inválido: {nivel}")

    alvo_serie = SERIES.index(serie)
    alvo_dificuldade = ORDEM_DIFICULDADE.index(DIFICULDADE_POR_NIVEL[nivel])

    candidatas = []
    for questao in banco:
        diferenca_serie = abs(SERIES.index(questao["serie"]) - alvo_serie)
        if (questao["disciplina"] == disciplina and questao["id_questao"] not in excluir
                and diferenca_serie <= MAX_DISTANCIA_SERIE):
            diferenca_dificuldade = abs(ORDEM_DIFICULDADE.index(questao["dificuldade"]) - alvo_dificuldade)
            candidatas.append((2 * diferenca_serie + diferenca_dificuldade, questao))
    if not candidatas:
        return None

    menor = min(distancia for distancia, _ in candidatas)
    melhores = [questao for distancia, questao in candidatas if distancia == menor]
    return rng.choice(melhores)


def corrigir_resposta(questao, resposta):
    """Devolve a tupla (acertou, gabarito)."""
    acertou = resposta.strip().upper() == questao["gabarito"]
    return acertou, questao["gabarito"]


def calcular_taxa_acerto(respostas, disciplina=None):
    """Taxa de acerto de 0 a 100 (%). Se passar a disciplina, filtra por ela."""
    if disciplina is not None:
        respostas = [r for r in respostas if r["disciplina"] == disciplina]
    if not respostas:
        return 0.0
    return 100 * sum(r["acertou"] for r in respostas) / len(respostas)


def obter_explicacao(questao, nivel, simplificado=False):
    """
    Adaptação: devolve a explicação na linguagem do nível do aluno.
    No modo de texto simplificado (acessibilidade), devolve sempre a básica.
    """
    campos = {
        "Básico": "explicacao_basica",
        "Intermediário": "explicacao_intermediaria",
        "Avançado": "explicacao_avancada",
    }
    if nivel not in campos:
        raise ValueError(f"nível inválido: {nivel}")
    if simplificado:
        return questao["explicacao_basica"]
    return questao[campos[nivel]]


# ======================================================================
# APOIO
# ======================================================================

def respostas_do_aluno(dados, id_aluno, disciplina=None):
    """Lista as respostas de um aluno (e de uma disciplina, se informada)."""
    respostas = [r for r in dados["respostas"] if r["id_aluno"] == id_aluno]
    if disciplina is not None:
        respostas = [r for r in respostas if r["disciplina"] == disciplina]
    return respostas


def nivel_atual(dados, id_aluno, disciplina, serie):
    """Tupla (nivel, origem) do aluno naquela disciplina."""
    return nivel_aluno.definir_nivel(respostas_do_aluno(dados, id_aluno, disciplina), disciplina=disciplina, serie=serie)


def texto_da_questao(questao):
    """Enunciado e alternativas em texto corrido, para ler em voz alta."""
    alternativas = ". ".join(f"Letra {letra}: {texto}" for letra, texto in questao["alternativas"].items())
    return f"{questao['enunciado']} {alternativas}."


def mostrar_questao(questao, numero, total):
    """Mostra a questão na tela. No modo acessível, mostra só o essencial e lê em voz alta."""
    if sessao["modo_acessivel"]:
        print(f"\nQuestão {numero} de {total}")
        print(questao["enunciado"])
        for letra, texto in questao["alternativas"].items():
            print(f"\n  {letra}) {texto}")
        print()
        audio.falar(texto_da_questao(questao))
        return
    print(f"\nQuestão {numero} de {total}  |  {questao['disciplina']} - {questao['serie']} - {questao['dificuldade']}")
    print(questao["enunciado"])
    for letra, texto in questao["alternativas"].items():
        print(f"  {letra}) {texto}")


def responder_questao(questao, *, incluir_alternativa=False):
    """
    Lê a resposta do aluno com até MAX_TENTATIVAS tentativas.
    Devolve a tupla (acertou, tentativas, usou_dica, tempo_seg),
    ou None se o aluno digitar 0 para encerrar a rodada.
    """
    usou_dica = False
    tentativas = 0
    acertou = False
    inicio = time.perf_counter()
    while tentativas < MAX_TENTATIVAS:
        entrada = input("Sua resposta (A, B, C ou D | ? = dica | 0 = encerrar): ").strip().upper()
        if entrada == "0":
            return None
        if entrada == "?":
            usou_dica = True
            print(f"  Dica: {questao['dica']}")
            continue
        if entrada not in ("A", "B", "C", "D"):
            print("  Opção inválida. Digite A, B, C ou D.")
            continue  # entrada inválida não gasta tentativa
        tentativas += 1
        acertou, gabarito = corrigir_resposta(questao, entrada)
        if acertou:
            print("  Certo!" if tentativas == 1 else f"  Certo, na {tentativas}ª tentativa!")
            break
        restam = MAX_TENTATIVAS - tentativas
        if restam:
            print(f"  Não foi dessa vez. Você ainda tem {restam} tentativa(s).")
        else:
            print(f"  A resposta certa era {gabarito}) {questao['alternativas'][gabarito]}.")
    tempo_seg = round(time.perf_counter() - inicio, 1)
    resultado = (acertou, tentativas, usou_dica, tempo_seg)
    return (*resultado, entrada) if incluir_alternativa else resultado


def evolucao_do_nivel(dados, id_aluno, disciplina):
    """Lista de (data, nivel) mostrando só quando o nível mudou (indicador de evolução)."""
    registros = sorted((d for d in dados["desempenho"]
                        if d["id_aluno"] == id_aluno and d["disciplina"] == disciplina),
                       key=lambda d: d["data_calculo"])
    evolucao = []
    for registro in registros:
        if not evolucao or evolucao[-1][1] != registro["nivel_previsto"]:
            evolucao.append((registro["data_calculo"][:10], registro["nivel_previsto"]))
    return evolucao


# ======================================================================
# OPÇÕES DO MENU
# ======================================================================

def fazer_exercicios(dados):
    """Rodada de exercícios: escolhe disciplina e quantidade, corrige e explica cada questão."""
    aluno = sessao["aluno"]
    if aluno is None:
        print("\nPrimeiro cadastre um aluno (opção 1) ou entre com um já cadastrado (opção 2).")
        return
    disciplina = escolher_da_lista("Qual disciplina você quer estudar?", DISCIPLINAS)
    quantidade = ler_inteiro(f"Quantas questões? (1 a {MAX_QUESTOES_POR_RODADA}): ", 1, MAX_QUESTOES_POR_RODADA)
    nivel_antes, _ = nivel_atual(dados, aluno["id_aluno"], disciplina, aluno["serie"])

    # Questões que o aluno já acertou antes só voltam quando as outras acabarem
    ja_acertadas = [r["id_questao"] for r in respostas_do_aluno(dados, aluno["id_aluno"], disciplina)
                    if r["acertou"]]
    usadas = []
    respondidas_agora = 0
    id_sessao = uuid4().hex

    for numero in range(1, quantidade + 1):
        nivel, origem = nivel_atual(dados, aluno["id_aluno"], disciplina, aluno["serie"])
        questao = sortear_questao(disciplina, aluno["serie"], nivel, excluir=usadas + ja_acertadas)
        if questao is None:
            questao = sortear_questao(disciplina, aluno["serie"], nivel, excluir=usadas)
        if questao is None:
            print(f"\nAcabaram as questões de {disciplina} para a sua série nesta rodada.")
            break
        usadas.append(questao["id_questao"])
        mostrar_questao(questao, numero, quantidade)

        resultado = responder_questao(questao, incluir_alternativa=True)
        if resultado is None:
            print("Rodada encerrada.")
            break
        acertou, tentativas, usou_dica, tempo_seg, alternativa = resultado
        respondidas_agora += 1

        explicacao = obter_explicacao(questao, nivel, simplificado=sessao["modo_acessivel"])
        sessao["ultima_explicacao"] = explicacao
        print(f"\nExplicação (nível {nivel}, definido por {origem}):\n  {explicacao}")
        if sessao["modo_acessivel"]:
            audio.falar(explicacao)

        resposta = {  # campos da tabela RESPOSTA do contrato (+ disciplina, para facilitar os filtros)
            "id_resposta": armazenamento.proximo_id(dados["respostas"], "id_resposta",
                                                    armazenamento.PRIMEIRO_ID_RESPOSTA),
            "id_aluno": aluno["id_aluno"],
            "id_questao": questao["id_questao"],
            "id_sessao": id_sessao,
            "alternativa": alternativa,
            "disciplina": disciplina,
            "acertou": int(acertou),
            "tempo_seg": tempo_seg,
            "tentativas": tentativas,
            "usou_dica": int(usou_dica),
            "data_resposta": datetime.now().isoformat(timespec="seconds"),
        }
        armazenamento.registrar_resposta(dados, resposta)

    if respondidas_agora == 0:
        return  # nada respondido nesta rodada: não grava desempenho repetido
    respostas = respostas_do_aluno(dados, aluno["id_aluno"], disciplina)
    nivel_depois, origem = nivel_atual(dados, aluno["id_aluno"], disciplina, aluno["serie"])
    taxa = calcular_taxa_acerto(respostas)
    armazenamento.registrar_desempenho(dados, {  # tabela DESEMPENHO do contrato
        "id_aluno": aluno["id_aluno"],
        "disciplina": disciplina,
        "taxa_acerto": round(taxa, 1),
        "nivel_previsto": nivel_depois,
        "origem_nivel": origem,
        "data_calculo": datetime.now().isoformat(timespec="seconds"),
    })
    print(f"\nTaxa de acerto em {disciplina}: {taxa:.0f}%")
    if nivel_depois != nivel_antes:
        print(f"Seu nível em {disciplina} mudou: {nivel_antes} -> {nivel_depois} ({origem}).")
    else:
        print(f"Seu nível em {disciplina}: {nivel_depois} ({origem}).")


def montar_relatorio(dados, aluno):
    """Texto do relatório do aluno (usado na tela e no arquivo TXT)."""
    linhas = [
        "EducaTodos - Relatório de desempenho",
        f"Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M')}",
        f"Aluno: {aluno['nome']} (nº {aluno['id_aluno']})  |  Série: {aluno['serie']}",
        "",
        f"{'Disciplina':<12} {'Questões':>8} {'Acertos':>8} {'De 1ª':>6} {'Taxa':>6} {'Tempo médio':>12}  Nível",
        "-" * 80,
    ]
    todas = respostas_do_aluno(dados, aluno["id_aluno"])
    evolucoes = []
    for disciplina in DISCIPLINAS:
        respostas = respostas_do_aluno(dados, aluno["id_aluno"], disciplina)
        if not respostas:
            linhas.append(f"{disciplina:<12} {0:>8} {'-':>8} {'-':>6} {'-':>6} {'-':>12}  ainda não estudou")
            continue
        acertos = sum(r["acertou"] for r in respostas)
        de_primeira = sum(1 for r in respostas if r["acertou"] and r["tentativas"] == 1)
        tempo = sum(r["tempo_seg"] for r in respostas) / len(respostas)
        nivel, origem = nivel_atual(dados, aluno["id_aluno"], disciplina, aluno["serie"])
        linhas.append(f"{disciplina:<12} {len(respostas):>8} {acertos:>8} {de_primeira:>6} "
                      f"{calcular_taxa_acerto(respostas):>5.0f}% {decimal_br(tempo):>10} s  {nivel} ({origem})")
        evolucao = evolucao_do_nivel(dados, aluno["id_aluno"], disciplina)
        if evolucao:
            caminho = " -> ".join(f"{datetime.fromisoformat(dia).strftime('%d/%m')} {nivel}"
                                  for dia, nivel in evolucao)
            evolucoes.append(f"  {disciplina}: {caminho}")
    linhas += [
        "-" * 80,
        f"Total: {len(todas)} questões, taxa de acerto geral de {calcular_taxa_acerto(todas):.0f}%",
        f"Tempo total de estudo: {decimal_br(sum(r['tempo_seg'] for r in todas) / 60)} min",
        "('De 1ª' = acertos na primeira tentativa)",
    ]
    if evolucoes:
        linhas += ["", "Evolução do nível:"] + evolucoes
    return "\n".join(linhas)


def ver_desempenho(dados):
    """Mostra o relatório do aluno conectado e oferece gravar em TXT."""
    aluno = sessao["aluno"]
    if aluno is None:
        print("\nPrimeiro cadastre um aluno (opção 1) ou entre com um já cadastrado (opção 2).")
        return
    relatorio = montar_relatorio(dados, aluno)
    print("\n" + relatorio)
    if ler_sim_nao("\nGerar o relatório em arquivo TXT? (S/N): "):
        nome_arquivo = f"relatorio_aluno_{aluno['id_aluno']}.txt"
        caminho = armazenamento.salvar_relatorio_txt(nome_arquivo, relatorio + "\n")
        if caminho:
            print(f"Relatório salvo em: {caminho}")


def ouvir_explicacao():
    """Lê a última explicação em voz alta."""
    if not sessao["ultima_explicacao"]:
        print("\nAinda não há explicação para ouvir. Faça um exercício primeiro (opção 3).")
        return
    print("\nLendo a última explicação em voz alta...")
    audio.falar(sessao["ultima_explicacao"])


def alternar_acessibilidade():
    """Liga ou desliga o modo acessível: texto simplificado e leitura automática em voz alta."""
    sessao["modo_acessivel"] = not sessao["modo_acessivel"]
    if sessao["modo_acessivel"]:
        print("\nModo acessível LIGADO: explicações em linguagem simples, tela mais limpa")
        print("e leitura automática da questão e da explicação em voz alta.")
    else:
        print("\nModo acessível DESLIGADO.")


def calcular_indicadores(dados):
    """
    Indicadores de impacto (ODS 4 e 10) com todos os alunos cadastrados.
    Devolve um dicionário com os números.
    """
    respostas = dados["respostas"]
    serie_do_aluno = {a["id_aluno"]: a["serie"] for a in dados["alunos"]}

    # Aluno avançou se, em alguma disciplina, o último nível é maior que o primeiro
    primeiro, ultimo = {}, {}
    for registro in sorted(dados["desempenho"], key=lambda d: d["data_calculo"]):
        chave = (registro["id_aluno"], registro["disciplina"])
        primeiro.setdefault(chave, registro["nivel_previsto"])
        ultimo[chave] = registro["nivel_previsto"]
    alunos_com_nivel = {id_aluno for id_aluno, _ in primeiro}
    avancaram = {id_aluno for (id_aluno, disc) in primeiro
                 if NIVEIS.index(ultimo[(id_aluno, disc)]) > NIVEIS.index(primeiro[(id_aluno, disc)])}

    # ODS 10: diferença entre ensino fundamental e ensino médio
    fundamental = [r for r in respostas if normalizar_serie(serie_do_aluno.get(r["id_aluno"], "")).endswith(" EF")]
    medio = [r for r in respostas if normalizar_serie(serie_do_aluno.get(r["id_aluno"], "")).endswith(" EM")]

    return {
        "alunos": len(dados["alunos"]),
        "respostas": len(respostas),
        "taxa_geral": calcular_taxa_acerto(respostas),
        "taxa_por_disciplina": {d: calcular_taxa_acerto(respostas, d) for d in DISCIPLINAS
                                if any(r["disciplina"] == d for r in respostas)},
        "tempo_total_min": sum(r["tempo_seg"] for r in respostas) / 60,
        "pct_avancaram": 100 * len(avancaram) / len(alunos_com_nivel) if alunos_com_nivel else 0.0,
        "taxa_fundamental": calcular_taxa_acerto(fundamental) if fundamental else None,
        "taxa_medio": calcular_taxa_acerto(medio) if medio else None,
    }


def mostrar_indicadores(dados):
    """Mostra o painel de indicadores de impacto de todos os alunos."""
    if not dados["respostas"]:
        print("\nAinda não há respostas para calcular os indicadores.")
        return
    ind = calcular_indicadores(dados)
    print("\n--- Indicadores de impacto (ODS 4 e 10) ---")
    print(f"Alunos cadastrados: {ind['alunos']}  |  Questões respondidas: {ind['respostas']}")
    print(f"Taxa de acerto média: {ind['taxa_geral']:.0f}%")
    for disciplina, taxa in ind["taxa_por_disciplina"].items():
        print(f"  {disciplina}: {taxa:.0f}%")
    print(f"Alunos que avançaram de nível: {ind['pct_avancaram']:.0f}%")
    print(f"Tempo total de estudo: {decimal_br(ind['tempo_total_min'])} min")
    if ind["taxa_fundamental"] is not None and ind["taxa_medio"] is not None:
        print(f"Acerto no fundamental: {ind['taxa_fundamental']:.0f}%  |  no médio: {ind['taxa_medio']:.0f}%")


# ======================================================================
# MENU PRINCIPAL
# ======================================================================

def mostrar_menu():
    """Mostra o menu com o aluno conectado no topo."""
    aluno = sessao["aluno"]
    quem = f"{aluno['nome']} ({aluno['serie']})" if aluno else "nenhum aluno conectado"
    acessivel = "ligado" if sessao["modo_acessivel"] else "desligado"
    print("\n" + "=" * 50)
    print(" EducaTodos - Reforço Escolar")
    print(f" Aluno: {quem}")
    print("=" * 50)
    print(" 1 - Cadastrar aluno")
    print(" 2 - Entrar com aluno já cadastrado")
    print(" 3 - Fazer exercícios")
    print(" 4 - Ver meu desempenho")
    print(" 5 - Ouvir explicação (modo áudio)")
    print(f" 6 - Modo acessível ({acessivel})")
    print(" 7 - Indicadores de impacto")
    print(" 0 - Sair")


def main():
    """Carrega os dados e roda o menu em loop até o usuário escolher sair."""
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # acentos certos no terminal do Windows
    except (AttributeError, ValueError):
        pass

    dados = armazenamento.carregar_dados()
    if nivel_aluno.MODELO_DISPONIVEL:
        print("Modelo de Machine Learning carregado: o nível será previsto por ele.")
    elif nivel_aluno.AVISO_MODELO:
        print(f"[aviso] Modelo não carregado: {nivel_aluno.AVISO_MODELO}. Usando a regra provisória.")
    if armazenamento.BANCO_ATIVO:
        print("Banco de dados SQLite conectado.")

    try:
        while True:
            mostrar_menu()
            opcao = ler_inteiro("Opção: ", 0, 7)
            if opcao == 0:
                break
            elif opcao == 1:
                cadastrar_aluno(dados)
            elif opcao == 2:
                entrar_aluno(dados)
            elif opcao == 3:
                fazer_exercicios(dados)
            elif opcao == 4:
                ver_desempenho(dados)
            elif opcao == 5:
                ouvir_explicacao()
            elif opcao == 6:
                alternar_acessibilidade()
            elif opcao == 7:
                mostrar_indicadores(dados)
    except (KeyboardInterrupt, EOFError):
        print()  # Ctrl+C ou fim da entrada: sai sem mostrar erro

    if armazenamento.salvar_dados(dados):
        print("Progresso salvo. Até a próxima!")
    else:
        print("Até a próxima! (o progresso desta sessão não pôde ser gravado)")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
