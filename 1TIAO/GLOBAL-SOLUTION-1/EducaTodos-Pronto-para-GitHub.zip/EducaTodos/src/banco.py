"""EducaTodos - camada de persistência em SQLite (Integrante 4).

Substitui o RepositorioJSON do aplicativo mantendo o mesmo contrato:

    repo = RepositorioSQLite("dados/educatodos.db")
    estado = repo.carregar()      # {'versao', 'alunos', 'respostas', 'desempenhos'}
    repo.salvar(estado)           # insere só o que é novo, em uma transação

Somente biblioteca padrão (sqlite3). Python 3.10+.
"""
from __future__ import annotations

import csv
import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from datetime import datetime
if __package__:
    from .questoes import QUESTOES, normalizar_serie
else:
    from questoes import QUESTOES, normalizar_serie


SERIES = ("6º Ano", "7º Ano", "8º Ano", "9º Ano", "1º Médio", "2º Médio", "3º Médio")


def agora():
    return datetime.now().isoformat(timespec="seconds")


RAIZ = Path(__file__).resolve().parent.parent
ARQUIVO_SCHEMA = RAIZ / "scripts" / "schema.sql"
ARQUIVO_CONSULTAS = RAIZ / "scripts" / "consultas.sql"
VERSAO_ESQUEMA = 2

COLUNAS_QUESTAO = ("id_questao", "disciplina", "serie", "dificuldade", "enunciado",
                   "alternativa_A", "alternativa_B", "alternativa_C", "alternativa_D",
                   "gabarito", "dica", "explicacao_basica", "explicacao_intermediaria",
                   "explicacao_avancada")
COLUNAS_RESPOSTA = ("id_resposta", "id_aluno", "id_questao", "alternativa", "acertou",
                    "tempo_seg", "tentativas", "usou_dica", "data_resposta", "id_sessao")
COLUNAS_DESEMPENHO = ("id_aluno", "disciplina", "taxa_acerto", "nivel_previsto",
                      "origem_nivel", "data_calculo")
COLUNAS_CSV_SIMULADO = ("id_aluno", "disciplina", "id_questao", "tentativas", "usou_dica",
                        "tempo_seg", "data", "serie", "nota_diagnostica",
                        "nivel_diagnostico", "acertou")
# O CSV do Integrante 2 abrevia o ensino médio; o aplicativo usa "1º Médio".
NORMALIZAR_SERIE = {"1º EM": "1º Médio", "2º EM": "2º Médio", "3º EM": "3º Médio"}


class RepositorioSQLite:
    """Persistência de alunos, respostas e histórico de desempenho."""

    def __init__(self, caminho):
        self.caminho = Path(caminho)
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        self.inicializar()

    # ------------------------------------------------------------------
    # infraestrutura
    # ------------------------------------------------------------------
    @contextmanager
    def _conexao(self):
        """Abre conexão, valida chaves estrangeiras e faz commit/rollback.

        Erros do SQLite viram ValueError, que o aplicativo já trata sem
        mostrar traceback ao aluno.
        """
        try:
            con = sqlite3.connect(self.caminho, timeout=10)
        except sqlite3.Error as erro:
            raise ValueError(f"Não foi possível abrir o banco: {erro}") from erro
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA foreign_keys = ON")
            yield con
            con.commit()
        except sqlite3.IntegrityError as erro:
            con.rollback()
            raise ValueError(f"Violação de integridade no banco: {erro}") from erro
        except sqlite3.Error as erro:
            con.rollback()
            raise ValueError(f"Banco inválido ou indisponível: {erro}") from erro
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def inicializar(self):
        """Cria as tabelas (se não existirem) e sincroniza o banco de questões."""
        mapa_serie = {
            "6º Ano EF": "6º Ano", "7º Ano EF": "7º Ano",
            "8º Ano EF": "8º Ano", "9º Ano EF": "9º Ano",
            "1º Ano EM": "1º Médio", "2º Ano EM": "2º Médio", "3º Ano EM": "3º Médio",
            "1º EM": "1º Médio", "2º EM": "2º Médio", "3º EM": "3º Médio",
        }
        mapa_dificuldade = {
            "fácil": "Básico", "facil": "Básico",
            "média": "Intermediário", "media": "Intermediário",
            "difícil": "Avançado", "dificil": "Avançado",
        }

        def _adaptar_questao(q):
            alts = q.get("alternativas") or {}
            serie_raw = str(q.get("serie", "")).strip()
            dif_raw = str(q.get("dificuldade", "")).strip()
            adaptada = {
                "id_questao": q.get("id_questao"),
                "disciplina": q.get("disciplina"),
                "serie": mapa_serie.get(serie_raw, serie_raw),
                "dificuldade": mapa_dificuldade.get(dif_raw.lower(), dif_raw),
                "enunciado": q.get("enunciado"),
                "alternativa_A": q.get("alternativa_A") or alts.get("A"),
                "alternativa_B": q.get("alternativa_B") or alts.get("B"),
                "alternativa_C": q.get("alternativa_C") or alts.get("C"),
                "alternativa_D": q.get("alternativa_D") or alts.get("D"),
                "gabarito": str(q.get("gabarito", "")).strip().upper(),
                "dica": q.get("dica"),
                "explicacao_basica": q.get("explicacao_basica") or "",
                "explicacao_intermediaria": q.get("explicacao_intermediaria") or "",
                "explicacao_avancada": q.get("explicacao_avancada") or "",
            }
            return tuple(adaptada[c] for c in COLUNAS_QUESTAO)

        sql = ARQUIVO_SCHEMA.read_text(encoding="utf-8")
        with self._conexao() as con:
            versao = con.execute("PRAGMA user_version").fetchone()[0]
            if versao not in (0, 1, VERSAO_ESQUEMA):
                raise ValueError(f"Versão de esquema não suportada: {versao}.")
            con.executescript(sql)
            colunas = {l["name"] for l in con.execute("PRAGMA table_info(RESPOSTA)")}
            if "id_sessao" not in colunas:
                con.execute("ALTER TABLE RESPOSTA ADD COLUMN id_sessao TEXT")
            simuladas = {l["name"] for l in con.execute("PRAGMA table_info(INTERACAO_SIMULADA)")}
            if "taxa_acerto" not in simuladas:
                con.execute("ALTER TABLE INTERACAO_SIMULADA ADD COLUMN taxa_acerto REAL")
            con.execute(f"PRAGMA user_version = {VERSAO_ESQUEMA}")
            marcadores = ", ".join("?" for _ in COLUNAS_QUESTAO)
            atualizacao = ", ".join(f"{c}=excluded.{c}" for c in COLUNAS_QUESTAO[1:])
            con.executemany(
                f"INSERT INTO QUESTAO ({', '.join(COLUNAS_QUESTAO)}) VALUES ({marcadores}) "
                f"ON CONFLICT(id_questao) DO UPDATE SET {atualizacao}",
                [_adaptar_questao(q) for q in QUESTOES])
    # ------------------------------------------------------------------
    # contrato usado pelo aplicativo (Integrante 1)
    # ------------------------------------------------------------------
    def carregar(self):
        """Reconstrói o dicionário de estado a partir do banco."""
        with self._conexao() as con:
            alunos = [dict(l) for l in con.execute(
                "SELECT id_aluno, nome, serie, data_cadastro FROM ALUNO ORDER BY id_aluno")]
            respostas = [dict(l) for l in con.execute(
                """SELECT r.id_resposta, r.id_aluno, r.id_questao, q.disciplina, r.acertou, r.tempo_seg, r.tentativas, r.usou_dica,
                          r.data_resposta, r.alternativa, r.id_sessao
                     FROM RESPOSTA r
                     JOIN ALUNO a  ON a.id_aluno   = r.id_aluno
                     JOIN QUESTAO q ON q.id_questao = r.id_questao
                    ORDER BY r.id_resposta""")]
            desempenhos = [dict(l) for l in con.execute(
                """SELECT id_desempenho, id_aluno, disciplina, taxa_acerto, nivel_previsto,
                          origem_nivel, data_calculo
                     FROM DESEMPENHO ORDER BY id_desempenho""")]
        gabaritos = {q["id_questao"]: q["gabarito"] for q in QUESTOES}
        if any(r["id_questao"] in gabaritos and
               bool(r["acertou"]) != (r["alternativa"] == gabaritos[r["id_questao"]])
               for r in respostas):
            raise ValueError("Banco com dados inconsistentes: resposta e gabarito divergem.")
        for aluno in alunos:
            aluno["serie"] = normalizar_serie(aluno["serie"])
        for desempenho in desempenhos:
            desempenho["taxa_acerto"] *= 100
        return {"alunos": alunos, "respostas": respostas, "desempenho": desempenhos}

    def salvar(self, estado):
        """Insere os registros novos em uma transação."""
        alunos = [dict(a, serie=_serie_sql(a["serie"])) for a in estado["alunos"]]
        respostas = [dict(r, id_sessao=r.get("id_sessao")) for r in estado["respostas"]]
        ids_novos = []
        with self._conexao() as con:
            con.execute("BEGIN IMMEDIATE")
            novos = self._novos(con, "ALUNO", "id_aluno", ("nome", "serie", "data_cadastro"), alunos)
            con.executemany(
                "INSERT INTO ALUNO (id_aluno, nome, serie, data_cadastro) VALUES (?,?,?,?)",
                [(a["id_aluno"], a["nome"], a["serie"], a["data_cadastro"]) for a in novos])
            novas = self._novos(con, "RESPOSTA", "id_resposta", COLUNAS_RESPOSTA[1:], respostas)
            con.executemany(
                f"INSERT INTO RESPOSTA ({', '.join(COLUNAS_RESPOSTA)}) "
                f"VALUES ({', '.join('?' for _ in COLUNAS_RESPOSTA)})",
                [tuple(r[c] for c in COLUNAS_RESPOSTA) for r in novas])
            for d in estado["desempenho"]:
                if "id_desempenho" not in d:
                    linha = dict(d, taxa_acerto=d["taxa_acerto"] / 100)
                    ids_novos.append((d, self._inserir_desempenho(con, linha)))
        for registro, id_desempenho in ids_novos:
            registro["id_desempenho"] = id_desempenho

    @staticmethod
    def _novos(con, tabela, chave, colunas, registros):
        """Separa os registros ainda não gravados e detecta conflito de conteúdo.

        Um id que já existe no banco com conteúdo diferente indica que outra
        instância do aplicativo gravou dados no mesmo arquivo: a operação é
        recusada (e desfeita) em vez de sobrescrever ou ignorar em silêncio.
        """
        gravados = {l[0]: tuple(l)[1:] for l in con.execute(
            f"SELECT {chave}, {', '.join(colunas)} FROM {tabela}")}
        novos = []
        for r in registros:
            atual = gravados.get(r[chave])
            if atual is None:
                novos.append(r)
            elif atual != tuple(r[c] for c in colunas):
                raise ValueError(f"Conflito em {tabela} (id {r[chave]}): o banco já tem outro "
                                 "conteúdo para este id. Há outra instância do aplicativo em uso?")
        return novos

    # ------------------------------------------------------------------
    # operações pontuais (nomes previstos no enunciado do grupo)
    # ------------------------------------------------------------------
    @staticmethod
    def _inserir_desempenho(con, d):
        cursor = con.execute(
            f"INSERT INTO DESEMPENHO ({', '.join(COLUNAS_DESEMPENHO)}) VALUES (?,?,?,?,?,?)",
            tuple(d[c] for c in COLUNAS_DESEMPENHO))
        return cursor.lastrowid

    def inserir_aluno(self, nome, serie, data_cadastro=None):
        """Cadastra um aluno e devolve o id_aluno gerado."""
        serie = _serie_sql(serie)
        if serie not in SERIES:
            raise ValueError("Série inválida.")
        with self._conexao() as con:
            cursor = con.execute(
                "INSERT INTO ALUNO (nome, serie, data_cadastro) VALUES (?,?,?)",
                (nome, serie, data_cadastro or agora()))
            return cursor.lastrowid

    def inserir_resposta(self, resposta):
        """Insere uma resposta (dict com os campos de RESPOSTA) e devolve o id.

        As regras do esquema (FKs, série coerente, acertou x gabarito) são
        verificadas pelo próprio banco.
        """
        dados = dict(resposta)
        dados.setdefault("id_resposta", None)
        dados.setdefault("id_sessao", None)
        with self._conexao() as con:
            cursor = con.execute(
                f"INSERT INTO RESPOSTA ({', '.join(COLUNAS_RESPOSTA)}) "
                f"VALUES ({', '.join('?' for _ in COLUNAS_RESPOSTA)})",
                tuple(dados[c] for c in COLUNAS_RESPOSTA))
            return cursor.lastrowid
    def salvar_nivel(self, id_aluno, disciplina, taxa_acerto, nivel, origem, data_calculo=None):
        """Registra uma medição de desempenho e devolve o id_desempenho."""
        registro = {"id_aluno": id_aluno, "disciplina": disciplina,
                    "taxa_acerto": taxa_acerto, "nivel_previsto": nivel,
                    "origem_nivel": origem, "data_calculo": data_calculo or agora()}
        with self._conexao() as con:
            return self._inserir_desempenho(con, registro)

    def buscar_desempenho(self, id_aluno, disciplina=None, somente_ultimo=False):
        """Histórico de desempenho (mais antigo primeiro) ou só a última medição."""
        sql = ("SELECT id_desempenho, id_aluno, disciplina, taxa_acerto, nivel_previsto, "
               "origem_nivel, data_calculo FROM DESEMPENHO WHERE id_aluno = ?")
        parametros = [id_aluno]
        if disciplina is not None:
            sql += " AND disciplina = ?"
            parametros.append(disciplina)
        sql += " ORDER BY id_desempenho " + ("DESC LIMIT 1" if somente_ultimo else "")
        with self._conexao() as con:
            return [dict(l) for l in con.execute(sql, parametros)]

    # ------------------------------------------------------------------
    # base simulada do Integrante 2 e consultas
    # ------------------------------------------------------------------
    def importar_interacoes_csv(self, caminho, substituir=True):
        """Carrega data/interacoes_alunos.csv em INTERACAO_SIMULADA."""
        mapa_series = {
            "6º Ano EF": "6º Ano", "7º Ano EF": "7º Ano",
            "8º Ano EF": "8º Ano", "9º Ano EF": "9º Ano",
            "1º Ano EM": "1º Médio", "2º Ano EM": "2º Médio", "3º Ano EM": "3º Médio",
            "1º EM": "1º Médio", "2º EM": "2º Médio", "3º EM": "3º Médio",
        }

        diagnosticos = {}
        arquivo_diag = Path(caminho).with_name("diagnostico_alunos.csv")
        if arquivo_diag.is_file():
            with arquivo_diag.open(newline="", encoding="utf-8-sig") as arquivo:
                diagnosticos = {
                    (l["id_aluno"], l["serie"], l["disciplina"]):
                    (float(l["nota_diagnostica"]), l["nivel_diagnostico"])
                    for l in csv.DictReader(arquivo)
                }

        linhas = []
        with Path(caminho).open(newline="", encoding="utf-8-sig") as arquivo:
            leitor = csv.DictReader(arquivo)
            campos = set(leitor.fieldnames or [])
            formato_resumo = {
                "id_aluno", "serie", "disciplina", "data_interacao",
                "tentativas", "acertos", "taxa_acerto", "tempo_seg", "usou_dica",
            }.issubset(campos)
            formato_questao = set(COLUNAS_CSV_SIMULADO).issubset(campos)

            if not (formato_resumo or formato_questao):
                raise ValueError(f"CSV sem as colunas esperadas: {', '.join(sorted(campos))}")

            for n, l in enumerate(leitor, start=2):
                try:
                    digitos_aluno = re.sub(r"\D", "", str(l["id_aluno"]))
                    id_aluno_num = int(digitos_aluno) if digitos_aluno else (n - 1)
                    serie_raw = l["serie"].strip()
                    serie = mapa_series.get(serie_raw, NORMALIZAR_SERIE.get(serie_raw, serie_raw))
                    if serie not in SERIES:
                        raise ValueError(f"série desconhecida: {l['serie']}")
                    total = float(l["tentativas"])
                    tempo_seg = float(l["tempo_seg"])
                    usou_dica = int(l["usou_dica"])
                    if not total.is_integer() or total < 1 or not tempo_seg > 0 or usou_dica not in (0, 1):
                        raise ValueError("tentativas, dica ou tempo inválidos")
                    tentativas = int(total)

                    if formato_resumo:
                        id_questao = 0
                        data_str = l["data_interacao"].strip()
                        taxa = float(l["taxa_acerto"])
                        if not 0 <= taxa <= 1:
                            raise ValueError("taxa de acerto fora da faixa")
                        nota, nivel = diagnosticos[(l["id_aluno"], serie_raw, l["disciplina"])]
                        # Campo legado por questão. A taxa da sessão é armazenada separadamente.
                        acertou = int(taxa >= 0.5)
                    else:
                        id_questao = int(l["id_questao"])
                        data_str = l["data"].strip()
                        nota = float(l["nota_diagnostica"])
                        nivel = l["nivel_diagnostico"].strip()
                        acertou = int(l["acertou"])
                        taxa = float(acertou)

                    linhas.append((
                        id_aluno_num, l["disciplina"].strip(), id_questao, serie,
                        tentativas, usou_dica, tempo_seg, data_str, nota, nivel, acertou, taxa,
                    ))
                except (ValueError, TypeError, KeyError) as erro:
                    raise ValueError(f"CSV inválido na linha {n}: {erro}") from erro

        with self._conexao() as con:
            if substituir:
                con.execute("DELETE FROM INTERACAO_SIMULADA")
            con.executemany(
                """INSERT INTO INTERACAO_SIMULADA
                   (id_aluno_sim, disciplina, id_questao_sim, serie, tentativas, usou_dica,
                    tempo_seg, data, nota_diagnostica, nivel_diagnostico, acertou, taxa_acerto)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                linhas,
            )
        return len(linhas)
    def contagens(self):
        """Número de linhas por tabela (conferência rápida)."""
        tabelas = ("ALUNO", "QUESTAO", "RESPOSTA", "DESEMPENHO", "INTERACAO_SIMULADA")
        with self._conexao() as con:
            return {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in tabelas}

    def executar_consulta(self, sql, parametros=()):
        """Executa uma consulta SELECT e devolve (colunas, linhas)."""
        if not re.match(r"\s*(SELECT|WITH)\b", sql, re.IGNORECASE):
            raise ValueError("Somente consultas SELECT são permitidas aqui.")
        with self._conexao() as con:
            cursor = con.execute(sql, parametros)
            colunas = [c[0] for c in cursor.description]
            return colunas, [tuple(l) for l in cursor.fetchall()]


def listar_consultas(caminho=ARQUIVO_CONSULTAS):
    """Lê scripts/consultas.sql e devolve [(nome, descricao, sql)].

    Formato: cada consulta começa com '-- @consulta nome' seguido de linhas
    de comentário com a descrição e do SELECT terminado em ';'.
    """
    texto = Path(caminho).read_text(encoding="utf-8")
    consultas = []
    for bloco in re.split(r"^-- @consulta\s+", texto, flags=re.MULTILINE)[1:]:
        linhas = bloco.splitlines()
        nome = linhas[0].strip()
        descricao = " ".join(l[2:].strip() for l in linhas[1:] if l.startswith("--"))
        sql = "\n".join(l for l in linhas[1:] if not l.startswith("--")).strip().rstrip(";")
        consultas.append((nome, descricao, sql))
    return consultas

# ------------------------------------------------------------------
# Ponte de compatibilidade com armazenamento.py (Integrante 1)
# ------------------------------------------------------------------

def _serie_sql(serie):
    return dict(zip(
        ("6º Ano EF", "7º Ano EF", "8º Ano EF", "9º Ano EF",
         "1º Ano EM", "2º Ano EM", "3º Ano EM"), SERIES
    )).get(normalizar_serie(serie), serie)
