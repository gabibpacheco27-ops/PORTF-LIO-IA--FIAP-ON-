"""Calcula o nível com o histórico de cada disciplina."""

from collections import defaultdict

if __package__:
    from .questoes import normalizar_serie
else:
    from questoes import normalizar_serie


NIVEIS = ("Básico", "Intermediário", "Avançado")  # do mais simples ao mais avançado
NIVEL_INICIAL = "Básico"
MIN_RESPOSTAS_PARA_PREVER = 3
MIN_SESSOES_PARA_MODELO = 10

# Origem do nível, mostrada ao aluno e gravada no relatório
ORIGEM_INICIAL = "nível inicial"
ORIGEM_MODELO = "modelo de Machine Learning"
ORIGEM_REGRA = "regra provisória"

# Tenta carregar o modelo do integrante 3. Se o arquivo não existir, segue sem ele.
AVISO_MODELO = None
try:
    if __package__:
        from .modelo_integracao import prever_nivel as _prever_nivel_modelo
    else:
        from modelo_integracao import prever_nivel as _prever_nivel_modelo
except ModuleNotFoundError as erro:
    _prever_nivel_modelo = None
    if erro.name != "modelo_integracao":  # o arquivo existe, mas falta uma biblioteca dentro dele
        AVISO_MODELO = f"o modelo_integracao.py precisa da biblioteca {erro.name}"
except Exception as erro:  # arquivo .joblib ausente, erro de sintaxe, versão diferente etc.
    _prever_nivel_modelo = None
    AVISO_MODELO = f"o modelo_integracao.py falhou ao carregar ({erro})"

MODELO_DISPONIVEL = _prever_nivel_modelo is not None
_ja_avisou_falha = False  # para avisar a falha do modelo uma vez só


def calcular_features(respostas):
    """
    Transforma as respostas de um aluno em uma disciplina nas 4 features
    combinadas com o integrante 3 (mesmas colunas da base simulada):
        taxa_acerto (0 a 1), tempo_medio (segundos),
        media_tentativas, taxa_dicas (0 a 1)
    """
    total = len(respostas)
    if total == 0:
        return {"taxa_acerto": 0.0, "tempo_medio": 0.0, "media_tentativas": 0.0, "taxa_dicas": 0.0}
    return {
        "taxa_acerto": sum(r["acertou"] for r in respostas) / total,
        "tempo_medio": sum(r["tempo_seg"] for r in respostas) / total,
        "media_tentativas": sum(r["tentativas"] for r in respostas) / total,
        "taxa_dicas": sum(r["usou_dica"] for r in respostas) / total,
    }


def calcular_features_sessoes(respostas):
    """Resume rodadas com 3 a 10 questões, como as sessões do CSV de treino."""
    sessoes = defaultdict(list)
    for resposta in respostas:
        if resposta.get("id_sessao"):
            sessoes[resposta["id_sessao"]].append(resposta)
    validas = [sessao for sessao in sessoes.values() if 3 <= len(sessao) <= 10]
    if len(validas) < MIN_SESSOES_PARA_MODELO:
        return None

    total = len(validas)
    return {
        "taxa_acerto": sum(sum(r["acertou"] for r in s) / len(s) for s in validas) / total,
        "tempo_medio": sum(sum(r["tempo_seg"] for r in s) for s in validas) / total,
        "media_tentativas": sum(map(len, validas)) / total,
        "taxa_dicas": sum(any(r["usou_dica"] for r in s) for s in validas) / total,
    }


def normalizar_nivel(valor):
    """Aceita o texto do nível (com ou sem acento, solto ou dentro de um array) e padroniza."""
    # O scikit-learn devolve um array com um item: pega esse item
    if hasattr(valor, "__len__") and not isinstance(valor, str):
        valor = list(valor)[0]
    if not isinstance(valor, str):
        # Número não é aceito de propósito: o LabelEncoder do scikit-learn ordena
        # em ordem alfabética (0 = Avançado), e adivinhar a ordem daria nível errado.
        raise ValueError("prever_nivel deve devolver o texto do nível "
                         "(use o inverse_transform do LabelEncoder)")
    texto = valor.strip().lower()
    mapa = {
        "básico": "Básico", "basico": "Básico",
        "intermediário": "Intermediário", "intermediario": "Intermediário",
        "avançado": "Avançado", "avancado": "Avançado",
    }
    if texto in mapa:
        return mapa[texto]
    raise ValueError(f"nível desconhecido devolvido pelo modelo: {valor}")


def regra_provisoria(features):
    """Regra simples usada só enquanto o modelo do integrante 3 não chega."""
    if features["taxa_acerto"] >= 0.75 and features["media_tentativas"] <= 1.5:
        return "Avançado"
    if features["taxa_acerto"] >= 0.45:
        return "Intermediário"
    return "Básico"


def definir_nivel(respostas, prever=None, *, disciplina=None, serie=None):
    """
    Devolve uma tupla (nivel, origem) para as respostas de UMA disciplina.
    O parâmetro prever permite testar com um modelo falso.
    """
    global _ja_avisou_falha
    if len(respostas) < MIN_RESPOSTAS_PARA_PREVER:
        return NIVEL_INICIAL, ORIGEM_INICIAL

    features = calcular_features(respostas)
    funcao = prever or _prever_nivel_modelo
    features_modelo = calcular_features_sessoes(respostas)
    if funcao is not None and features_modelo is not None:
        try:
            features_modelo["tempo_medio"] = max(0.1, features_modelo["tempo_medio"])
            resultado = funcao(**features_modelo, disciplina=disciplina,
                               serie=normalizar_serie(serie))
            return normalizar_nivel(resultado), ORIGEM_MODELO
        except Exception as erro:
            if not _ja_avisou_falha:
                print(f"  [aviso] O modelo não conseguiu prever ({erro}). Usando a regra provisória.")
                _ja_avisou_falha = True
    return regra_provisoria(features), ORIGEM_REGRA
