"""Abre o EducaTodos com persistência em SQLite."""
import os
from pathlib import Path

if __package__:
    from . import armazenamento, educatodos
    from .banco import RepositorioSQLite
else:
    import armazenamento
    import educatodos
    from banco import RepositorioSQLite

RAIZ = Path(__file__).resolve().parent.parent


def main():
    caminho = Path(os.environ.get("EDUCATODOS_DB", RAIZ / "dados" / "educatodos.db"))
    pasta_original = armazenamento.PASTA_RELATORIOS
    try:
        armazenamento.REPOSITORIO = RepositorioSQLite(caminho)
        armazenamento.BANCO_ATIVO = True
        armazenamento.PASTA_RELATORIOS = caminho.parent / "relatorios"
        return educatodos.main()
    except (OSError, ValueError) as erro:
        print(f"Não foi possível usar o banco de dados: {erro}")
        return 1
    finally:
        armazenamento.BANCO_ATIVO = False
        armazenamento.REPOSITORIO = None
        armazenamento.PASTA_RELATORIOS = pasta_original


if __name__ == "__main__":
    raise SystemExit(main())
