"""
Banco de questões do EducaTodos (escrito pelo grupo).

Cada questão é um dicionário com os mesmos campos da tabela QUESTAO do
contrato comum, para o integrante 4 carregar direto no banco:
    id_questao, disciplina, serie, dificuldade, enunciado,
    alternativas (A a D), gabarito,
    explicacao_basica, explicacao_intermediaria, explicacao_avancada

Campo extra só do programa: "dica" (aparece quando o aluno digita ?).

IDs do catálogo de questões (1 a 40, 10 por disciplina):
    1-10 Matemática | 11-20 Português | 21-30 Ciências | 31-40 História
"""

# Tuplas: valores fixos que não mudam durante o programa
DISCIPLINAS = ("Matemática", "Português", "Ciências", "História")
SERIES = ("6º Ano EF", "7º Ano EF", "8º Ano EF", "9º Ano EF", "1º Ano EM", "2º Ano EM", "3º Ano EM")
DIFICULDADES = ("fácil", "média", "difícil")


SERIES_ANTIGAS = {
    **{f"{ano}º Ano": f"{ano}º Ano EF" for ano in range(6, 10)},
    **{f"{ano}º {nome}": f"{ano}º Ano EM"
       for ano in range(1, 4) for nome in ("EM", "Médio")},
}


def normalizar_serie(serie):
    return SERIES_ANTIGAS.get(serie, serie)


QUESTOES = [
    # ------------------------------------------------------------------
    # MATEMÁTICA (1 a 10)
    # ------------------------------------------------------------------
    {
        "id_questao": 1, "disciplina": "Matemática", "serie": "6º Ano EF", "dificuldade": "fácil",
        "enunciado": "Quanto é 3/4 de 20?",
        "alternativas": {"A": "12", "B": "15", "C": "16", "D": "5"},
        "gabarito": "B",
        "dica": "Primeiro descubra quanto vale 1/4 de 20.",
        "explicacao_basica": "Divida 20 em 4 partes iguais: cada parte vale 5. Como queremos 3 partes, fazemos 3 x 5 = 15.",
        "explicacao_intermediaria": "Fração de um número: divida pelo denominador e multiplique pelo numerador. 20 / 4 = 5 e 5 x 3 = 15.",
        "explicacao_avancada": "a/b de N = (a x N) / b. Aqui, (3 x 20) / 4 = 60 / 4 = 15. Também vale 0,75 x 20 = 15.",
    },
    {
        "id_questao": 2, "disciplina": "Matemática", "serie": "3º Ano EM", "dificuldade": "difícil",
        "enunciado": "Qual é a distância entre os pontos (1, 2) e (4, 6) no plano cartesiano?",
        "alternativas": {"A": "5", "B": "7", "C": "25", "D": "12"},
        "gabarito": "A",
        "dica": "Calcule quanto x e y andam de um ponto ao outro e use Pitágoras.",
        "explicacao_basica": "De um ponto ao outro, o x anda 4 - 1 = 3 e o y anda 6 - 2 = 4. Isso forma um triângulo com lados 3 e 4. A distância é o lado maior: 3 x 3 + 4 x 4 = 9 + 16 = 25, e a raiz de 25 é 5.",
        "explicacao_intermediaria": "Fórmula da distância: d = raiz de ((4 - 1)² + (6 - 2)²) = raiz de (9 + 16) = raiz de 25 = 5.",
        "explicacao_avancada": "A fórmula da distância é o Teorema de Pitágoras aplicado às diferenças de coordenadas (3 e 4). O trio 3, 4, 5 é um terno pitagórico clássico, então nem é preciso fazer a raiz.",
    },
    {
        "id_questao": 3, "disciplina": "Matemática", "serie": "7º Ano EF", "dificuldade": "fácil",
        "enunciado": "Resolva a equação 2x + 5 = 17. Quanto vale x?",
        "alternativas": {"A": "6", "B": "11", "C": "8,5", "D": "7"},
        "gabarito": "A",
        "dica": "Tire o 5 dos dois lados primeiro.",
        "explicacao_basica": "Tiramos 5 dos dois lados: 2x = 12. Depois dividimos por 2: x = 6. Conferindo: 2 x 6 + 5 = 17.",
        "explicacao_intermediaria": "Isolando x: 2x = 17 - 5 = 12, então x = 12 / 2 = 6.",
        "explicacao_avancada": "Equação do 1º grau ax + b = c tem solução x = (c - b) / a = (17 - 5) / 2 = 6.",
    },
    {
        "id_questao": 4, "disciplina": "Matemática", "serie": "7º Ano EF", "dificuldade": "média",
        "enunciado": "Um produto custa R$ 80,00 e está com 15% de desconto. Qual é o preço final?",
        "alternativas": {"A": "R$ 65,00", "B": "R$ 72,00", "C": "R$ 70,00", "D": "R$ 68,00"},
        "gabarito": "D",
        "dica": "Calcule 10% e 5% de 80 e some.",
        "explicacao_basica": "10% de 80 é 8 e 5% de 80 é 4. Então 15% é 8 + 4 = 12. O preço final é 80 - 12 = 68 reais.",
        "explicacao_intermediaria": "Desconto = 80 x 0,15 = 12. Preço final = 80 - 12 = R$ 68,00.",
        "explicacao_avancada": "Com desconto de 15% você paga 85%: 80 x 0,85 = 68. Multiplicar pelo fator (1 - taxa) resolve em um passo só.",
    },
    {
        "id_questao": 5, "disciplina": "Matemática", "serie": "8º Ano EF", "dificuldade": "média",
        "enunciado": "Qual é o desenvolvimento de (x + 3)²?",
        "alternativas": {"A": "x² + 9", "B": "x² + 3x + 9", "C": "x² + 6x + 9", "D": "2x + 6"},
        "gabarito": "C",
        "dica": "(x + 3)² é o mesmo que (x + 3) vezes (x + 3).",
        "explicacao_basica": "Multiplique (x + 3) por (x + 3): x vezes x = x², x vezes 3 = 3x, 3 vezes x = 3x e 3 vezes 3 = 9. Somando: x² + 6x + 9.",
        "explicacao_intermediaria": "Produto notável: (a + b)² = a² + 2ab + b². Com a = x e b = 3: x² + 2 vezes x vezes 3 + 9 = x² + 6x + 9.",
        "explicacao_avancada": "O quadrado da soma gera o termo do meio 2ab, que costuma ser esquecido. A alternativa x² + 9 é o erro clássico de 'distribuir' o expoente.",
    },
    {
        "id_questao": 6, "disciplina": "Matemática", "serie": "8º Ano EF", "dificuldade": "difícil",
        "enunciado": "No sistema x + y = 10 e x - y = 4, qual é o valor de x?",
        "alternativas": {"A": "3", "B": "6", "C": "7", "D": "14"},
        "gabarito": "C",
        "dica": "Some as duas equações: o y some.",
        "explicacao_basica": "Somando as duas equações, o y desaparece: 2x = 14, então x = 7. E y = 10 - 7 = 3.",
        "explicacao_intermediaria": "Método da adição: (x + y) + (x - y) = 10 + 4, logo 2x = 14 e x = 7. Substituindo, y = 3.",
        "explicacao_avancada": "Somando, x = (10 + 4) / 2 = 7; subtraindo, y = (10 - 4) / 2 = 3. Soma e diferença determinam os dois números.",
    },
    {
        "id_questao": 7, "disciplina": "Matemática", "serie": "9º Ano EF", "dificuldade": "média",
        "enunciado": "Um triângulo retângulo tem catetos de 6 cm e 8 cm. Quanto mede a hipotenusa?",
        "alternativas": {"A": "10 cm", "B": "12 cm", "C": "14 cm", "D": "48 cm"},
        "gabarito": "A",
        "dica": "Use o Teorema de Pitágoras: a² = b² + c².",
        "explicacao_basica": "Pelo Teorema de Pitágoras: 6x6 + 8x8 = 36 + 64 = 100. A raiz de 100 é 10, então a hipotenusa mede 10 cm.",
        "explicacao_intermediaria": "a² = 6² + 8² = 100, logo a = 10 cm.",
        "explicacao_avancada": "6-8-10 é o terno 3-4-5 multiplicado por 2. Reconhecer ternos pitagóricos poupa a conta.",
    },
    {
        "id_questao": 8, "disciplina": "Matemática", "serie": "9º Ano EF", "dificuldade": "difícil",
        "enunciado": "Quais são as raízes da equação x² - 5x + 6 = 0?",
        "alternativas": {"A": "1 e 6", "B": "-1 e 6", "C": "-2 e -3", "D": "2 e 3"},
        "gabarito": "D",
        "dica": "Procure dois números que somam 5 e multiplicados dão 6.",
        "explicacao_basica": "Testando: 2 x 2 - 5 x 2 + 6 = 4 - 10 + 6 = 0, e com 3 também dá 0. Então as raízes são 2 e 3.",
        "explicacao_intermediaria": "Bhaskara: delta = 25 - 24 = 1. Então x = (5 + 1) / 2 = 3 ou x = (5 - 1) / 2 = 2.",
        "explicacao_avancada": "Por soma e produto: S = -b/a = 5 e P = c/a = 6, então as raízes são 2 e 3. Fatorando, (x - 2)(x - 3) = 0.",
    },
    {
        "id_questao": 9, "disciplina": "Matemática", "serie": "1º Ano EM", "dificuldade": "média",
        "enunciado": "Dada a função f(x) = 2x - 3, quanto vale f(4)?",
        "alternativas": {"A": "5", "B": "8", "C": "11", "D": "-5"},
        "gabarito": "A",
        "dica": "Troque o x por 4.",
        "explicacao_basica": "Onde está o x, colocamos 4: 2 x 4 - 3 = 8 - 3 = 5.",
        "explicacao_intermediaria": "f(4) = 2 x 4 - 3 = 5. Calcular f(a) é substituir x por a.",
        "explicacao_avancada": "f é afim com coeficiente angular 2 e linear -3; f(4) = 5 significa que o ponto (4, 5) pertence ao gráfico.",
    },
    {
        "id_questao": 10, "disciplina": "Matemática", "serie": "2º Ano EM", "dificuldade": "média",
        "enunciado": "Ao lançar duas moedas honestas, qual a probabilidade de sair cara nas duas?",
        "alternativas": {"A": "1/2", "B": "1/3", "C": "1/4", "D": "2/3"},
        "gabarito": "C",
        "dica": "Liste todos os resultados possíveis das duas moedas.",
        "explicacao_basica": "Os resultados possíveis são 4: cara-cara, cara-coroa, coroa-cara e coroa-coroa. Só 1 deles é cara-cara, então a chance é 1 em 4.",
        "explicacao_intermediaria": "Espaço amostral com 4 resultados e 1 favorável: P = 1/4.",
        "explicacao_avancada": "Eventos independentes: P(cara e cara) = 1/2 x 1/2 = 1/4 = 25%.",
    },
    # ------------------------------------------------------------------
    # PORTUGUÊS (11 a 20)
    # ------------------------------------------------------------------
    {
        "id_questao": 11, "disciplina": "Português", "serie": "6º Ano EF", "dificuldade": "fácil",
        "enunciado": "Na frase 'O menino correu rapidamente até a escola', qual palavra é um substantivo?",
        "alternativas": {"A": "correu", "B": "rapidamente", "C": "menino", "D": "até"},
        "gabarito": "C",
        "dica": "Substantivo é o nome que damos a pessoas, lugares e coisas.",
        "explicacao_basica": "Substantivo é o nome de algo. 'Menino' é o nome de uma pessoa. 'Correu' é ação (verbo) e 'rapidamente' diz como (advérbio).",
        "explicacao_intermediaria": "'Menino' nomeia um ser, então é substantivo. 'Correu' é verbo, 'rapidamente' é advérbio de modo e 'até' é preposição.",
        "explicacao_avancada": "A frase tem dois substantivos: 'menino' (núcleo do sujeito) e 'escola' (núcleo do adjunto adverbial de lugar). Entre as opções, só 'menino' aparece.",
    },
    {
        "id_questao": 12, "disciplina": "Português", "serie": "1º Ano EM", "dificuldade": "média",
        "enunciado": "A Carta de Pero Vaz de Caminha (1500) pertence a qual movimento da literatura no Brasil?",
        "alternativas": {"A": "Quinhentismo", "B": "Barroco", "C": "Arcadismo", "D": "Romantismo"},
        "gabarito": "A",
        "dica": "Pense no século em que a carta foi escrita.",
        "explicacao_basica": "A carta foi escrita em 1500. Os textos escritos nos anos 1500 (os 'quinhentos') formam o Quinhentismo.",
        "explicacao_intermediaria": "O Quinhentismo reúne textos do século XVI, como a Carta de Caminha e os textos dos jesuítas, que descrevem a terra nova.",
        "explicacao_avancada": "A Carta é literatura de informação: descreve a terra e os povos para a Coroa. Junto da literatura jesuítica (Anchieta), forma o Quinhentismo, anterior ao Barroco.",
    },
    {
        "id_questao": 13, "disciplina": "Português", "serie": "7º Ano EF", "dificuldade": "fácil",
        "enunciado": "Na frase 'Ana comprou flores', quem é o sujeito?",
        "alternativas": {"A": "comprou", "B": "Ana", "C": "flores", "D": "sujeito oculto"},
        "gabarito": "B",
        "dica": "Pergunte ao verbo: quem comprou?",
        "explicacao_basica": "Perguntando 'quem comprou?', a resposta é 'Ana'. Então Ana é o sujeito.",
        "explicacao_intermediaria": "O sujeito é o termo sobre o qual se declara algo. 'Ana' é sujeito simples; 'comprou flores' é o predicado.",
        "explicacao_avancada": "Sujeito simples (um núcleo: Ana). 'Flores' é objeto direto de 'comprou', que é verbo transitivo direto.",
    },
    {
        "id_questao": 14, "disciplina": "Português", "serie": "7º Ano EF", "dificuldade": "média",
        "enunciado": "Qual frase está escrita corretamente?",
        "alternativas": {"A": "Ele têm dois livros.", "B": "Ele têm dois livro.", "C": "Eles tem dois livros.", "D": "Eles têm dois livros."},
        "gabarito": "D",
        "dica": "O acento em 'têm' indica plural.",
        "explicacao_basica": "'Têm' com acento é para muitas pessoas (eles têm). 'Tem' sem acento é para uma pessoa (ele tem).",
        "explicacao_intermediaria": "O acento circunflexo diferencia o plural: ele tem / eles têm. O mesmo vale para vem / vêm.",
        "explicacao_avancada": "Acento diferencial de número nos verbos ter e vir (e derivados como 'contêm' e 'mantêm'), mantido pelo Acordo Ortográfico.",
    },
    {
        "id_questao": 15, "disciplina": "Português", "serie": "8º Ano EF", "dificuldade": "média",
        "enunciado": "Na frase 'Choveu muito ontem', como se classifica o sujeito?",
        "alternativas": {"A": "Sujeito simples: muito", "B": "Sujeito simples: ontem", "C": "Oração sem sujeito", "D": "Sujeito oculto"},
        "gabarito": "C",
        "dica": "Quem choveu? Existe alguém fazendo a ação?",
        "explicacao_basica": "Ninguém faz a ação de chover. Por isso a frase não tem sujeito.",
        "explicacao_intermediaria": "Verbos que indicam fenômenos da natureza (chover, ventar, nevar) são impessoais e formam oração sem sujeito.",
        "explicacao_avancada": "Verbos impessoais ficam na 3ª pessoa do singular e não têm sujeito. Em sentido figurado ('Choveram críticas') passam a ter sujeito.",
    },
    {
        "id_questao": 16, "disciplina": "Português", "serie": "8º Ano EF", "dificuldade": "difícil",
        "enunciado": "Em 'Embora estivesse cansado, terminou o trabalho', a palavra 'embora' indica:",
        "alternativas": {"A": "Causa", "B": "Conclusão", "C": "Condição", "D": "Concessão"},
        "gabarito": "D",
        "dica": "O cansaço impediu que ele terminasse?",
        "explicacao_basica": "'Embora' mostra uma ideia contrária que não impediu a ação: ele estava cansado, mas mesmo assim terminou. Isso se chama concessão.",
        "explicacao_intermediaria": "'Embora' é conjunção concessiva: apresenta um obstáculo que não impede o fato principal. Pode trocar por 'mesmo que'.",
        "explicacao_avancada": "Oração subordinada adverbial concessiva, com verbo no subjuntivo ('estivesse'). Equivale a 'apesar de estar cansado'.",
    },
    {
        "id_questao": 17, "disciplina": "Português", "serie": "9º Ano EF", "dificuldade": "média",
        "enunciado": "Qual figura de linguagem aparece em 'Aquele homem é uma fera'?",
        "alternativas": {"A": "Metáfora", "B": "Comparação", "C": "Hipérbole", "D": "Ironia"},
        "gabarito": "A",
        "dica": "Repare que não aparece a palavra 'como'.",
        "explicacao_basica": "A frase diz que o homem 'é' uma fera, sem usar 'como'. Quando a comparação é direta, sem 'como', é metáfora.",
        "explicacao_intermediaria": "Metáfora é a comparação implícita. Se fosse 'forte como uma fera', seria comparação (símile).",
        "explicacao_avancada": "Metáfora transfere traços de um termo para outro por semelhança (fera = agressivo ou muito habilidoso), sem conectivo comparativo.",
    },
    {
        "id_questao": 18, "disciplina": "Português", "serie": "9º Ano EF", "dificuldade": "difícil",
        "enunciado": "Em qual frase a crase está usada corretamente?",
        "alternativas": {"A": "Vou à escola.", "B": "Fui à pé.", "C": "Começou à chover.", "D": "Entreguei à ele."},
        "gabarito": "A",
        "dica": "Crase só acontece antes de palavra feminina que aceita o artigo 'a'.",
        "explicacao_basica": "Quem vai, vai A algum lugar, e 'escola' é feminina (A escola). A + A vira À. Antes de 'pé', 'chover' e 'ele' não tem crase.",
        "explicacao_intermediaria": "Crase = preposição 'a' + artigo 'a'. 'Pé' é masculino, 'chover' é verbo e 'ele' é pronome: nenhum aceita o artigo 'a'.",
        "explicacao_avancada": "Truque: troque por uma palavra masculina. 'Vou ao colégio' tem 'ao', então 'Vou à escola' tem crase. Em regra, não há crase antes de verbo, de palavra masculina nem de pronome pessoal.",
    },
    {
        "id_questao": 19, "disciplina": "Português", "serie": "2º Ano EM", "dificuldade": "média",
        "enunciado": "José de Alencar, autor de 'Iracema', pertence a qual movimento literário?",
        "alternativas": {"A": "Arcadismo", "B": "Romantismo", "C": "Realismo", "D": "Modernismo"},
        "gabarito": "B",
        "dica": "Iracema exalta o indígena como herói nacional.",
        "explicacao_basica": "Iracema conta uma história de amor e mostra o indígena como herói do Brasil. Isso é marca do Romantismo.",
        "explicacao_intermediaria": "Alencar é o principal nome da prosa romântica brasileira, com romances indianistas (Iracema, O Guarani) e urbanos (Senhora).",
        "explicacao_avancada": "O indianismo romântico idealiza o indígena para construir uma identidade nacional após a Independência. 'Iracema' (1865) é anagrama de 'América'.",
    },
    {
        "id_questao": 20, "disciplina": "Português", "serie": "3º Ano EM", "dificuldade": "difícil",
        "enunciado": "'Vidas Secas', de Graciliano Ramos, pertence a qual momento da literatura brasileira?",
        "alternativas": {"A": "Romantismo", "B": "Segunda fase do Modernismo (Geração de 30)", "C": "Parnasianismo", "D": "Realismo"},
        "gabarito": "B",
        "dica": "O livro é de 1938 e fala da seca no Nordeste.",
        "explicacao_basica": "O livro é de 1938 e mostra a vida difícil de uma família no sertão. Livros assim fazem parte da segunda fase do Modernismo.",
        "explicacao_intermediaria": "A Geração de 30 produziu o romance regionalista de denúncia social, com Graciliano Ramos, Rachel de Queiroz e Jorge Amado.",
        "explicacao_avancada": "Romance regionalista de 30: linguagem seca e econômica, capítulos quase independentes e crítica à desigualdade e à opressão no sertão nordestino.",
    },
    # ------------------------------------------------------------------
    # CIÊNCIAS (21 a 30)
    # ------------------------------------------------------------------
    {
        "id_questao": 21, "disciplina": "Ciências", "serie": "6º Ano EF", "dificuldade": "fácil",
        "enunciado": "Como se chama a passagem da água do estado líquido para o gasoso?",
        "alternativas": {"A": "Fusão", "B": "Solidificação", "C": "Condensação", "D": "Vaporização"},
        "gabarito": "D",
        "dica": "Pense na água fervendo e virando vapor.",
        "explicacao_basica": "Quando a água ferve, ela vira vapor. Essa passagem de líquido para gás se chama vaporização.",
        "explicacao_intermediaria": "Vaporização: líquido para gasoso. Condensação é o caminho inverso; fusão é sólido para líquido.",
        "explicacao_avancada": "A vaporização pode ser evaporação (lenta, na superfície), ebulição (em toda a massa, na temperatura de ebulição) ou calefação (brusca).",
    },
    {
        "id_questao": 22, "disciplina": "Ciências", "serie": "3º Ano EM", "dificuldade": "difícil",
        "enunciado": "Dois resistores, de 4 ohms e de 6 ohms, estão ligados em série e passa por eles uma corrente de 2 A. Qual é a tensão total?",
        "alternativas": {"A": "5 V", "B": "12 V", "C": "20 V", "D": "8 V"},
        "gabarito": "C",
        "dica": "Em série, as resistências se somam. Depois use a Lei de Ohm.",
        "explicacao_basica": "Em série, somamos as resistências: 4 + 6 = 10 ohms. Pela Lei de Ohm, tensão = resistência x corrente: 10 x 2 = 20 volts.",
        "explicacao_intermediaria": "Resistência equivalente em série: 4 + 6 = 10 ohms. U = R x i = 10 x 2 = 20 V.",
        "explicacao_avancada": "Em série a corrente é a mesma nos dois resistores: U1 = 4 x 2 = 8 V e U2 = 6 x 2 = 12 V, somando 20 V. As alternativas 8 V e 12 V são as tensões de cada resistor sozinho.",
    },
    {
        "id_questao": 23, "disciplina": "Ciências", "serie": "7º Ano EF", "dificuldade": "fácil",
        "enunciado": "Os seres vivos que produzem o próprio alimento pela fotossíntese são chamados de:",
        "alternativas": {"A": "Consumidores", "B": "Decompositores", "C": "Produtores", "D": "Parasitas"},
        "gabarito": "C",
        "dica": "Eles 'produzem' o próprio alimento.",
        "explicacao_basica": "As plantas fazem o próprio alimento usando a luz do sol. Por isso são chamadas de produtores.",
        "explicacao_intermediaria": "Produtores (plantas, algas) são autótrofos e ficam na base da cadeia alimentar. Consumidores dependem deles.",
        "explicacao_avancada": "Autótrofos fotossintetizantes convertem energia luminosa em energia química (glicose), que circula pelos níveis tróficos.",
    },
    {
        "id_questao": 24, "disciplina": "Ciências", "serie": "7º Ano EF", "dificuldade": "média",
        "enunciado": "Qual gás as plantas liberam durante a fotossíntese?",
        "alternativas": {"A": "Gás carbônico", "B": "Oxigênio", "C": "Nitrogênio", "D": "Metano"},
        "gabarito": "B",
        "dica": "Os animais precisam desse gás para respirar.",
        "explicacao_basica": "Na fotossíntese a planta pega gás carbônico e libera oxigênio, o gás que respiramos.",
        "explicacao_intermediaria": "Fotossíntese: gás carbônico + água + luz formam glicose e liberam oxigênio.",
        "explicacao_avancada": "6 CO2 + 6 H2O + luz -> C6H12O6 + 6 O2. O oxigênio liberado vem da quebra da água (fotólise).",
    },
    {
        "id_questao": 25, "disciplina": "Ciências", "serie": "8º Ano EF", "dificuldade": "média",
        "enunciado": "Qual hormônio, produzido pelo pâncreas, diminui a quantidade de açúcar no sangue?",
        "alternativas": {"A": "Adrenalina", "B": "Tiroxina", "C": "Testosterona", "D": "Insulina"},
        "gabarito": "D",
        "dica": "A falta dele está ligada ao diabetes.",
        "explicacao_basica": "A insulina ajuda o açúcar do sangue a entrar nas células. Quando ela falta, a pessoa pode ter diabetes.",
        "explicacao_intermediaria": "A insulina é produzida pelo pâncreas e baixa a glicemia. O glucagon, também do pâncreas, faz o contrário.",
        "explicacao_avancada": "Insulina (células beta das ilhotas pancreáticas) facilita a captação de glicose e seu armazenamento como glicogênio. Atua em equilíbrio com o glucagon.",
    },
    {
        "id_questao": 26, "disciplina": "Ciências", "serie": "8º Ano EF", "dificuldade": "difícil",
        "enunciado": "Uma lâmpada de 60 W fica ligada por 5 horas. Quanta energia ela consome?",
        "alternativas": {"A": "12 Wh", "B": "3 kWh", "C": "65 Wh", "D": "300 Wh"},
        "gabarito": "D",
        "dica": "Energia = potência x tempo.",
        "explicacao_basica": "Multiplique a potência pelo tempo ligado: 60 x 5 = 300 Wh.",
        "explicacao_intermediaria": "E = P x t = 60 W x 5 h = 300 Wh, ou seja, 0,3 kWh.",
        "explicacao_avancada": "E = P x t = 300 Wh = 0,3 kWh. A conta de luz cobra em kWh, então essa lâmpada gasta 0,3 kWh por dia nesse uso.",
    },
    {
        "id_questao": 27, "disciplina": "Ciências", "serie": "9º Ano EF", "dificuldade": "média",
        "enunciado": "Um carro percorre 150 km em 2 horas. Qual é a velocidade média?",
        "alternativas": {"A": "75 km/h", "B": "300 km/h", "C": "152 km/h", "D": "50 km/h"},
        "gabarito": "A",
        "dica": "Divida a distância pelo tempo.",
        "explicacao_basica": "Velocidade média é distância dividida pelo tempo: 150 / 2 = 75 km por hora.",
        "explicacao_intermediaria": "Vm = distância / tempo = 150 km / 2 h = 75 km/h.",
        "explicacao_avancada": "Vm = deslocamento / intervalo de tempo = 75 km/h, cerca de 20,8 m/s (divida por 3,6).",
    },
    {
        "id_questao": 28, "disciplina": "Ciências", "serie": "9º Ano EF", "dificuldade": "difícil",
        "enunciado": "Um átomo tem 11 prótons e 12 nêutrons. Qual é o seu número de massa?",
        "alternativas": {"A": "11", "B": "12", "C": "23", "D": "1"},
        "gabarito": "C",
        "dica": "Número de massa soma o que fica no núcleo.",
        "explicacao_basica": "O número de massa é prótons + nêutrons: 11 + 12 = 23.",
        "explicacao_intermediaria": "A = Z + N = 11 + 12 = 23. O número atômico (Z = 11) indica que é o sódio.",
        "explicacao_avancada": "A = Z + N = 23, isótopo sódio-23 (o mais comum). Os elétrons quase não contam na massa.",
    },
    {
        "id_questao": 29, "disciplina": "Ciências", "serie": "1º Ano EM", "dificuldade": "média",
        "enunciado": "Uma força resultante de 10 N age sobre um corpo de 2 kg. Qual é a aceleração?",
        "alternativas": {"A": "5 m/s²", "B": "20 m/s²", "C": "12 m/s²", "D": "8 m/s²"},
        "gabarito": "A",
        "dica": "Segunda Lei de Newton: F = m x a.",
        "explicacao_basica": "Pela Segunda Lei de Newton, força = massa x aceleração. Então a = 10 / 2 = 5 m/s².",
        "explicacao_intermediaria": "F = m x a, logo a = F / m = 10 / 2 = 5 m/s².",
        "explicacao_avancada": "Princípio fundamental da dinâmica: a = F_resultante / m = 5 m/s², com mesma direção e sentido da força.",
    },
    {
        "id_questao": 30, "disciplina": "Ciências", "serie": "2º Ano EM", "dificuldade": "difícil",
        "enunciado": "No cruzamento Aa x Aa, qual a proporção esperada de filhos aa?",
        "alternativas": {"A": "0%", "B": "25%", "C": "50%", "D": "75%"},
        "gabarito": "B",
        "dica": "Monte o quadro de Punnett.",
        "explicacao_basica": "Combinando os genes dos pais, saem 4 possibilidades: AA, Aa, Aa e aa. Só 1 em 4 é aa, ou seja, 25%.",
        "explicacao_intermediaria": "Quadro de Punnett: 1 AA : 2 Aa : 1 aa. A proporção de aa é 1/4 = 25%.",
        "explicacao_avancada": "Primeira Lei de Mendel: cada pai doa 'a' com probabilidade 1/2, então P(aa) = 1/2 x 1/2 = 1/4. Proporção fenotípica 3:1.",
    },
    # ------------------------------------------------------------------
    # HISTÓRIA (31 a 40)
    # ------------------------------------------------------------------
    {
        "id_questao": 31, "disciplina": "História", "serie": "6º Ano EF", "dificuldade": "fácil",
        "enunciado": "Qual civilização construiu as pirâmides de Gizé?",
        "alternativas": {"A": "Gregos", "B": "Maias", "C": "Romanos", "D": "Egípcios"},
        "gabarito": "D",
        "dica": "Gizé fica às margens do rio Nilo.",
        "explicacao_basica": "As pirâmides de Gizé ficam no Egito e foram construídas pelos antigos egípcios como túmulos dos faraós.",
        "explicacao_intermediaria": "Construídas por volta de 2500 a.C., as pirâmides eram túmulos de faraós como Quéops, ligados à crença na vida após a morte.",
        "explicacao_avancada": "As pirâmides do Império Antigo mostram o poder centralizado do faraó, capaz de organizar mão de obra e excedente agrícola do Nilo em grande escala.",
    },
    {
        "id_questao": 32, "disciplina": "História", "serie": "2º Ano EM", "dificuldade": "média",
        "enunciado": "Em qual país começou a Revolução Industrial, no século XVIII?",
        "alternativas": {"A": "Inglaterra", "B": "Brasil", "C": "Japão", "D": "Rússia"},
        "gabarito": "A",
        "dica": "Era o país com mais carvão, capital e colônias na época.",
        "explicacao_basica": "A Revolução Industrial começou na Inglaterra, quando as máquinas a vapor passaram a substituir o trabalho manual nas fábricas.",
        "explicacao_intermediaria": "A Inglaterra tinha carvão, capital acumulado no comércio e mão de obra vinda do campo (cercamentos), o que permitiu a industrialização.",
        "explicacao_avancada": "Fatores ingleses: acúmulo de capital mercantil, reservas de carvão e ferro, monarquia parlamentar favorável à burguesia após 1688 e êxodo rural causado pelos cercamentos.",
    },
    {
        "id_questao": 33, "disciplina": "História", "serie": "7º Ano EF", "dificuldade": "fácil",
        "enunciado": "Em que ano a frota portuguesa de Pedro Álvares Cabral chegou ao Brasil?",
        "alternativas": {"A": "1492", "B": "1500", "C": "1822", "D": "1889"},
        "gabarito": "B",
        "dica": "Foi exatamente na virada do século XV para o XVI.",
        "explicacao_basica": "Os portugueses chegaram ao Brasil em 22 de abril de 1500. 1492 é a chegada de Colombo à América.",
        "explicacao_intermediaria": "Em 1500 a frota de Cabral chegou à Bahia. 1822 é a Independência e 1889, a Proclamação da República.",
        "explicacao_avancada": "A chegada de 1500 faz parte da expansão marítima portuguesa. A colonização efetiva só começou na década de 1530, com as capitanias hereditárias.",
    },
    {
        "id_questao": 34, "disciplina": "História", "serie": "7º Ano EF", "dificuldade": "média",
        "enunciado": "Qual foi o primeiro produto explorado pelos portugueses no Brasil?",
        "alternativas": {"A": "Ouro", "B": "Café", "C": "Pau-brasil", "D": "Borracha"},
        "gabarito": "C",
        "dica": "O nome do país veio dele.",
        "explicacao_basica": "O primeiro produto foi o pau-brasil, uma árvore usada para fazer tinta vermelha. O nome do país vem dela.",
        "explicacao_intermediaria": "A exploração do pau-brasil usava o escambo com os indígenas. Depois vieram o açúcar, o ouro e, bem mais tarde, o café.",
        "explicacao_avancada": "Atividade extrativista e monopólio da Coroa (estanco), baseada no escambo com indígenas, sem ocupação permanente do território.",
    },
    {
        "id_questao": 35, "disciplina": "História", "serie": "8º Ano EF", "dificuldade": "média",
        "enunciado": "Quem proclamou a Independência do Brasil em 1822?",
        "alternativas": {"A": "Tiradentes", "B": "Deodoro da Fonseca", "C": "Dom Pedro II", "D": "Dom Pedro I"},
        "gabarito": "D",
        "dica": "Ele se tornou o primeiro imperador do Brasil.",
        "explicacao_basica": "Dom Pedro I proclamou a Independência em 7 de setembro de 1822 e virou o primeiro imperador do Brasil.",
        "explicacao_intermediaria": "Dom Pedro I proclamou a Independência às margens do Ipiranga. Deodoro proclamou a República em 1889; Tiradentes foi da Inconfidência Mineira.",
        "explicacao_avancada": "A Independência foi conduzida pela elite e manteve monarquia, escravidão e latifúndio, diferente das repúblicas da América espanhola.",
    },
    {
        "id_questao": 36, "disciplina": "História", "serie": "8º Ano EF", "dificuldade": "média",
        "enunciado": "Qual era o lema da Revolução Francesa (1789)?",
        "alternativas": {"A": "Ordem e Progresso", "B": "Deus, Pátria e Família", "C": "Paz, Pão e Terra", "D": "Liberdade, Igualdade, Fraternidade"},
        "gabarito": "D",
        "dica": "É até hoje o lema da França.",
        "explicacao_basica": "O lema da Revolução Francesa era 'Liberdade, Igualdade, Fraternidade', e ainda hoje é o lema da França.",
        "explicacao_intermediaria": "O lema resume os ideais iluministas. 'Ordem e Progresso' é da bandeira brasileira e 'Paz, Pão e Terra' é da Revolução Russa.",
        "explicacao_avancada": "Inspirado no Iluminismo, o lema expressa o fim dos privilégios do Antigo Regime e a cidadania; a Declaração dos Direitos do Homem e do Cidadão é de 1789.",
    },
    {
        "id_questao": 37, "disciplina": "História", "serie": "9º Ano EF", "dificuldade": "média",
        "enunciado": "O que a Lei Áurea, assinada em 1888, determinou?",
        "alternativas": {"A": "O fim da monarquia", "B": "O fim da escravidão no Brasil", "C": "O voto feminino", "D": "O fim apenas do tráfico de escravizados"},
        "gabarito": "B",
        "dica": "Foi assinada pela princesa Isabel.",
        "explicacao_basica": "A Lei Áurea, assinada pela princesa Isabel em 13 de maio de 1888, acabou com a escravidão no Brasil.",
        "explicacao_intermediaria": "A Lei Áurea aboliu a escravidão. O fim do tráfico veio antes, em 1850 (Lei Eusébio de Queirós), e a monarquia caiu em 1889.",
        "explicacao_avancada": "O Brasil foi o último país das Américas a abolir a escravidão, sem indenização nem integração dos libertos, o que deixou desigualdades que duram até hoje.",
    },
    {
        "id_questao": 38, "disciplina": "História", "serie": "9º Ano EF", "dificuldade": "difícil",
        "enunciado": "A Consolidação das Leis do Trabalho (CLT), de 1943, foi criada no governo de:",
        "alternativas": {"A": "Juscelino Kubitschek", "B": "Fernando Collor", "C": "Dom Pedro II", "D": "Getúlio Vargas"},
        "gabarito": "D",
        "dica": "Era o período do Estado Novo.",
        "explicacao_basica": "A CLT, que reúne os direitos do trabalhador, foi criada em 1943 por Getúlio Vargas.",
        "explicacao_intermediaria": "No Estado Novo (1937-1945), Vargas criou a CLT, que reuniu direitos como carteira assinada, férias e jornada de trabalho.",
        "explicacao_avancada": "A CLT faz parte da política trabalhista de Vargas: concedeu direitos, mas atrelou os sindicatos ao Estado, base do chamado populismo.",
    },
    {
        "id_questao": 39, "disciplina": "História", "serie": "1º Ano EM", "dificuldade": "média",
        "enunciado": "No feudalismo, como se chamava o trabalhador preso à terra que devia obrigações ao senhor?",
        "alternativas": {"A": "Servo", "B": "Burguês", "C": "Cavaleiro", "D": "Clérigo"},
        "gabarito": "A",
        "dica": "Ele 'servia' ao senhor feudal.",
        "explicacao_basica": "O servo trabalhava na terra do senhor feudal e, em troca de proteção, entregava parte do que produzia.",
        "explicacao_intermediaria": "Os servos estavam presos à terra e pagavam obrigações como a corveia (trabalho) e a talha (parte da produção).",
        "explicacao_avancada": "A servidão diferia da escravidão: o servo não era vendido, mas estava preso ao feudo e às obrigações (corveia, talha, banalidades) em troca de proteção.",
    },
    {
        "id_questao": 40, "disciplina": "História", "serie": "3º Ano EM", "dificuldade": "difícil",
        "enunciado": "O Ato Institucional nº 5 (AI-5), de 1968, ficou marcado por:",
        "alternativas": {
            "A": "Convocar eleições diretas para presidente",
            "B": "Endurecer a ditadura, permitindo fechar o Congresso e suspender o habeas corpus para crimes políticos",
            "C": "Criar a Constituição de 1988",
            "D": "Conceder anistia aos presos políticos",
        },
        "gabarito": "B",
        "dica": "Foi o ato mais duro da ditadura militar.",
        "explicacao_basica": "O AI-5 deu poderes enormes ao governo militar: podia fechar o Congresso e prender opositores com menos garantias.",
        "explicacao_intermediaria": "O AI-5 abriu o período mais duro da ditadura, com censura, cassações e suspensão do habeas corpus para crimes políticos.",
        "explicacao_avancada": "O AI-5 marca o início dos 'anos de chumbo' (1968-1974). Foi revogado em 1978; a anistia veio em 1979 e a Constituição democrática em 1988.",
    },
]


def validar_banco(questoes=QUESTOES):
    """Confere se todas as questões seguem o contrato. Devolve a lista de problemas."""
    obrigatorios = ("id_questao", "disciplina", "serie", "dificuldade", "enunciado",
                    "alternativas", "gabarito", "explicacao_basica",
                    "explicacao_intermediaria", "explicacao_avancada")
    problemas = []
    ids_vistos = set()
    for q in questoes:
        for campo in obrigatorios:
            if campo not in q or q[campo] in ("", None):
                problemas.append(f"Questão {q.get('id_questao')}: falta o campo {campo}")
        if q.get("id_questao") in ids_vistos:
            problemas.append(f"Questão {q['id_questao']}: id repetido")
        ids_vistos.add(q.get("id_questao"))
        if q.get("disciplina") not in DISCIPLINAS:
            problemas.append(f"Questão {q.get('id_questao')}: disciplina inválida")
        if q.get("serie") not in SERIES:
            problemas.append(f"Questão {q.get('id_questao')}: série inválida")
        if q.get("dificuldade") not in DIFICULDADES:
            problemas.append(f"Questão {q.get('id_questao')}: dificuldade inválida")
        if sorted(q.get("alternativas", {})) != ["A", "B", "C", "D"]:
            problemas.append(f"Questão {q.get('id_questao')}: alternativas devem ser A a D")
        if q.get("gabarito") not in q.get("alternativas", {}):
            problemas.append(f"Questão {q.get('id_questao')}: gabarito fora das alternativas")
    return problemas
