"""Persistência do progresso em JSON ou no repositório SQLite configurado."""

import json
import os
import time
from datetime import datetime
from pathlib import Path

if __package__:
    from .questoes import normalizar_serie
else:
    from questoes import normalizar_serie


PASTA_SRC = Path(__file__).resolve().parent
ARQUIVO_JSON = PASTA_SRC / "dados" / "progresso.json"
PASTA_RELATORIOS = PASTA_SRC / "relatorios"

# Os ids reais começam longe dos ids da base simulada do integrante 2
# (250 alunos e cerca de 3.000 respostas), para não colidirem no mesmo banco.
PRIMEIRO_ID_ALUNO = 1001
PRIMEIRO_ID_RESPOSTA = 100001

# Campos que cada registro precisa ter para o arquivo ser considerado válido
CAMPOS_OBRIGATORIOS = {
    "alunos": ("id_aluno", "nome", "serie"),
    "respostas": ("id_resposta", "id_aluno", "id_questao", "disciplina", "acertou",
                  "tempo_seg", "tentativas", "usou_dica"),
    "desempenho": ("id_aluno", "disciplina", "nivel_previsto", "data_calculo"),
}

BANCO_ATIVO = False
REPOSITORIO = None


def dados_vazios():
    """Estrutura inicial do progresso: uma lista para cada tabela do contrato."""
    return {"alunos": [], "respostas": [], "desempenho": []}


def _formato_valido(dados):
    """Confere se o JSON lido tem as três listas e os campos obrigatórios."""
    if not isinstance(dados, dict):
        return False
    for chave, campos in CAMPOS_OBRIGATORIOS.items():
        lista = dados.get(chave, [])
        if not isinstance(lista, list):
            return False
        for item in lista:
            if not isinstance(item, dict) or any(campo not in item for campo in campos):
                return False
    return True


def _guardar_copia_e_avisar(caminho, motivo):
    """Renomeia o arquivo problemático (com data e hora) para não perder nada."""
    carimbo = datetime.now().strftime("%Y%m%d-%H%M%S")
    copia = caminho.with_name(f"{caminho.stem}.corrompido-{carimbo}.json")
    try:
        os.replace(caminho, copia)
        onde = f"Guardei uma cópia em {copia.name}"
    except OSError:
        onde = "Não consegui guardar uma cópia"
    print(f"  [aviso] Não consegui ler {caminho.name} ({motivo}). {onde} e comecei do zero.")


def carregar_dados(caminho=None):
    """Lê o JSON. Se não existir, estiver corrompido ou com formato errado, começa do zero sem travar."""
    if caminho is None and BANCO_ATIVO:
        return REPOSITORIO.carregar()
    caminho = Path(caminho or ARQUIVO_JSON)
    if not caminho.exists():
        return dados_vazios()
    try:
        with open(caminho, "r", encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
    except (ValueError, OSError) as erro:  # JSON inválido ou codificação errada
        _guardar_copia_e_avisar(caminho, erro)
        return dados_vazios()
    if not _formato_valido(dados):
        _guardar_copia_e_avisar(caminho, "formato inesperado")
        return dados_vazios()
    for chave in CAMPOS_OBRIGATORIOS:
        dados.setdefault(chave, [])
    for aluno in dados["alunos"]:
        aluno["serie"] = normalizar_serie(aluno["serie"])
    return dados


def salvar_dados(dados, caminho=None):
    """
    Grava o JSON em um arquivo temporário e troca no fim, para o arquivo nunca
    ficar pela metade. Tenta 3 vezes, porque o OneDrive às vezes trava o arquivo
    enquanto sincroniza. Devolve True se gravou.
    """
    if caminho is None and BANCO_ATIVO:
        try:
            REPOSITORIO.salvar(dados)
        except ValueError as erro:
            print(f"  [aviso] Não consegui gravar no SQLite ({erro}).")
            return False
        return True
    caminho = Path(caminho or ARQUIVO_JSON)
    temporario = caminho.with_suffix(".tmp")
    for tentativa in range(3):
        try:
            caminho.parent.mkdir(parents=True, exist_ok=True)
            with open(temporario, "w", encoding="utf-8") as arquivo:
                json.dump(dados, arquivo, ensure_ascii=False, indent=2)
            os.replace(temporario, caminho)
            return True
        except OSError as erro:
            ultimo_erro = erro
            time.sleep(0.3)
    print(f"  [aviso] Não consegui gravar o progresso ({ultimo_erro}). Ele fica na memória até você sair.")
    return False


def proximo_id(lista, campo, inicio=1):
    """Próximo número livre: o maior id da lista + 1 (ou 'inicio' se a lista estiver vazia)."""
    return max((item[campo] for item in lista), default=inicio - 1) + 1


def registrar_aluno(dados, aluno):
    """Grava um aluno novo (tabela ALUNO) no armazenamento ativo."""
    dados["alunos"].append(aluno)
    return salvar_dados(dados)


def registrar_resposta(dados, resposta):
    """Grava uma resposta (tabela RESPOSTA) no armazenamento ativo."""
    dados["respostas"].append(resposta)
    return salvar_dados(dados)


def registrar_desempenho(dados, desempenho):
    """Grava o nível calculado (tabela DESEMPENHO) no armazenamento ativo."""
    dados["desempenho"].append(desempenho)
    return salvar_dados(dados)


def salvar_relatorio_txt(nome_arquivo, texto, pasta=None):
    """Grava o relatório do aluno em TXT. Devolve o caminho, ou None se não conseguiu."""
    pasta = Path(pasta or PASTA_RELATORIOS)
    try:
        pasta.mkdir(parents=True, exist_ok=True)
        caminho = pasta / nome_arquivo
        with open(caminho, "w", encoding="utf-8") as arquivo:
            arquivo.write(texto)
        return caminho
    except OSError as erro:
        print(f"  [aviso] Não consegui gravar o relatório ({erro}).")
        return None
