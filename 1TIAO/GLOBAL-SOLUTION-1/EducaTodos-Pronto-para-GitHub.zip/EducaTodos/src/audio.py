"""
Modo áudio (acessibilidade): lê textos em voz alta.

1ª opção: pyttsx3, que funciona sem internet e usa a voz do próprio Windows.
2ª opção: gTTS, voz do Google; precisa de internet, gera um MP3 e abre no player.
Se nenhuma estiver instalada, o programa avisa e continua normalmente.
"""

import os
import re
import subprocess
import sys
import tempfile


def preparar_para_fala(texto):
    """Troca símbolos de matemática por palavras, para a voz ler direito."""
    texto = re.sub(r"(\w)\s*x\s*(\d)", r"\1 vezes \2", texto)  # 3 x 4 -> 3 vezes 4
    trocas = (("km/h", " quilômetros por hora"), ("m/s²", " metros por segundo ao quadrado"),
              ("m/s", " metros por segundo"), ("²", " ao quadrado"), ("->", " resulta em "), ("/", " dividido por "),
              ("=", " igual a "), ("+", " mais "), ("%", " por cento"), ("raiz de", "raiz quadrada de"))
    for simbolo, palavra in trocas:
        texto = texto.replace(simbolo, palavra)
    return re.sub(r"\s+", " ", texto).strip()


def _escolher_voz_portugues(motor):
    """Procura uma voz em português instalada no computador. Devolve True se achou."""
    try:
        for voz in motor.getProperty("voices"):
            descricao = f"{voz.id} {voz.name} {getattr(voz, 'languages', '')}".lower()
            if any(chave in descricao for chave in ("pt-br", "pt_br", "brazil", "portug")):
                motor.setProperty("voice", voz.id)
                return True
    except Exception:
        pass
    return False


def _falar_pyttsx3(texto):
    """Fala com o pyttsx3 (sem internet)."""
    import pyttsx3
    motor = pyttsx3.init()
    motor.setProperty("rate", 165)  # velocidade da fala
    _escolher_voz_portugues(motor)
    motor.say(texto)
    motor.runAndWait()


def _abrir_arquivo(caminho):
    """Abre o MP3 no player padrão do sistema."""
    if sys.platform.startswith("win"):
        os.startfile(caminho)
    elif sys.platform == "darwin":
        subprocess.run(["open", caminho], check=False)
    else:
        subprocess.run(["xdg-open", caminho], check=False)


def _falar_gtts(texto):
    """Fala com o gTTS (precisa de internet)."""
    from gtts import gTTS
    caminho = os.path.join(tempfile.gettempdir(), "educatodos_explicacao.mp3")
    gTTS(text=texto, lang="pt", tld="com.br").save(caminho)
    _abrir_arquivo(caminho)


def falar(texto):
    """Lê o texto em voz alta. Devolve True se conseguiu."""
    texto = preparar_para_fala(texto)
    for nome, funcao in (("pyttsx3", _falar_pyttsx3), ("gTTS", _falar_gtts)):
        try:
            funcao(texto)
            return True
        except ImportError:
            continue
        except Exception as erro:
            print(f"  [aviso] O {nome} não conseguiu falar ({erro}).")
    print("  Modo áudio indisponível. Instale com: pip install pyttsx3  (ou gTTS, com internet)")
    return False
