# Aplicação EducaTodos

A partir da raiz do projeto, instale `requirements.txt` e execute `python3 -m src.main_sqlite`.
O progresso é salvo em `dados/educatodos.db`. Os relatórios TXT ficam em `dados/relatorios/`.
Para usar a versão JSON com histórico local separado, execute `python3 src/educatodos.py`.

`educatodos.py` contém o menu e a lógica dos exercícios. `questoes.py` contém as 40 questões.
`nivel_aluno.py` agrega as métricas por sessão e chama `modelo_integracao.py`.
`armazenamento.py` encaminha as operações à persistência ativa, e `banco.py` implementa o SQLite.
