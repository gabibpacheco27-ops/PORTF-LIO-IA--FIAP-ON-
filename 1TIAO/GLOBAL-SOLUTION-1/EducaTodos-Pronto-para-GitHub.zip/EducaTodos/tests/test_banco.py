"""Testes da camada SQLite (Integrante 4). Execute na raiz: python -m unittest discover -s tests -v"""
import contextlib
import csv
import io
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

from src import armazenamento, banco, main_sqlite
from src import educatodos as app

RAIZ = Path(__file__).resolve().parent.parent


def aluno(id_aluno=1, serie="6º Ano EF", nome="Teste"):
    return dict(id_aluno=id_aluno, nome=nome, serie=serie, data_cadastro=banco.agora())


def resposta(id_resposta=1, id_aluno=1, questao=None, acertou=True):
    q = questao or next(q for q in app.QUESTOES if q["serie"] == "6º Ano EF")
    letra = q["gabarito"] if acertou else next(a for a in "ABCD" if a != q["gabarito"])
    return dict(id_resposta=id_resposta, id_aluno=id_aluno, id_questao=q["id_questao"],
                disciplina=q["disciplina"], id_sessao="sessao-teste", acertou=int(acertou),
                tempo_seg=12.5, tentativas=1, usou_dica=0, data_resposta=banco.agora(),
                alternativa=letra)


def adicionar_desempenho(estado, aluno, disciplina, origem="regra provisória"):
    estado["desempenho"].append(dict(
        id_aluno=aluno["id_aluno"], disciplina=disciplina, taxa_acerto=50.0,
        nivel_previsto="Básico", origem_nivel=origem, data_calculo=banco.agora(),
    ))


class BaseBanco(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.caminho = Path(self._tmp.name) / "teste.db"
        self.repo = banco.RepositorioSQLite(self.caminho)

    def contar(self, tabela):
        with closing(sqlite3.connect(self.caminho)) as con:
            return con.execute(f"SELECT COUNT(*) FROM {tabela}").fetchone()[0]


class TestEsquema(BaseBanco):
    def test_tabelas_e_questoes(self):
        with closing(sqlite3.connect(self.caminho)) as con:
            tabelas = {l[0] for l in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertTrue({"ALUNO", "QUESTAO", "RESPOSTA", "DESEMPENHO", "INTERACAO_SIMULADA"} <= tabelas)
        self.assertEqual(self.contar("QUESTAO"), len(app.QUESTOES))

    def test_reabrir_nao_duplica_questoes(self):
        banco.RepositorioSQLite(self.caminho)
        banco.RepositorioSQLite(self.caminho)
        self.assertEqual(self.contar("QUESTAO"), len(app.QUESTOES))

    def test_questoes_do_banco_iguais_ao_app(self):
        dados = app.QUESTOES
        with closing(sqlite3.connect(self.caminho)) as con:
            con.row_factory = sqlite3.Row
            no_banco = {l["id_questao"]: dict(l) for l in con.execute("SELECT * FROM QUESTAO")}
        self.assertEqual(len(dados), len(no_banco))
        for q in dados:
            gravada = no_banco[q["id_questao"]]
            for chave in ("disciplina", "enunciado", "gabarito"):
                self.assertEqual(gravada[chave], q[chave])
            self.assertEqual(gravada["serie"], banco._serie_sql(q["serie"]))

    def test_chaves_estrangeiras_ativas(self):
        with self.repo._conexao() as con:
            self.assertEqual(con.execute("PRAGMA foreign_keys").fetchone()[0], 1)

    def test_versao_do_esquema(self):
        with closing(sqlite3.connect(self.caminho)) as con:
            self.assertEqual(con.execute("PRAGMA user_version").fetchone()[0], banco.VERSAO_ESQUEMA)


class TestContratoDoRepositorio(BaseBanco):
    def test_banco_novo_devolve_estado_vazio(self):
        self.assertEqual(self.repo.carregar(), armazenamento.dados_vazios())

    def test_ida_e_volta_identica(self):
        estado = armazenamento.dados_vazios()
        a = aluno()
        estado["alunos"].append(a)
        estado["respostas"] += [resposta(1), resposta(2, acertou=False)]
        adicionar_desempenho(estado, a, "Matemática")
        self.repo.salvar(estado)
        self.assertEqual(self.repo.carregar(), estado)

    def test_salvar_varias_vezes_nao_duplica(self):
        estado = armazenamento.dados_vazios()
        a = aluno()
        estado["alunos"].append(a)
        estado["respostas"].append(resposta(1))
        adicionar_desempenho(estado, a, "Matemática")
        for _ in range(3):
            self.repo.salvar(estado)
        self.assertEqual((self.contar("ALUNO"), self.contar("RESPOSTA"), self.contar("DESEMPENHO")), (1, 1, 1))

    def test_salvamento_incremental_como_o_aplicativo_faz(self):
        estado = self.repo.carregar()
        a = aluno()
        estado["alunos"].append(a)
        self.repo.salvar(estado)
        questoes = [q for q in app.QUESTOES if q["serie"] == "6º Ano EF" and q["disciplina"] == "Matemática"]
        for n, q in enumerate(questoes, start=1):
            estado["respostas"].append(resposta(n, questao=q, acertou=bool(n % 2)))
            adicionar_desempenho(estado, a, "Matemática")
            self.repo.salvar(estado)
        reaberto = banco.RepositorioSQLite(self.caminho).carregar()
        self.assertEqual(reaberto, estado)
        self.assertEqual(len(reaberto["desempenho"]), len(questoes))
        self.assertEqual(self.contar("DESEMPENHO"), len(questoes))

    def test_origem_do_nivel_preservada(self):
        estado = armazenamento.dados_vazios()
        a = aluno()
        estado["alunos"].append(a)
        estado["respostas"].append(resposta(1))
        adicionar_desempenho(estado, a, "Matemática", origem="modelo de Machine Learning")
        adicionar_desempenho(estado, a, "Matemática")
        self.repo.salvar(estado)
        origens = [d["origem_nivel"] for d in self.repo.carregar()["desempenho"]]
        self.assertEqual(origens[0], "modelo de Machine Learning")
        self.assertTrue(origens[1].startswith("regra provisória"))

    def test_estado_invalido_nao_e_gravado(self):
        estado = armazenamento.dados_vazios()
        estado["alunos"].append(aluno(serie="Série Inexistente"))
        with self.assertRaises(ValueError):
            self.repo.salvar(estado)
        self.assertEqual(self.contar("ALUNO"), 0)

    def test_conflito_de_conteudo_com_mesmo_id_desfaz_a_transacao(self):
        estado = armazenamento.dados_vazios()
        estado["alunos"].append(aluno())
        estado["respostas"].append(resposta(1, acertou=True))
        self.repo.salvar(estado)
        divergente = armazenamento.dados_vazios()
        divergente["alunos"] = [aluno(), aluno(2, nome="Novo")]       # o aluno 2 seria inserido...
        divergente["alunos"][0] = estado["alunos"][0]
        divergente["respostas"].append(resposta(1, acertou=False))     # ...mas o id 1 diverge
        with self.assertRaisesRegex(ValueError, "Conflito em RESPOSTA"):
            self.repo.salvar(divergente)
        self.assertEqual((self.contar("ALUNO"), self.contar("RESPOSTA")), (1, 1))   # nada ficou pela metade

    def test_duas_instancias_com_o_mesmo_id_de_resposta(self):
        base = armazenamento.dados_vazios()
        base["alunos"].append(aluno())
        self.repo.salvar(base)
        outra = banco.RepositorioSQLite(self.caminho)
        estado_a, estado_b = self.repo.carregar(), outra.carregar()
        estado_a["respostas"].append(resposta(1, acertou=True))
        self.repo.salvar(estado_a)
        estado_b["respostas"].append(resposta(1, acertou=False))
        with self.assertRaisesRegex(ValueError, "outra instância"):
            outra.salvar(estado_b)
        self.assertEqual(self.contar("RESPOSTA"), 1)

    def test_banco_corrompido_gera_erro_sem_alterar_arquivo(self):
        corrompido = Path(self._tmp.name) / "ruim.db"
        corrompido.write_bytes(b"isto nao e um banco sqlite" * 20)
        antes = corrompido.read_bytes()
        with self.assertRaises(ValueError):
            banco.RepositorioSQLite(corrompido)
        self.assertEqual(corrompido.read_bytes(), antes)

    def test_dados_inconsistentes_no_banco_sao_detectados_ao_carregar(self):
        estado = armazenamento.dados_vazios()
        estado["alunos"].append(aluno())
        estado["respostas"].append(resposta(1))
        self.repo.salvar(estado)
        with closing(sqlite3.connect(self.caminho)) as con:
            con.execute("DROP TRIGGER trg_resposta_coerencia")
            con.execute("UPDATE RESPOSTA SET acertou = 0")   # gabarito diz que acertou
            con.commit()
        with self.assertRaises(ValueError):
            self.repo.carregar()


class TestRegrasDoBanco(BaseBanco):
    def setUp(self):
        super().setUp()
        estado = armazenamento.dados_vazios()
        estado["alunos"].append(aluno())
        self.repo.salvar(estado)

    def test_fk_aluno_inexistente(self):
        with self.assertRaises(ValueError):
            self.repo.inserir_resposta(resposta(id_aluno=99))

    def test_questao_de_outra_serie_e_recusada(self):
        outra = next(q for q in app.QUESTOES if q["serie"] == "9º Ano EF")
        r = resposta(questao=outra)
        with self.assertRaisesRegex(ValueError, "Questao fora da faixa"):
            self.repo.inserir_resposta(r)

    def test_acertou_deve_conferir_com_gabarito(self):
        r = resposta(acertou=False)
        r["acertou"] = 1
        with self.assertRaisesRegex(ValueError, "gabarito"):
            self.repo.inserir_resposta(r)

    def test_checks_de_dominio(self):
        for campo, valor in [("tempo_seg", -1), ("tentativas", 0), ("usou_dica", 2), ("alternativa", "E")]:
            r = dict(resposta(), **{campo: valor})
            with self.assertRaises(ValueError, msg=campo):
                self.repo.inserir_resposta(r)
        self.assertEqual(self.contar("RESPOSTA"), 0)

    def test_inserir_aluno_e_serie_invalida(self):
        novo = self.repo.inserir_aluno("Maria", "2º Médio")
        self.assertEqual(novo, 2)
        with self.assertRaises(ValueError):
            self.repo.inserir_aluno("Joao", "10º Ano")
        with self.assertRaises(ValueError):
            self.repo.inserir_aluno("X", "6º Ano EF")   # nome curto demais

    def test_salvar_nivel_e_buscar_desempenho(self):
        self.repo.salvar_nivel(1, "Matemática", .5, "Básico", "provisório: teste", "2026-10-01T10:00:00-03:00")
        self.repo.salvar_nivel(1, "Matemática", .8, "Avançado", "modelo de Machine Learning", "2026-10-02T10:00:00-03:00")
        self.repo.salvar_nivel(1, "História", .2, "Básico", "provisório: teste")
        historico = self.repo.buscar_desempenho(1, "Matemática")
        self.assertEqual([h["nivel_previsto"] for h in historico], ["Básico", "Avançado"])
        ultimo = self.repo.buscar_desempenho(1, "Matemática", somente_ultimo=True)
        self.assertEqual(len(ultimo), 1)
        self.assertEqual(ultimo[0]["nivel_previsto"], "Avançado")
        self.assertEqual(len(self.repo.buscar_desempenho(1)), 3)
        with self.assertRaises(ValueError):
            self.repo.salvar_nivel(1, "Matemática", 1.5, "Básico", "x")
        with self.assertRaises(ValueError):
            self.repo.salvar_nivel(1, "Matemática", .5, "Mestre", "x")


class TestFluxoDoAplicativo(BaseBanco):
    """Reproduz test_fluxo_completo_e_reabertura do Integrante 1, agora com SQLite."""

    def test_fluxo_completo_e_reabertura(self):
        q = app.QUESTOES[0]
        entradas = ["1", "Aluno Demo", "1", "3", "1", "1", "?", "Z",
                    q["gabarito"], "4", "s", "0"]
        with patch.dict("os.environ", {"EDUCATODOS_DB": str(self.caminho)}),                 patch.dict(app.sessao), patch("builtins.input", side_effect=entradas),                 patch.object(app, "sortear_questao", return_value=q),                 contextlib.redirect_stdout(io.StringIO()) as saida:
            self.assertIsNone(main_sqlite.main())
        self.assertIn("Certo!", saida.getvalue())
        estado = banco.RepositorioSQLite(self.caminho).carregar()
        self.assertEqual(len(estado["alunos"]), 1)
        self.assertEqual(len(estado["respostas"]), 1)
        r = estado["respostas"][0]
        self.assertEqual((r["usou_dica"], r["tentativas"], r["alternativa"]), (1, 1, q["gabarito"]))
        self.assertTrue(r["id_sessao"])
        self.assertEqual(self.contar("DESEMPENHO"), 1)
        self.assertTrue(list((self.caminho.parent / "relatorios").glob("*.txt")))
        with patch.dict("os.environ", {"EDUCATODOS_DB": str(self.caminho)}),                 patch.dict(app.sessao), patch("builtins.input", side_effect=["2", "1001", "4", "n", "0"]),                 contextlib.redirect_stdout(io.StringIO()) as retorno:
            self.assertIsNone(main_sqlite.main())
        self.assertIn("100%", retorno.getvalue())
        self.assertEqual((self.contar("ALUNO"), self.contar("RESPOSTA")), (1, 1))

    def test_main_sqlite_retorna_erro_amigavel_com_banco_ruim(self):
        from src import main_sqlite
        ruim = Path(self._tmp.name) / "ruim.db"
        ruim.write_bytes(b"lixo" * 100)
        with patch.dict("os.environ", {"EDUCATODOS_DB": str(ruim)}), \
                contextlib.redirect_stdout(io.StringIO()) as saida:
            self.assertEqual(main_sqlite.main(), 1)
        self.assertIn("Não foi possível usar o banco", saida.getvalue())


class TestBaseSimulada(BaseBanco):
    def escrever_csv(self, linhas, colunas=banco.COLUNAS_CSV_SIMULADO):
        caminho = Path(self._tmp.name) / "sim.csv"
        with caminho.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=colunas)
            w.writeheader()
            w.writerows(linhas)
        return caminho

    def linha(self, **extra):
        base = dict(id_aluno=1, disciplina="História", id_questao=5, tentativas="3.0", usou_dica=0,
                    tempo_seg="88.5", data="2026-08-22", serie="1º EM", nota_diagnostica="4.4",
                    nivel_diagnostico="Intermediário", acertou=1)
        base.update(extra)
        return base

    def test_importa_normaliza_serie_e_e_idempotente(self):
        caminho = self.escrever_csv([self.linha(), self.linha(id_aluno=2, serie="6º Ano EF", tentativas="1")])
        self.assertEqual(self.repo.importar_interacoes_csv(caminho), 2)
        self.assertEqual(self.repo.importar_interacoes_csv(caminho), 2)
        self.assertEqual(self.contar("INTERACAO_SIMULADA"), 2)
        _, linhas = self.repo.executar_consulta("SELECT serie, tentativas, origem FROM INTERACAO_SIMULADA ORDER BY id_aluno_sim")
        self.assertEqual(linhas, [("1º Médio", 3, "simulado"), ("6º Ano", 1, "simulado")])

    def test_csv_invalido(self):
        with self.assertRaisesRegex(ValueError, "linha 2"):
            self.repo.importar_interacoes_csv(self.escrever_csv([self.linha(tentativas="2.5")]))
        with self.assertRaisesRegex(ValueError, "linha 2"):
            self.repo.importar_interacoes_csv(self.escrever_csv([self.linha(serie="10º Ano")]))
        with self.assertRaisesRegex(ValueError, "sem as colunas"):
            self.repo.importar_interacoes_csv(self.escrever_csv([{"id_aluno": 1}], colunas=["id_aluno"]))
        self.assertEqual(self.contar("INTERACAO_SIMULADA"), 0)

    def test_csv_com_linha_invalida_nao_apaga_dados_anteriores(self):
        self.repo.importar_interacoes_csv(self.escrever_csv([self.linha()]))
        with self.assertRaises(ValueError):
            self.repo.importar_interacoes_csv(self.escrever_csv([self.linha(), self.linha(acertou="x")]))
        self.assertEqual(self.contar("INTERACAO_SIMULADA"), 1)

    def test_csv_real_do_integrante_2(self):
        csv_real = RAIZ / "data" / "interacoes_alunos.csv"
        if not csv_real.exists():
            self.skipTest("data/interacoes_alunos.csv ausente")
        with csv_real.open(encoding="utf-8-sig") as f:
            esperado = sum(1 for _ in f) - 1
        self.assertEqual(self.repo.importar_interacoes_csv(csv_real), esperado)
        _, series = self.repo.executar_consulta("SELECT DISTINCT serie FROM INTERACAO_SIMULADA")
        self.assertTrue({s[0] for s in series} <= set(banco.SERIES))


class TestConsultas(BaseBanco):
    def test_todas_as_consultas_executam(self):
        estado = armazenamento.dados_vazios()
        a = aluno()
        estado["alunos"].append(a)
        qs = [q for q in app.QUESTOES if q["serie"] == "6º Ano EF"]
        for n, q in enumerate(qs, start=1):
            estado["respostas"].append(resposta(n, questao=q, acertou=n % 3 != 0))
            adicionar_desempenho(estado, a, q["disciplina"], origem="modelo de Machine Learning")
        self.repo.salvar(estado)
        consultas = banco.listar_consultas()
        self.assertEqual(len(consultas), 12)
        nomes = [c[0] for c in consultas]
        self.assertEqual(len(nomes), len(set(nomes)))
        resultados = {nome: self.repo.executar_consulta(sql) for nome, _, sql in consultas}
        self.assertEqual(len(resultados["01_taxa_acerto_por_aluno_disciplina"][1]), 4)
        self.assertEqual(resultados["12_verificacao_respostas_orfas"][1], [(0,)])
        self.assertEqual(len(resultados["06_nivel_atual_por_aluno_disciplina"][1]), 4)

    def test_taxa_de_acerto_confere_com_o_calculo_do_aplicativo(self):
        estado = armazenamento.dados_vazios()
        a = aluno()
        estado["alunos"].append(a)
        qs = [q for q in app.QUESTOES if q["serie"] in ("6º Ano EF", "7º Ano EF") and q["disciplina"] == "Matemática"]
        estado["respostas"] += [resposta(1, questao=qs[0], acertou=True), resposta(2, questao=qs[1], acertou=False)]
        self.repo.salvar(estado)
        sql = dict((n, s) for n, _, s in banco.listar_consultas())["01_taxa_acerto_por_aluno_disciplina"]
        _, linhas = self.repo.executar_consulta(sql)
        esperado = round(app.calcular_taxa_acerto(app.respostas_do_aluno(estado, a["id_aluno"], "Matemática")), 1)
        self.assertEqual(linhas[0][-1], esperado)

    def test_evolucao_ignora_nivel_provisorio(self):
        estado = armazenamento.dados_vazios()
        a = aluno()
        estado["alunos"].append(a)
        estado["respostas"].append(resposta(1))
        for _ in range(3):
            adicionar_desempenho(estado, a, "Matemática")   # provisório
        self.repo.salvar(estado)
        sql = dict((n, s) for n, _, s in banco.listar_consultas())["07_evolucao_somente_nivel_do_modelo"]
        self.assertEqual(self.repo.executar_consulta(sql)[1], [])
        self.repo.salvar_nivel(1, "Matemática", .4, "Básico", "modelo de Machine Learning")
        self.repo.salvar_nivel(1, "Matemática", .9, "Avançado", "modelo de Machine Learning")
        linhas = self.repo.executar_consulta(sql)[1]
        self.assertEqual(linhas, [(1, "Matemática", 2, "Básico", "Avançado", 50.0)])

    def test_executar_consulta_recusa_comandos_que_alteram_dados(self):
        with self.assertRaises(ValueError):
            self.repo.executar_consulta("DELETE FROM ALUNO")


if __name__ == "__main__":
    unittest.main()
