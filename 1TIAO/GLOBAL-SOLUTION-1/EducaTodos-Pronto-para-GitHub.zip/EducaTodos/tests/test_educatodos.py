"""
Testes automáticos da aplicação (integrante 1).
Rodar a partir da pasta src/:   python -m unittest discover -s tests -v
"""

import collections
import random
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import armazenamento, audio, educatodos, nivel_aluno
from src.questoes import DISCIPLINAS, QUESTOES, SERIES, validar_banco  # noqa: E402


def resposta_falsa(acertou, tempo=60, tentativas=1, dica=0, disciplina="Matemática", id_aluno=1001):
    """Resposta mínima para os testes, com os campos usados nos cálculos."""
    return {"acertou": acertou, "tempo_seg": tempo, "tentativas": tentativas,
            "usou_dica": dica, "disciplina": disciplina, "id_aluno": id_aluno}


def modelo_quebrado(**features):
    """Modelo falso que sempre falha, para testar a regra provisória."""
    raise RuntimeError("sem modelo")


class TestComPastaTemporaria(unittest.TestCase):
    """Base: cada teste grava numa pasta temporária, nunca no progresso.json real."""

    def setUp(self):
        pasta = tempfile.TemporaryDirectory()
        self.addCleanup(pasta.cleanup)
        self.pasta = Path(pasta.name)
        self.arquivo = self.pasta / "progresso.json"
        patches = [patch.object(armazenamento, "ARQUIVO_JSON", self.arquivo),
                   patch.object(armazenamento, "PASTA_RELATORIOS", self.pasta / "relatorios"),
                   patch.object(armazenamento, "BANCO_ATIVO", False),
                   patch.object(nivel_aluno, "_prever_nivel_modelo", None),
                   patch.dict(educatodos.sessao, {"aluno": None, "ultima_explicacao": None,
                                                  "modo_acessivel": False})]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)


class TestBancoDeQuestoes(unittest.TestCase):
    def test_banco_segue_o_contrato(self):
        self.assertEqual(validar_banco(), [])

    def test_dez_questoes_por_disciplina_com_ids_do_integrante_2(self):
        self.assertEqual(len(QUESTOES), 40)
        for indice, disciplina in enumerate(DISCIPLINAS):
            ids = sorted(q["id_questao"] for q in QUESTOES if q["disciplina"] == disciplina)
            self.assertEqual(ids, list(range(indice * 10 + 1, indice * 10 + 11)))

    def test_cada_disciplina_cobre_todas_as_series_e_dificuldades(self):
        for disciplina in DISCIPLINAS:
            questoes = [q for q in QUESTOES if q["disciplina"] == disciplina]
            self.assertEqual({q["serie"] for q in questoes}, set(SERIES))
            self.assertEqual({q["dificuldade"] for q in questoes}, {"fácil", "média", "difícil"})

    def test_gabaritos_equilibrados(self):
        """Nenhuma letra pode ser a certa em mais de 40% das questões (chute não pode render)."""
        contagem = collections.Counter(q["gabarito"] for q in QUESTOES)
        self.assertEqual(set(contagem), {"A", "B", "C", "D"})
        self.assertLessEqual(max(contagem.values()), 0.4 * len(QUESTOES))


class TestFuncoesPrincipais(unittest.TestCase):
    def test_corrigir_resposta(self):
        questao = QUESTOES[0]  # gabarito B
        self.assertEqual(educatodos.corrigir_resposta(questao, "b"), (True, "B"))
        self.assertEqual(educatodos.corrigir_resposta(questao, " A "), (False, "B"))

    def test_calcular_taxa_acerto(self):
        respostas = [resposta_falsa(1), resposta_falsa(0), resposta_falsa(1, disciplina="História"),
                     resposta_falsa(1)]
        self.assertAlmostEqual(educatodos.calcular_taxa_acerto(respostas), 75.0)
        self.assertAlmostEqual(educatodos.calcular_taxa_acerto(respostas, "Matemática"), 200 / 3)
        self.assertEqual(educatodos.calcular_taxa_acerto([]), 0.0)

    def test_obter_explicacao_muda_com_o_nivel(self):
        questao = QUESTOES[0]
        textos = {nivel: educatodos.obter_explicacao(questao, nivel) for nivel in nivel_aluno.NIVEIS}
        self.assertEqual(textos["Básico"], questao["explicacao_basica"])
        self.assertEqual(textos["Avançado"], questao["explicacao_avancada"])
        self.assertEqual(len(set(textos.values())), 3)
        with self.assertRaises(ValueError):
            educatodos.obter_explicacao(questao, "Expert")

    def test_texto_simplificado_usa_sempre_a_basica(self):
        questao = QUESTOES[0]
        self.assertEqual(educatodos.obter_explicacao(questao, "Avançado", simplificado=True),
                         questao["explicacao_basica"])

    def test_sortear_questao_respeita_disciplina_serie_e_nivel(self):
        rng = random.Random(1)
        questao = educatodos.sortear_questao("Matemática", "9º Ano EF", "Avançado", rng=rng)
        self.assertEqual((questao["disciplina"], questao["serie"], questao["dificuldade"]),
                         ("Matemática", "9º Ano EF", "difícil"))
        questao = educatodos.sortear_questao("História", "7º Ano EF", "Básico", rng=rng)
        self.assertEqual((questao["serie"], questao["dificuldade"]), ("7º Ano EF", "fácil"))

    def test_sortear_questao_nao_repete_e_nao_foge_da_serie(self):
        usadas = []
        while True:
            questao = educatodos.sortear_questao("História", "6º Ano EF", "Básico", excluir=usadas)
            if questao is None:
                break
            self.assertNotIn(questao["id_questao"], usadas)
            distancia = SERIES.index(questao["serie"]) - SERIES.index("6º Ano EF")
            self.assertLessEqual(distancia, educatodos.MAX_DISTANCIA_SERIE)  # nada de ensino médio no 6º ano
            usadas.append(questao["id_questao"])
        self.assertGreaterEqual(len(usadas), 3)

    def test_sortear_questao_recusa_valores_invalidos(self):
        with self.assertRaises(ValueError):
            educatodos.sortear_questao("Geografia", "6º Ano EF", "Básico")
        with self.assertRaises(ValueError):
            educatodos.sortear_questao("Matemática", "5º Ano", "Básico")


class TestValidacoes(unittest.TestCase):
    def test_ler_inteiro_insiste_ate_valor_valido(self):
        with patch("builtins.input", side_effect=["abc", "", "1_0", "+3", "99", "3"]), patch("builtins.print"):
            self.assertEqual(educatodos.ler_inteiro("> ", 0, 5), 3)

    def test_ler_nome_recusa_simbolos_numeros_e_vazio(self):
        with patch("builtins.input", side_effect=["", "--", "A", "Ana123", "  gabriela   pacheco "]), \
                patch("builtins.print"):
            self.assertEqual(educatodos.ler_nome("> "), "Gabriela Pacheco")

    def test_formatar_nome_mantem_preposicoes(self):
        self.assertEqual(educatodos.formatar_nome("MARIA DAS DORES e silva"), "Maria das Dores e Silva")

    def test_ler_sim_nao(self):
        with patch("builtins.input", side_effect=["talvez", "s"]), patch("builtins.print"):
            self.assertTrue(educatodos.ler_sim_nao("> "))

    def test_responder_questao_dica_entrada_invalida_e_tentativas(self):
        questao = QUESTOES[0]  # gabarito B
        with patch("builtins.input", side_effect=["?", "Z", "A", "C", "B"]), patch("builtins.print"):
            acertou, tentativas, usou_dica, _ = educatodos.responder_questao(questao)
        self.assertEqual((acertou, tentativas, usou_dica), (True, 3, True))  # "Z" não gastou tentativa

    def test_responder_questao_tres_erros_e_encerrar(self):
        questao = QUESTOES[0]
        with patch("builtins.input", side_effect=["A", "C", "D"]), patch("builtins.print"):
            self.assertEqual(educatodos.responder_questao(questao)[:3], (False, 3, False))
        with patch("builtins.input", side_effect=["0"]), patch("builtins.print"):
            self.assertIsNone(educatodos.responder_questao(questao))


class TestNivel(unittest.TestCase):
    def test_nivel_inicial_com_poucas_respostas(self):
        self.assertEqual(nivel_aluno.definir_nivel([resposta_falsa(1)]),
                         ("Básico", nivel_aluno.ORIGEM_INICIAL))

    def test_regra_provisoria(self):
        fortes = [resposta_falsa(1)] * 5
        fracos = [resposta_falsa(0, tentativas=3)] * 5
        with patch("builtins.print"):
            self.assertEqual(nivel_aluno.definir_nivel(fortes, prever=modelo_quebrado)[0], "Avançado")
            self.assertEqual(nivel_aluno.definir_nivel(fracos, prever=modelo_quebrado)[0], "Básico")

    def test_usa_o_modelo_do_integrante_3_por_nome(self):
        recebido = {}

        # Ordem dos parâmetros trocada de propósito: a chamada por nome tem que funcionar
        def modelo_falso(tempo_medio, taxa_acerto, taxa_dicas, media_tentativas,
                          serie, disciplina):
            recebido.update(taxa=taxa_acerto, tempo=tempo_medio, tent=media_tentativas,
                            dica=taxa_dicas, serie=serie, disciplina=disciplina)
            return ["intermediario"]

        respostas = self.historico_de_sessoes()
        nivel, origem = nivel_aluno.definir_nivel(
            respostas, prever=modelo_falso, disciplina="História", serie="2º Médio")
        self.assertEqual((nivel, origem), ("Intermediário", nivel_aluno.ORIGEM_MODELO))
        self.assertAlmostEqual(recebido["taxa"], 2 / 3)
        self.assertEqual(recebido["tempo"], 180)
        self.assertEqual(recebido["tent"], 3)
        self.assertEqual(recebido["dica"], 1)
        self.assertEqual((recebido["serie"], recebido["disciplina"]), ("2º Ano EM", "História"))

    @staticmethod
    def historico_de_sessoes():
        respostas = [resposta_falsa(1, 30, 1, 0), resposta_falsa(0, 90, 3, 1),
                     resposta_falsa(1, 60, 2, 0)]
        return [dict(r, id_sessao=str(i)) for i in range(10) for r in respostas]

    def test_modelo_real_com_dez_sessoes(self):
        dados = armazenamento.dados_vazios()
        dados["respostas"] = [dict(r, disciplina="História") for r in self.historico_de_sessoes()]
        nivel, origem = educatodos.nivel_atual(dados, 1001, "História", "3º Ano EM")
        self.assertIn(nivel, nivel_aluno.NIVEIS)
        self.assertEqual(origem, nivel_aluno.ORIGEM_MODELO)

    def test_nove_sessoes_e_respostas_legadas_ainda_usam_regra(self):
        respostas = self.historico_de_sessoes()[:-3] + [resposta_falsa(1)] * 10
        _, origem = nivel_aluno.definir_nivel(respostas, disciplina="Matemática", serie="6º Ano EF")
        self.assertEqual(origem, nivel_aluno.ORIGEM_REGRA)

    def test_modelo_que_devolve_numero_cai_na_regra_e_avisa_uma_vez(self):
        with patch.object(nivel_aluno, "_ja_avisou_falha", False), patch("builtins.print") as impressao:
            for _ in range(3):
                nivel, origem = nivel_aluno.definir_nivel(self.historico_de_sessoes(), prever=lambda **f: 0,
                                                         disciplina="História", serie="2º Ano EM")
                self.assertEqual(origem, nivel_aluno.ORIGEM_REGRA)
        self.assertEqual(impressao.call_count, 1)


class TestPersistencia(TestComPastaTemporaria):
    def test_json_ida_e_volta_com_acentos(self):
        dados = armazenamento.dados_vazios()
        dados["alunos"].append({"id_aluno": 1001, "nome": "João Ávila", "serie": "1º Ano EM"})
        self.assertTrue(armazenamento.salvar_dados(dados))
        self.assertEqual(armazenamento.carregar_dados(), dados)

    def test_json_corrompido_ou_com_formato_errado_nao_trava(self):
        conteudos = ["{isso não é json".encode("utf-8"), b"[]", b"null", b'{"alunos": {}}',
                     b'{"alunos": [{"nome": "sem id"}]}', "{\"alunos\": \"Jos\xe9\"}".encode("latin-1")]
        for conteudo in conteudos:
            self.arquivo.write_bytes(conteudo)
            with patch("builtins.print"):
                self.assertEqual(armazenamento.carregar_dados(), armazenamento.dados_vazios(), conteudo)
            self.assertFalse(self.arquivo.exists())  # o arquivo ruim foi guardado como cópia
        self.assertEqual(len(list(self.pasta.glob("progresso.corrompido-*.json"))) >= 1, True)

    def test_falha_ao_gravar_nao_derruba(self):
        with patch("os.replace", side_effect=PermissionError("arquivo travado")), \
                patch("time.sleep"), patch("builtins.print"):
            self.assertFalse(armazenamento.salvar_dados(armazenamento.dados_vazios()))

    def test_relatorio_txt_com_evolucao(self):
        dados = armazenamento.dados_vazios()
        aluno = {"id_aluno": 1001, "nome": "Ana", "serie": "6º Ano EF"}
        dados["respostas"] = [resposta_falsa(1), resposta_falsa(0)]
        dados["desempenho"] = [
            {"id_aluno": 1001, "disciplina": "Matemática", "nivel_previsto": "Básico",
             "data_calculo": "2026-11-10T10:00:00", "taxa_acerto": 40.0},
            {"id_aluno": 1001, "disciplina": "Matemática", "nivel_previsto": "Intermediário",
             "data_calculo": "2026-11-16T10:00:00", "taxa_acerto": 60.0},
        ]
        texto = educatodos.montar_relatorio(dados, aluno)
        caminho = armazenamento.salvar_relatorio_txt("r.txt", texto)
        conteudo = caminho.read_text(encoding="utf-8")
        self.assertIn("50%", conteudo)
        self.assertIn("ainda não estudou", conteudo)
        self.assertIn("10/11 Básico -> 16/11 Intermediário", conteudo)


class TestFluxoCompleto(TestComPastaTemporaria):
    def test_cadastro_e_rodada_gravam_no_formato_do_contrato(self):
        dados = armazenamento.dados_vazios()
        entradas = ["Gabriela Pacheco", "4",           # cadastro: nome e 9º Ano
                    "1", "3"] + ["A", "B", "C"] * 3     # Matemática, 3 questões
        with patch("builtins.input", side_effect=entradas), patch("builtins.print"):
            educatodos.cadastrar_aluno(dados)
            educatodos.fazer_exercicios(dados)
        self.assertEqual(dados["alunos"][0]["id_aluno"], 1001)
        self.assertEqual(len(dados["respostas"]), 3)
        campos_contrato = {"id_resposta", "id_aluno", "id_questao", "acertou", "tempo_seg",
                           "tentativas", "usou_dica", "data_resposta"}
        for resposta in dados["respostas"]:
            self.assertTrue(campos_contrato <= set(resposta))
        self.assertEqual(dados["respostas"][0]["id_resposta"], armazenamento.PRIMEIRO_ID_RESPOSTA)
        self.assertEqual(len({r["id_sessao"] for r in dados["respostas"]}), 1)
        self.assertEqual(len(dados["desempenho"]), 1)
        self.assertEqual(armazenamento.carregar_dados(), dados)  # gravou no JSON

    def test_questao_acertada_nao_volta_na_rodada_seguinte(self):
        dados = armazenamento.dados_vazios()
        with patch("builtins.input", side_effect=["Ana Souza", "7"]), patch("builtins.print"):
            educatodos.cadastrar_aluno(dados)
        vistas = []
        for _ in range(3):  # 3 rodadas de 1 questão, sempre acertando na hora
            with patch("builtins.input", side_effect=["1", "1", "A", "B", "C", "D"]), patch("builtins.print"):
                educatodos.fazer_exercicios(dados)
            vistas.append(dados["respostas"][-1]["id_questao"])
        self.assertEqual(len(set(vistas)), 3)

    def test_encerrar_sem_responder_nao_grava_desempenho(self):
        dados = armazenamento.dados_vazios()
        with patch("builtins.input", side_effect=["Ana Souza", "1", "2", "5", "0"]), patch("builtins.print"):
            educatodos.cadastrar_aluno(dados)
            educatodos.fazer_exercicios(dados)
        self.assertEqual(dados["desempenho"], [])

    def test_indicadores_de_impacto(self):
        dados = armazenamento.dados_vazios()
        dados["alunos"] = [{"id_aluno": 1001, "nome": "A", "serie": "6º Ano EF"},
                           {"id_aluno": 1002, "nome": "B", "serie": "2º EM"}]
        dados["respostas"] = [resposta_falsa(1, id_aluno=1001), resposta_falsa(1, id_aluno=1001),
                              resposta_falsa(0, id_aluno=1002), resposta_falsa(1, id_aluno=1002)]
        dados["desempenho"] = [
            {"id_aluno": 1001, "disciplina": "Matemática", "nivel_previsto": "Básico", "data_calculo": "2026-11-01"},
            {"id_aluno": 1001, "disciplina": "Matemática", "nivel_previsto": "Avançado", "data_calculo": "2026-11-09"},
            {"id_aluno": 1002, "disciplina": "Matemática", "nivel_previsto": "Básico", "data_calculo": "2026-11-01"},
        ]
        ind = educatodos.calcular_indicadores(dados)
        self.assertEqual(ind["pct_avancaram"], 50.0)
        self.assertEqual(ind["taxa_geral"], 75.0)
        self.assertEqual((ind["taxa_fundamental"], ind["taxa_medio"]), (100.0, 50.0))


class TestAudio(unittest.TestCase):
    def test_simbolos_viram_palavras(self):
        texto = audio.preparar_para_fala("150 km/h: 2 x 4 = 8 e a² -> ok")
        self.assertIn("quilômetros por hora", texto)
        self.assertIn("2 vezes 4 igual a 8", texto)
        self.assertIn("ao quadrado", texto)
        self.assertIn("resulta em", texto)


if __name__ == "__main__":
    unittest.main(verbosity=2)
