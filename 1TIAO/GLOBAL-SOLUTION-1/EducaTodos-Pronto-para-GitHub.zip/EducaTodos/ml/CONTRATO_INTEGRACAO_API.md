# Contrato de integração — API EducaTodos / Modelo de nível

## Objetivo

A aplicação deve enviar as quatro métricas agregadas do aluno **junto com a série e a disciplina**. A série e a disciplina são importantes para contextualizar a previsão; não usar valores fixos padrão.

## Payload sugerido

```json
{
  "taxa_acerto": 0.78,
  "tempo_medio": 155.0,
  "media_tentativas": 6.0,
  "taxa_dicas": 0.25,
  "serie": "8º Ano EF",
  "disciplina": "Matemática"
}
```

As taxas são proporções entre 0 e 1, não percentuais entre 0 e 100. `tempo_medio` está em segundos. `media_tentativas` é a média de tentativas por interação/sessão agregada.

## Resposta mínima

```json
{
  "nivel": "Intermediário"
}
```

## Resposta detalhada opcional

```json
{
  "nivel": "Intermediário",
  "confianca": 0.62,
  "probabilidades": {
    "Avançado": 0.12,
    "Básico": 0.26,
    "Intermediário": 0.62
  }
}
```

As probabilidades acima são apenas um exemplo de formato, não uma previsão fixa. A saída real depende dos dados enviados. `confianca` corresponde à maior probabilidade estimada pelo classificador e não representa certeza garantida.

## Chamada Python disponível

- `prever_nivel(...) -> str`: retorna somente `Básico`, `Intermediário` ou `Avançado`.
- `prever_nivel_detalhado(...) -> dict`: retorna classe e probabilidades.

Ambas exigem os seis parâmetros: `taxa_acerto`, `tempo_medio`, `media_tentativas`, `taxa_dicas`, `serie` e `disciplina`.

## Domínios aceitos

- Séries: `6º Ano EF`, `7º Ano EF`, `8º Ano EF`, `9º Ano EF`, `1º Ano EM`, `2º Ano EM`, `3º Ano EM`.
- Disciplinas: `Matemática`, `Português`, `Ciências`, `História`.
- `taxa_acerto`: 0 a 1.
- `taxa_dicas`: 0 a 1.
- `tempo_medio`: maior que zero, em segundos.
- `media_tentativas`: maior que zero.

Entradas inválidas levantam `ValueError` ou `TypeError`; a camada HTTP da aplicação deve converter esses erros em resposta 400/422, sem retornar uma classificação silenciosa.

## Passos para o Integrante 1

1. Manter o arquivo `modelo_nivel.joblib` na raiz desta entrega (ou ajustar o caminho `CAMINHO_MODELO`).
2. Importar as funções de `src.modelo_integracao`.
3. Ao receber a resposta do aluno, agregar o histórico da combinação aluno + disciplina: média de taxa de acerto, média de tempo, média de tentativas e proporção de sessões com dica.
4. Encaminhar também a série escolar e a disciplina selecionada na tela.
5. Tratar erros de validação e exibir o nível retornado na interface.
6. Não enviar `nota_diagnostica` à função de previsão; ela não faz parte do contrato.

**Nota:** este pacote entrega a interface Python do modelo e o contrato para integração. Como o código-fonte da API/aplicação do Integrante 1 não foi enviado nesta conversa, não altera diretamente os endpoints existentes; o Integrante 1 deve conectar a chamada no endpoint correspondente.
