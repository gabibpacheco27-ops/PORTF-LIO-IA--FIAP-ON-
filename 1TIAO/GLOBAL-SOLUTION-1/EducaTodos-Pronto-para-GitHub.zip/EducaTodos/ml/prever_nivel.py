"""Compatibilidade: importe as funções de previsão deste módulo ou de src."""
from src.modelo_integracao import prever_nivel, prever_nivel_detalhado

__all__ = ["prever_nivel", "prever_nivel_detalhado"]
