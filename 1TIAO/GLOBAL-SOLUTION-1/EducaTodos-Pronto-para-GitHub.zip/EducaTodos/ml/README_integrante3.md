# EducaTodos — Entrega do Integrante 3 (Machine Learning)

## Objetivo

Treinar e avaliar um classificador que estime o nível do aluno por **série e disciplina** (`Básico`, `Intermediário` ou `Avançado`), usando o histórico agregado de interações da plataforma. A entrega contém o pipeline de preparação dos dados, comparação entre modelos, artefato treinado, interface de integração, notebook e testes.

> **Natureza dos dados:** as duas bases fornecidas pelo Integrante 2 contêm dados 100% simulados/sintéticos. As métricas deste trabalho descrevem somente esse cenário de prototipagem e não comprovam desempenho com alunos reais.

## Estrutura

```text
EducaTodos_Integrante3/
├── dados/
│   ├── interacoes_alunos.csv
│   └── diagnostico_alunos.csv
├── src/
│   ├── __init__.py
│   └── modelo_integracao.py
├── testes/
│   └── test_modelo_integracao.py
├── assets/
│   ├── importancia_variaveis.png
│   └── matriz_confusao_melhor_modelo.png
├── treinar_modelo.py
├── modelo_nivel.joblib
├── prever_nivel.py
├── notebook_integrante3_educatodos.ipynb
├── base_agregada_aluno_disciplina.csv
├── comparacao_validacao_cruzada.csv
├── metricas_teste.csv
├── previsoes_teste_modelo_selecionado.csv
├── importancia_variaveis_random_forest.csv
├── matriz_confusao_*.csv
├── relatorio_*.txt
├── resumo_execucao.json
├── evidencias_validacao.csv
├── relatorio_resultados_limitacoes.md
├── CONTRATO_INTEGRACAO_API.md
└── requirements.txt
```

## Como o modelo foi preparado

1. `interacoes_alunos.csv` é agrupado por `id_aluno`, `serie` e `disciplina`.
2. São calculadas as médias de `taxa_acerto`, `tempo_seg` (renomeada para `tempo_medio`), `tentativas` (`media_tentativas`) e `usou_dica` (`taxa_dicas`).
3. A tabela é unida a `diagnostico_alunos.csv` pelas três chaves.
4. O alvo (`y`) é `nivel_diagnostico`.
5. As variáveis explicativas (`X`) são as quatro métricas comportamentais, `serie` e `disciplina`.

**`nota_diagnostica` não é usada como variável explicativa**, pois é a origem de `nivel_diagnostico`. Assim, evita-se fornecer ao modelo a própria informação que ele deve aprender a prever.

## Avaliação sem vazamento entre alunos

A separação treino/teste usa `StratifiedGroupKFold`, agrupando por `id_aluno`. Foram usados 200 alunos para treino e 50 alunos para teste; todos os registros de um mesmo aluno ficam somente em uma das partições. A comparação durante o treinamento também usa validação cruzada estratificada e agrupada por aluno.

Modelos comparados:

- Árvore de Decisão;
- Random Forest;
- Baseline com a classe majoritária, como referência simples.

A seleção do modelo é feita pela média de F1-macro na validação cruzada. O pipeline vencedor é depois reajustado com os 1.000 registros para gerar `modelo_nivel.joblib`, usado pela integração.

## Resultado desta execução

| Modelo | Acurácia no teste | F1-macro no teste |
|---|---:|---:|
| Random Forest | 59,5% | 0,596 |
| Árvore de Decisão | 52,0% | 0,520 |
| Baseline (classe majoritária) | 44,5% | 0,205 |

A Random Forest foi selecionada pela validação cruzada (F1-macro médio de aproximadamente 0,585). Consulte `metricas_teste.csv`, `comparacao_validacao_cruzada.csv`, `previsoes_teste_modelo_selecionado.csv` e `relatorio_resultados_limitacoes.md` para as demais métricas, previsões individuais do teste e ressalvas.

## Como executar

No terminal, dentro desta pasta:

```bash
python -m pip install -r requirements.txt
python treinar_modelo.py
python -m unittest discover -s testes -v
```

O treinamento atualiza as tabelas, gráficos, relatórios e `modelo_nivel.joblib`.

O notebook `notebook_integrante3_educatodos.ipynb` documenta o fluxo completo. Abra-o no Jupyter ou Google Colab, mantendo a pasta `dados/` e os demais arquivos do projeto no mesmo diretório.

## Como integrar na aplicação

A interface fica em `src/modelo_integracao.py`. Exemplo:

```python
from src.modelo_integracao import prever_nivel, prever_nivel_detalhado

nivel = prever_nivel(
    taxa_acerto=0.78,
    tempo_medio=155.0,
    media_tentativas=6.0,
    taxa_dicas=0.25,
    serie="8º Ano EF",
    disciplina="Matemática",
)
print(nivel)  # Básico, Intermediário ou Avançado

# Alternativa com probabilidades estimadas:
detalhes = prever_nivel_detalhado(
    taxa_acerto=0.78,
    tempo_medio=155.0,
    media_tentativas=6.0,
    taxa_dicas=0.25,
    serie="8º Ano EF",
    disciplina="Matemática",
)
```

Os parâmetros `serie` e `disciplina` são obrigatórios. A função não assume silenciosamente Matemática ou 6º Ano EF. Os nomes devem corresponder exatamente às categorias documentadas no contrato. A função detalhada retorna a classe, a maior probabilidade estimada e as probabilidades por classe; essas probabilidades não são garantias e não foram calibradas.

Veja `CONTRATO_INTEGRACAO_API.md` para o formato sugerido de payload da API e o que o Integrante 1 precisa conectar na aplicação.

## Testes automatizados

`testes/test_modelo_integracao.py` verifica previsões válidas, retorno detalhado, cobertura de todas as séries e disciplinas, e rejeição de valores numéricos fora da faixa, tipos incorretos, série inválida e disciplina inválida. Nesta execução, **10 testes passaram** (veja `resultados_testes.txt`).

## Limitações e uso responsável

- Dados inteiramente simulados; nenhuma pessoa real foi usada.
- O desempenho pode mudar significativamente em dados reais, em novas escolas ou em novas coortes.
- A granularidade é uma sessão agregada, não o registro de cada questão individual.
- A classificação é apoio pedagógico para direcionar conteúdo, não diagnóstico definitivo nem substituto da avaliação do professor.
- Antes de uso real, será necessário validar com dados representativos, acompanhar vieses, calibrar probabilidades, monitorar deriva e revisar o modelo periodicamente.
