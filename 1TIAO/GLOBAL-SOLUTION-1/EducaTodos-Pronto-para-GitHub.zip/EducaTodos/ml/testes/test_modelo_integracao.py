import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.modelo_integracao import prever_nivel, prever_nivel_detalhado


class TesteIntegracaoModelo(unittest.TestCase):
    def test_previsao_valida(self):
        nivel = prever_nivel(0.78, 155.0, 6.0, 0.25, "8º Ano EF", "Matemática")
        self.assertIn(nivel, {"Básico", "Intermediário", "Avançado"})

    def test_previsao_detalhada(self):
        resultado = prever_nivel_detalhado(0.78, 155.0, 6.0, 0.25, "8º Ano EF", "Matemática")
        self.assertIn(resultado["nivel"], {"Básico", "Intermediário", "Avançado"})
        self.assertGreaterEqual(resultado["confianca"], 0)
        self.assertLessEqual(resultado["confianca"], 1)
        self.assertAlmostEqual(sum(resultado["probabilidades"].values()), 1.0, places=6)

    def test_todas_series_e_disciplinas_aceitas(self):
        series = ["6º Ano EF", "7º Ano EF", "8º Ano EF", "9º Ano EF", "1º Ano EM", "2º Ano EM", "3º Ano EM"]
        disciplinas = ["Matemática", "Português", "Ciências", "História"]
        for serie in series:
            for disciplina in disciplinas:
                nivel = prever_nivel(0.7, 160, 5, 0.2, serie, disciplina)
                self.assertIn(nivel, {"Básico", "Intermediário", "Avançado"})

    def test_taxa_acerto_fora_da_faixa(self):
        with self.assertRaises(ValueError):
            prever_nivel(1.2, 150, 5, 0.2, "8º Ano EF", "Matemática")

    def test_tempo_zero(self):
        with self.assertRaises(ValueError):
            prever_nivel(0.7, 0, 5, 0.2, "8º Ano EF", "Matemática")

    def test_media_tentativas_zero(self):
        with self.assertRaises(ValueError):
            prever_nivel(0.7, 150, 0, 0.2, "8º Ano EF", "Matemática")

    def test_taxa_dicas_fora_da_faixa(self):
        with self.assertRaises(ValueError):
            prever_nivel(0.7, 150, 5, -0.1, "8º Ano EF", "Matemática")

    def test_serie_invalida(self):
        with self.assertRaises(ValueError):
            prever_nivel(0.7, 150, 5, 0.2, "4º Ano EF", "Matemática")

    def test_disciplina_invalida(self):
        with self.assertRaises(ValueError):
            prever_nivel(0.7, 150, 5, 0.2, "8º Ano EF", "Geografia")

    def test_tipo_invalido(self):
        with self.assertRaises(TypeError):
            prever_nivel("0.7", 150, 5, 0.2, "8º Ano EF", "Matemática")


if __name__ == "__main__":
    unittest.main(verbosity=2)
