"""Interface estável de integração do modelo de ML com o aplicativo EducaTodos.

Contrato: prever_nivel(taxa_acerto, tempo_medio, media_tentativas, taxa_dicas,
                       serie, disciplina) -> str

O modelo usa série e disciplina como contexto. Não há valores padrão silenciosos.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import joblib
import pandas as pd

SERIES_ESCOLARES = {
    "6º Ano EF", "7º Ano EF", "8º Ano EF", "9º Ano EF",
    "1º Ano EM", "2º Ano EM", "3º Ano EM",
}
DISCIPLINAS = {"Matemática", "Português", "Ciências", "História"}
FEATURES = [
    "taxa_acerto", "tempo_medio", "media_tentativas", "taxa_dicas", "serie", "disciplina"
]
CAMINHO_MODELO = Path(__file__).resolve().parents[1] / "modelo_nivel.joblib"


@lru_cache(maxsize=1)
def _carregar_modelo(caminho: str = str(CAMINHO_MODELO)):
    arquivo = Path(caminho)
    if not arquivo.exists():
        raise FileNotFoundError(
            f"Modelo não encontrado em {arquivo}. Execute treinar_modelo.py antes de usar a integração."
        )
    return joblib.load(arquivo)


def _validar_entrada(
    taxa_acerto: float,
    tempo_medio: float,
    media_tentativas: float,
    taxa_dicas: float,
    serie: str,
    disciplina: str,
) -> dict[str, Any]:
    valores = {
        "taxa_acerto": taxa_acerto,
        "tempo_medio": tempo_medio,
        "media_tentativas": media_tentativas,
        "taxa_dicas": taxa_dicas,
    }
    for nome, valor in valores.items():
        if isinstance(valor, bool) or not isinstance(valor, (int, float)):
            raise TypeError(f"{nome} deve ser numérico.")
        if not pd.notna(valor):
            raise ValueError(f"{nome} não pode ser nulo ou NaN.")
    if not 0 <= float(taxa_acerto) <= 1:
        raise ValueError("taxa_acerto deve estar entre 0 e 1.")
    if float(tempo_medio) <= 0:
        raise ValueError("tempo_medio deve ser maior que zero (segundos).")
    if float(media_tentativas) <= 0:
        raise ValueError("media_tentativas deve ser maior que zero.")
    if not 0 <= float(taxa_dicas) <= 1:
        raise ValueError("taxa_dicas deve estar entre 0 e 1.")
    if serie not in SERIES_ESCOLARES:
        raise ValueError(f"Série inválida: {serie!r}. Consulte SERIES_ESCOLARES.")
    if disciplina not in DISCIPLINAS:
        raise ValueError(f"Disciplina inválida: {disciplina!r}. Consulte DISCIPLINAS.")
    return {
        "taxa_acerto": float(taxa_acerto),
        "tempo_medio": float(tempo_medio),
        "media_tentativas": float(media_tentativas),
        "taxa_dicas": float(taxa_dicas),
        "serie": serie,
        "disciplina": disciplina,
    }


def prever_nivel_detalhado(
    taxa_acerto: float,
    tempo_medio: float,
    media_tentativas: float,
    taxa_dicas: float,
    serie: str,
    disciplina: str,
) -> dict[str, Any]:
    """Retorna classe, confiança estimada e probabilidades por classe.

    A confiança é a maior probabilidade estimada pelo classificador; não deve
    ser interpretada como garantia ou probabilidade clínica/educacional calibrada.
    """
    entrada = _validar_entrada(
        taxa_acerto, tempo_medio, media_tentativas, taxa_dicas, serie, disciplina
    )
    modelo = _carregar_modelo()
    amostra = pd.DataFrame([entrada], columns=FEATURES)
    nivel = str(modelo.predict(amostra)[0])
    resultado: dict[str, Any] = {"nivel": nivel}
    if hasattr(modelo, "predict_proba"):
        probabilidades = modelo.predict_proba(amostra)[0]
        classes = modelo.classes_
        resultado["confianca"] = float(max(probabilidades))
        resultado["probabilidades"] = {
            str(classe): float(prob)
            for classe, prob in zip(classes, probabilidades)
        }
    return resultado


def prever_nivel(
    taxa_acerto: float,
    tempo_medio: float,
    media_tentativas: float,
    taxa_dicas: float,
    serie: str,
    disciplina: str,
) -> str:
    """Retorna somente o rótulo Básico, Intermediário ou Avançado."""
    return prever_nivel_detalhado(
        taxa_acerto, tempo_medio, media_tentativas, taxa_dicas, serie, disciplina
    )["nivel"]
