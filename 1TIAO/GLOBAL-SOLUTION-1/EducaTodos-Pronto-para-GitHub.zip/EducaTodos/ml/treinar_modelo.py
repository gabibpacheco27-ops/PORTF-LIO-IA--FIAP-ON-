"""Treinamento e avaliação dos modelos de nível do projeto EducaTodos.

Os dados de entrada são sintéticos e devem ser colocados em ./dados/.
O alvo é nivel_diagnostico; nota_diagnostica nunca entra nas variáveis X.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import StratifiedGroupKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "dados"
ASSETS_DIR = ROOT / "assets"
CLASSES = ["Básico", "Intermediário", "Avançado"]
NUMERIC_FEATURES = ["taxa_acerto", "tempo_medio", "media_tentativas", "taxa_dicas"]
CATEGORICAL_FEATURES = ["serie", "disciplina"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES
TARGET = "nivel_diagnostico"


def carregar_e_preparar_dados(
    caminho_interacoes: Path | str | None = None,
    caminho_diagnostico: Path | str | None = None,
) -> pd.DataFrame:
    """Agrega interações por aluno/série/disciplina e une o diagnóstico."""
    caminho_interacoes = Path(caminho_interacoes or DATA_DIR / "interacoes_alunos.csv")
    caminho_diagnostico = Path(caminho_diagnostico or DATA_DIR / "diagnostico_alunos.csv")
    interacoes = pd.read_csv(caminho_interacoes)
    diagnostico = pd.read_csv(caminho_diagnostico)

    colunas_interacoes = {
        "id_aluno", "serie", "disciplina", "taxa_acerto", "tempo_seg",
        "tentativas", "usou_dica",
    }
    colunas_diag = {"id_aluno", "serie", "disciplina", TARGET}
    faltantes_i = colunas_interacoes - set(interacoes.columns)
    faltantes_d = colunas_diag - set(diagnostico.columns)
    if faltantes_i or faltantes_d:
        raise ValueError(
            f"Colunas ausentes. Interações: {sorted(faltantes_i)}; "
            f"diagnóstico: {sorted(faltantes_d)}"
        )

    chaves = ["id_aluno", "serie", "disciplina"]
    agregada = (
        interacoes.groupby(chaves, as_index=False)
        .agg(
            taxa_acerto=("taxa_acerto", "mean"),
            tempo_medio=("tempo_seg", "mean"),
            media_tentativas=("tentativas", "mean"),
            taxa_dicas=("usou_dica", "mean"),
            quantidade_interacoes=("id_aluno", "size"),
        )
    )
    base = agregada.merge(
        diagnostico[chaves + [TARGET]],
        on=chaves,
        how="inner",
        validate="one_to_one",
    )
    if len(base) != len(diagnostico):
        raise ValueError(
            "O merge não encontrou correspondência para todos os diagnósticos. "
            f"Linhas agregadas={len(agregada)}, diagnósticos={len(diagnostico)}, "
            f"resultado={len(base)}."
        )
    if base[FEATURES + [TARGET]].isna().any().any():
        raise ValueError("Há valores ausentes nas variáveis utilizadas pelo modelo.")
    if not set(base[TARGET].unique()).issubset(set(CLASSES)):
        raise ValueError("Há classes de diagnóstico fora do contrato esperado.")
    if not base["taxa_acerto"].between(0, 1).all():
        raise ValueError("taxa_acerto deve estar entre 0 e 1.")
    if not base["taxa_dicas"].between(0, 1).all():
        raise ValueError("taxa_dicas deve estar entre 0 e 1.")
    return base.sort_values(chaves).reset_index(drop=True)


def construir_pipeline(classificador: Any) -> Pipeline:
    """Preprocessa variáveis numéricas e categóricas dentro do pipeline."""
    preprocessor = ColumnTransformer(
        transformers=[
            ("numericas", StandardScaler(), NUMERIC_FEATURES),
            ("categoricas", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )
    return Pipeline([("preprocessamento", preprocessor), ("classificador", classificador)])


def executar_treinamento() -> dict[str, Any]:
    """Executa holdout por aluno, validação cruzada agrupada, compara modelos e salva artefatos."""
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    base = carregar_e_preparar_dados()
    base.to_csv(ROOT / "base_agregada_aluno_disciplina.csv", index=False, encoding="utf-8-sig")

    X = base[FEATURES].copy()
    y = base[TARGET].copy()
    groups = base["id_aluno"].copy()

    # O mesmo aluno não pode aparecer simultaneamente no treino e no teste.
    holdout = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)
    train_idx, test_idx = next(holdout.split(X, y, groups=groups))
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    groups_train, groups_test = groups.iloc[train_idx], groups.iloc[test_idx]
    assert set(groups_train).isdisjoint(set(groups_test)), "Vazamento de alunos entre treino e teste."

    modelos = {
        "Árvore de Decisão": construir_pipeline(
            DecisionTreeClassifier(max_depth=5, min_samples_leaf=8, class_weight="balanced", random_state=42)
        ),
        "Random Forest": construir_pipeline(
            RandomForestClassifier(
                n_estimators=400,
                min_samples_leaf=3,
                max_features="sqrt",
                class_weight="balanced_subsample",
                random_state=42,
                n_jobs=-1,
            )
        ),
        "Baseline (classe majoritária)": construir_pipeline(
            DummyClassifier(strategy="most_frequent")
        ),
    }

    cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=123)
    cv_rows: list[dict[str, Any]] = []
    fitted_train_models: dict[str, Pipeline] = {}
    for nome, pipeline in modelos.items():
        scores = cross_validate(
            pipeline,
            X_train,
            y_train,
            groups=groups_train,
            cv=cv,
            scoring={"accuracy": "accuracy", "f1_macro": "f1_macro"},
            n_jobs=-1,
            return_train_score=False,
        )
        pipeline.fit(X_train, y_train)
        fitted_train_models[nome] = pipeline
        cv_rows.append(
            {
                "modelo": nome,
                "cv_accuracy_media": float(np.mean(scores["test_accuracy"])),
                "cv_accuracy_desvio": float(np.std(scores["test_accuracy"])),
                "cv_f1_macro_media": float(np.mean(scores["test_f1_macro"])),
                "cv_f1_macro_desvio": float(np.std(scores["test_f1_macro"])),
            }
        )
    comparacao_cv = pd.DataFrame(cv_rows).sort_values(
        ["cv_f1_macro_media", "cv_accuracy_media"], ascending=False
    )
    comparacao_cv.to_csv(ROOT / "comparacao_validacao_cruzada.csv", index=False, encoding="utf-8-sig")

    metric_rows: list[dict[str, Any]] = []
    report_texts: dict[str, str] = {}
    cm_melhor: np.ndarray | None = None
    previsoes_melhor_modelo: pd.DataFrame | None = None
    melhor_nome = str(comparacao_cv.iloc[0]["modelo"])
    for nome, pipeline in fitted_train_models.items():
        pred = pipeline.predict(X_test)
        row = {
            "modelo": nome,
            "accuracy_teste": float(accuracy_score(y_test, pred)),
            "balanced_accuracy_teste": float(balanced_accuracy_score(y_test, pred)),
            "precision_macro_teste": float(precision_score(y_test, pred, average="macro", zero_division=0)),
            "recall_macro_teste": float(recall_score(y_test, pred, average="macro", zero_division=0)),
            "f1_macro_teste": float(f1_score(y_test, pred, average="macro", zero_division=0)),
            "f1_weighted_teste": float(f1_score(y_test, pred, average="weighted", zero_division=0)),
        }
        metric_rows.append(row)
        report_texts[nome] = classification_report(y_test, pred, labels=CLASSES, zero_division=0)
        cm = confusion_matrix(y_test, pred, labels=CLASSES)
        pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_csv(
            ROOT / f"matriz_confusao_{'arvore' if nome == 'Árvore de Decisão' else 'random_forest' if nome == 'Random Forest' else 'baseline'}.csv",
            encoding="utf-8-sig",
        )
        if nome == melhor_nome:
            cm_melhor = cm
            previsoes_melhor_modelo = base.iloc[test_idx][["id_aluno", "serie", "disciplina"]].copy()
            previsoes_melhor_modelo["nivel_real"] = y_test.to_numpy()
            previsoes_melhor_modelo["nivel_previsto"] = pred
            previsoes_melhor_modelo["acertou"] = previsoes_melhor_modelo["nivel_real"] == previsoes_melhor_modelo["nivel_previsto"]
            if hasattr(pipeline, "predict_proba"):
                probs = pipeline.predict_proba(X_test)
                for j, classe in enumerate(pipeline.classes_):
                    previsoes_melhor_modelo[f"probabilidade_{classe}"] = probs[:, j]
    if previsoes_melhor_modelo is not None:
        previsoes_melhor_modelo.to_csv(ROOT / "previsoes_teste_modelo_selecionado.csv", index=False, encoding="utf-8-sig")
    metricas = pd.DataFrame(metric_rows)
    metricas.to_csv(ROOT / "metricas_teste.csv", index=False, encoding="utf-8-sig")

    # Reajuste final em todos os 1.000 exemplos para o artefato consumido pela aplicação.
    modelo_final = construir_pipeline(modelos[melhor_nome].named_steps["classificador"])
    modelo_final.fit(X, y)
    joblib.dump(modelo_final, ROOT / "modelo_nivel.joblib", compress=3)

    # Importância das variáveis do Random Forest quando ele é o modelo selecionado.
    importancias = pd.DataFrame()
    rf = fitted_train_models.get("Random Forest")
    if rf is not None:
        pre = rf.named_steps["preprocessamento"]
        clf = rf.named_steps["classificador"]
        nomes = pre.get_feature_names_out()
        importancias = pd.DataFrame({"variavel": nomes, "importancia": clf.feature_importances_})
        importancias = importancias.sort_values("importancia", ascending=False)
        importancias.to_csv(ROOT / "importancia_variaveis_random_forest.csv", index=False, encoding="utf-8-sig")
        plt.figure(figsize=(9, 5))
        top = importancias.head(12).sort_values("importancia")
        plt.barh(top["variavel"], top["importancia"])
        plt.title("Importância das variáveis — Random Forest")
        plt.xlabel("Importância (impureza Gini normalizada)")
        plt.tight_layout()
        plt.savefig(ASSETS_DIR / "importancia_variaveis.png", dpi=160)
        plt.close()

    if cm_melhor is not None:
        fig, ax = plt.subplots(figsize=(6.5, 5.5))
        im = ax.imshow(cm_melhor, cmap="Blues")
        ax.set_xticks(range(len(CLASSES)), CLASSES, rotation=20, ha="right")
        ax.set_yticks(range(len(CLASSES)), CLASSES)
        ax.set_xlabel("Classe prevista")
        ax.set_ylabel("Classe real")
        ax.set_title(f"Matriz de confusão — {melhor_nome}")
        for i in range(cm_melhor.shape[0]):
            for j in range(cm_melhor.shape[1]):
                ax.text(j, i, str(cm_melhor[i, j]), ha="center", va="center")
        fig.colorbar(im, ax=ax, shrink=0.8)
        fig.tight_layout()
        fig.savefig(ASSETS_DIR / "matriz_confusao_melhor_modelo.png", dpi=160)
        plt.close(fig)

    # Arquivos de relatório detalhado por modelo.
    for nome, txt in report_texts.items():
        slug = "arvore" if nome == "Árvore de Decisão" else "random_forest" if nome == "Random Forest" else "baseline"
        (ROOT / f"relatorio_{slug}.txt").write_text(txt, encoding="utf-8")

    dist = base[TARGET].value_counts().reindex(CLASSES, fill_value=0)
    summary = {
        "natureza_dos_dados": "100% simulados/sintéticos",
        "linhas_interacoes_origem": int(pd.read_csv(DATA_DIR / "interacoes_alunos.csv").shape[0]),
        "linhas_diagnostico_origem": int(pd.read_csv(DATA_DIR / "diagnostico_alunos.csv").shape[0]),
        "linhas_base_modelo": int(len(base)),
        "alunos_unicos": int(base["id_aluno"].nunique()),
        "series": sorted(base["serie"].unique().tolist()),
        "disciplinas": sorted(base["disciplina"].unique().tolist()),
        "distribuicao_classes": {k: int(v) for k, v in dist.items()},
        "distribuicao_classes_treino": {str(k): int(v) for k, v in y_train.value_counts().items()},
        "distribuicao_classes_teste": {str(k): int(v) for k, v in y_test.value_counts().items()},
        "n_alunos_treino": int(groups_train.nunique()),
        "n_alunos_teste": int(groups_test.nunique()),
        "n_registros_treino": int(len(train_idx)),
        "n_registros_teste": int(len(test_idx)),
        "sem_vazamento_de_aluno": True,
        "features": FEATURES,
        "alvo": TARGET,
        "nota_diagnostica_usada_em_X": False,
        "melhor_modelo_por_cv_f1_macro": melhor_nome,
        "comparacao_cv": comparacao_cv.to_dict(orient="records"),
        "metricas_holdout": metric_rows,
        "observacao": "Métricas refletem exclusivamente esta base sintética; não garantem desempenho em dados reais.",
    }
    (ROOT / "resumo_execucao.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # Evidências básicas de sanidade e separação por aluno.
    evidencias = [
        ("base_agregada_tem_1000_linhas", len(base) == 1000),
        ("cada_aluno_tem_4_disciplinas", (base.groupby("id_aluno").size() == 4).all()),
        ("treino_e_teste_sem_alunos_em_comum", set(groups_train).isdisjoint(set(groups_test))),
        ("nota_diagnostica_fora_das_features", "nota_diagnostica" not in FEATURES),
        ("todas_as_classes_presentes", set(y.unique()) == set(CLASSES)),
        ("modelo_final_salvo", (ROOT / "modelo_nivel.joblib").exists()),
    ]
    pd.DataFrame(evidencias, columns=["verificacao", "aprovado"]).to_csv(
        ROOT / "evidencias_validacao.csv", index=False, encoding="utf-8-sig"
    )
    print("Base agregada:", base.shape)
    print("Alunos em treino/teste:", groups_train.nunique(), "/", groups_test.nunique())
    print("Melhor modelo pela validação cruzada:", melhor_nome)
    print(metricas.to_string(index=False))
    return summary


if __name__ == "__main__":
    executar_treinamento()
