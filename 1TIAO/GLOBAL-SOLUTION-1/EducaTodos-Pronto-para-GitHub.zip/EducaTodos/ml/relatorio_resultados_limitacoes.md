# Relatório — Modelagem de Machine Learning (Integrante 3)

## 1. Objetivo

Classificar o nível de aprendizagem por aluno e disciplina em três categorias: Básico, Intermediário e Avançado, usando as interações agregadas da plataforma EducaTodos.

## 2. Origem e preparação dos dados

Foram utilizados os arquivos do Integrante 2: `interacoes_alunos.csv` (11.991 interações válidas) e `diagnostico_alunos.csv` (1.000 avaliações diagnósticas). A base final contém 1.000 combinações aluno × disciplina e 250 alunos distribuídos pelas sete séries escolares e quatro disciplinas. Todos os dados são sintéticos.

As interações foram agrupadas por `id_aluno`, `serie` e `disciplina`, produzindo quatro atributos: média de taxa de acerto, tempo médio em segundos, média de tentativas e taxa de uso de dicas. O alvo utilizado é `nivel_diagnostico`. A coluna `nota_diagnostica` foi excluída de X por derivar diretamente do alvo.

## 3. Estratégia de avaliação

Foi usada separação estratificada por grupos (`id_aluno`): 200 alunos no treinamento e 50 no teste. Nenhum aluno aparece nas duas partições. A validação cruzada interna também é estratificada e agrupada por aluno. Esse procedimento reduz o risco de o teste avaliar registros de estudantes já vistos durante o treinamento.

Foram comparados Árvore de Decisão, Random Forest e um baseline que sempre prevê a classe majoritária. O critério de seleção foi a média de F1-macro na validação cruzada.

## 4. Resultados

A Random Forest foi selecionada, com F1-macro médio de aproximadamente 0,585 na validação cruzada. No conjunto de teste, apresentou:

- Acurácia: **59,5%**;
- Acurácia balanceada: **60,7%**;
- Precisão macro: **58,9%**;
- Recall macro: **60,7%**;
- F1-macro: **0,596**;
- F1 ponderado: **0,595**.

A Árvore de Decisão obteve 52,0% de acurácia e F1-macro de 0,520. O baseline de classe majoritária obteve 44,5% de acurácia e F1-macro de 0,205. Os resultados completos por classe estão nos arquivos `relatorio_*.txt` e `metricas_teste.csv`.

## 5. Interpretação e variáveis

Na Random Forest avaliada, `taxa_acerto` foi a variável de maior importância, seguida por `taxa_dicas`, `tempo_medio` e `media_tentativas`. As variáveis categóricas `serie` e `disciplina` também são incluídas no modelo, mesmo que tenham menor importância global neste conjunto.

A importância de variável descreve o comportamento do modelo treinado e não demonstra causalidade. Não se deve concluir que aumentar ou reduzir o uso de dicas, por si só, causará alteração no nível do aluno.

## 6. Limitações

1. **Dados sintéticos:** padrões, ruídos e relações foram simulados. A métrica não representa, por si só, a qualidade esperada em escolas reais.
2. **Tamanho e representatividade:** 250 alunos simulados não representam a diversidade de redes, currículos, idades, contextos socioeconômicos ou necessidades educacionais.
3. **Granularidade:** cada linha de interação representa uma sessão agregada, não uma questão individual.
4. **Dependência da origem do alvo:** o nível foi definido por nota diagnóstica simulada com faixas fixas. Mudanças nessas faixas alteram o alvo e podem alterar o desempenho.
5. **Probabilidades:** os valores de `predict_proba` não foram calibrados; devem ser tratados como pontuações estimadas, não certezas.
6. **Uso pedagógico:** a classificação deve servir como recomendação inicial de conteúdo e ser revisada por educadores, nunca como diagnóstico definitivo ou decisão automática de alto impacto.

## 7. Próximos passos antes de qualquer uso real

- Coletar dados reais com base legal, governança, segurança e minimização de dados apropriadas.
- Validar o modelo em escolas e turmas que não participaram do treinamento.
- Avaliar erros por série e disciplina, bem como possíveis disparidades entre grupos relevantes, com metodologia e autorização adequadas.
- Calibrar probabilidades, acompanhar métricas ao longo do tempo e definir processo de retreinamento.
- Fazer validação pedagógica com professores e estudantes e permitir revisão humana das recomendações.

## 8. Artefato

`modelo_nivel.joblib` contém o pipeline final reajustado com os 1.000 registros sintéticos. A aplicação deve chamá-lo por meio de `src/modelo_integracao.py`, que valida entradas e exige série e disciplina.
