# Roteiro — parte do Integrante 4 (cerca de 1 min dentro dos 5 min do vídeo)

Regras: vídeo de até 5 minutos, no YouTube como "não listado". Dividir o tempo entre os 4 integrantes (~1 min 15 s cada).

1. **(0:00)** "Eu sou [nome] e cuidei do banco de dados e do repositório." Mostrar `assets/er_educatodos.png`.
2. **(0:10)** "São cinco tabelas. Alunos, questões, respostas e desempenho ligados por chaves; a base simulada fica separada."
3. **(0:25)** No terminal: `python -m src.main_sqlite`. Cadastrar um aluno, responder uma questão, escolher "Sair".
4. **(0:40)** Rodar de novo, selecionar o aluno e ver o desempenho: "o progresso voltou do banco".
5. **(0:50)** `python scripts/executar_consultas.py dados/demo.db`: mostrar a taxa de acerto por aluno. Dizer que os dados da demo são fictícios.
6. **(1:00)** Rodar `python -m unittest discover -s tests`: "39 testes passando". Encerrar.

Dica: gravar o terminal com fonte grande; não mostrar nenhum dado pessoal.
